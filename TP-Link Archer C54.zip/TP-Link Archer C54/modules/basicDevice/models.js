//@ sourceURL=modules/basicDevice/models.js

(function($) {
	$.su.define("lanDhcpIpProxy", {
		extend: "MERProxy",
		preventSuccessEvent: true,
		instrs: {
				get: {
						instr: "main lanDhcpc serverIp"
				}
		}
	});

	
	$.su.storeManager.define("connectedClientsStore", {
		type: "store",
		autoReload: false,
		keyProperty: "mac",
		fields: [{
			name: "deviceName",
			allowBlank: false,
			maxLength: 32
		}, {
			name: "deviceTag"
		}, {
			name: "deviceType",
			defaultValue: "0"
		}, {
			name: "mac"
		}, {
			name: "ip"
		}, {
			name: "downloadSpeed"
		}, {
			name: "uploadSpeed"
		}, {
			name: "downloadLimit",
			allowBlank: false,
			vtype: "integer"
		}, {
			name: "uploadLimit",
			allowBlank: false,
			vtype: "integer"
		}, {
			name: "host",
			defaultValue: false
		}],
		convert: function(data) {
			var hostMac = $.su.serviceManager.get("device").getHostMac();
			var sortData = clientsStoreConvert(getEffectiveData(data), function(item) {
				return item.blocked == "0" && item.online == "1";
			}).sort(function(a, b) {
				return a.mac > b.mac ? 1 : -1;
				
			});
			var ret =[];
			for(var i = 0, len = sortData.length; i< len; i++){
				$.su.App.utils.isSameMac(sortData[i].mac, hostMac)? ret.unshift(sortData[i]): ret.push(sortData[i]);
			}
			if (ret.length > 0 && ret[0].mac === hostMac) {
				ret[0].host = true;
			}
			return ret;
		},
		serialize: clientsStoreSerialize,
		proxy: "connectedClientsProxy"
	});
	$.su.storeManager.define("allClientsStore", {
		type: "store",
		autoReload: false,
		keyProperty: "mac",
		fields: [{
			name: "deviceName",
			allowBlank: false,
			maxLength: 32
		}, {
			name: "deviceTag"
		}, {
			name: "deviceType",
			defaultValue: "0"
		}, {
			name: "mac"
		}, {
			name: "ip"
		}, {
			name: "downloadSpeed"
		}, {
			name: "uploadSpeed"
		}, {
			name: "downloadLimit",
			allowBlank: false,
			vtype: "integer"
		}, {
			name: "uploadLimit",
			allowBlank: false,
			vtype: "integer"
		}, {
			name: "host",
			defaultValue: false
		}],
		convert: function(data) {
			var hostMac = $.su.serviceManager.get("device").getHostMac();
			var sortData = clientsStoreConvert(getEffectiveData(data), function() {
				return true;
			}).sort(function(a, b) {
				return a.mac > b.mac ? 1 : -1;
				
			});
			var ret =[];
			for(var i = 0, len = sortData.length; i< len; i++){
				$.su.App.utils.isSameMac(sortData[i].mac, hostMac)? ret.unshift(sortData[i]): ret.push(sortData[i]);
			}
			if (ret.length > 0 && ret[0].mac === hostMac) {
				ret[0].host = true;
			}
			return ret;
		},
		proxy: "connectedClientsProxy"
	});
	$.su.storeManager.define("hostClientsStore", {
		type: "store",
		keyProperty: "mac",
		fields: [{
			name: "deviceName",
			allowBlank: false
		}, {
			name: "deviceTag"
		}, {
			name: "mac"
		}, {
			name: "ip"
		}, {
			name: "downloadSpeed"
		}, {
			name: "uploadSpeed"
		}, {
			name: "downloadLimit",
			allowBlank: false,
			vtype: "integer"
		}, {
			name: "uploadLimit",
			allowBlank: false,
			vtype: "integer"
		}, {
			name: "host",
			defaultValue: false
		}],
		convert: function(data) {
			var hostMac = $.su.serviceManager.get("device").getHostMac();
			var ret = clientsStoreConvert(getEffectiveData(data), function(item) {
				return item.blocked == "0" && item.online == "1" && (item.type == STATION_WIRE || item.type == STATION_WIRELESS_2G);
			}).sort(function(a, b) {
				return $.su.App.utils.isSameMac(b.mac, hostMac) ? 1 : -1;
			});
			if (ret.length > 0 && ret[0].mac === hostMac) {
				ret[0].host = true;
			}
			return ret;
		},
		serialize: clientsStoreSerialize,
		proxy: "connectedClientsProxy"
	});
	$.su.storeManager.define("guestClientsStore", {
		type: "store",
		keyProperty: "mac",
		fields: [{
			name: "deviceName",
			allowBlank: false
		}, {
			name: "deviceTag"
		}, {
			name: "mac"
		}, {
			name: "ip"
		}, {
			name: "downloadSpeed"
		}, {
			name: "uploadSpeed"
		}, {
			name: "downloadLimit",
			allowBlank: false,
			vtype: "integer"
		}, {
			name: "uploadLimit",
			allowBlank: false,
			vtype: "integer"
		}],
		convert: function(data) {
			return clientsStoreConvert(getEffectiveData(data), function(item) {
				return item.blocked == "0" && item.online == "1" && item.type == STATION_GUESTNETWORK_2G;
			})
		},
		serialize: clientsStoreSerialize,
		proxy: "connectedClientsProxy"
	});
	$.su.define("connectedClientsProxy", {
		extend: "MERProxy",
		blocks: STARTTABLE_DATA_ID,
		instrs: {
			edit: {
				instr: "main staMgt -add",
				fields: [
					{name: "mac"},
					{name: "name", filter: encodeURIComponent},
					{name: "upload"},
					{name: "download"}
				]
			},
			del: {
				instr: "main staMgt -add",
				fields: [
					{name: "mac"},
					{name: "name", filter: encodeURIComponent},
					{name: "upload"},
					{
						name: "download",
						filter: function(value) {
							return value + " blocked";
						}
					}
				]
			}
		}
	});
	$.su.storeManager.define("blockedClientsStore", {
		type: "store",
		keyProperty: "mac",
		fields: [{
			name: "deviceName",
			allowBlank: false
		}, {
			name: "deviceTag"
		}, {
			name: "mac"
		}, {
			name: "ip"
		}],
		convert: function(data) {
			return clientsStoreConvert(getEffectiveData(data), function(item) {
				return item.blocked == "1";
			})
		},
		serialize: clientsStoreSerialize,
		proxy: "blockedClientsProxy"
	});
	$.su.define("blockedClientsProxy", {
		extend: "MERProxy",
		blocks: STARTTABLE_DATA_ID,
		instrs: {
			edit: {
				instr: "main staMgt -add",
				fields: [
					{name: "mac"},
					{name: "name", filter: encodeURIComponent},
					{name: "upload"},
					{
						name: "download",
						filter: function(value) {
							return value + " blocked";
						}
					}
				]
			},
			del: {
				instr: "main staMgt -add",
				fields: [
					{name: "mac"},
					{name: "name", filter: encodeURIComponent},
					{name: "upload"},
					{name: "download"}
				]
			}
		}
	});

	$.su.define("allClientsProxy", {
		extend: "MERProxy",
		blocks: STARTTABLE_DATA_ID
	});

	function getEffectiveData(data) {
		var list = data.list;
		var result = [];
		var deviceMode = Number($.su.serviceManager.get("device").getCurrentMode());
		var needFilterDhcp = deviceMode === SYSTEM_MODE_AP || deviceMode === SYSTEM_MODE_RE;
		var ipToFilter = null; 
		if(needFilterDhcp){
			$.su.serviceManager.get("ajax").request({
				proxy: "lanDhcpIpProxy",
				ajax:{
					async: false
				},
				method: "instrGet",
				success: function(dhcpIp){
					ipToFilter = $.appUtils.ipToInt(dhcpIp)
				}
			});
		}
		for (var i = 0; i < list.length; i++) {
			var item = list[i];
			if (item.mac.length == 0 || item.mac === "00-00-00-00-00-00") {
				break;
			}
			if(needFilterDhcp && $.appUtils.ipToInt(item.ip) === ipToFilter){
				continue;
			}
			item.mac = item.mac.toUpperCase();
			item.deviceType = ["pc", "phone"][item.deviceType];
			result.push(item);
		}
		return result;
	}
	function clientsStoreConvert(data, filter) {
		var result = [];
		var getDeviceTag = function(data) {
			if (data.online == 0) {
				return "offline";
			}
			if (item.type == STATION_WIRE) {
				return "wired";
			}
			if (item.type == STATION_WIRELESS_2G) {
				return "wireless2g";
			}
			if (item.type == STATION_WIRELESS_5G) {
				return "wireless5g";
			}
			if (item.type == STATION_GUESTNETWORK_2G) {
				return "guest2g";
			}
			if (item.type == STATION_GUESTNETWORK_5G) {
				return "guest5g";
			}
			return "wired";
		};
		for (var i = 0; i < data.length; i++) {
			var item = data[i];
			// 允许连接设备
			if (filter(item)) {
				result.push({
					ip: item.ip,
					mac: item.mac,
					downloadSpeed: parseInt(item.down / 1024, 10),
					uploadSpeed: parseInt(item.up / 1024, 10),
					downloadLimit: parseInt(item.downLimit / 1024, 10),
					uploadLimit: parseInt(item.upLimit / 1024, 10),
					deviceName: item.name || $.su.CHAR.BASIC_DEVICE.UNKNOWN,
					deviceTag: getDeviceTag(item)
				});
			}
		}
		return result;
	}
	function clientsStoreSerialize(data) {
		for (var i = 0; i < data.length; i++) {
			// 不能data[i] = {}
			// key会丢失
			data[i].name = data[i].deviceName;
			data[i].upload = checkType(data[i].uploadLimit) ? data[i].uploadLimit * 1024 : 0;
			data[i].download = checkType(data[i].downloadLimit) ? data[i].downloadLimit * 1024 : 0;
		}
		function checkType (val) {
			var type = typeof val;
			return type === "number" || type === "string";
		}
		return data;
	}
	
	
		
	$.su.define("linkTypeProxy", {
		extend: "MERProxy",
		blocks: [LINK_DATA_ID]
	});

	
    $.su.define("networkWanAndLanStatusProxy", {
        extend: "MERProxy",
        blocks: IPV6_LAN_STATUS_DATA_ID
    });
})(jQuery);

