//@ sourceURL=modules/basicDevice/controllers.js

/*
 * @description @module basicDevice
 * @author
 * @change
 *
 * */
(function ($) {
	$.su.moduleManager.define("basicDevice", {
		services: ["timer", "ajax", "device", "moduleRouter"],
		models: ["accessControl", "accessControlEnableM"],
		stores: ["connectedClientsStore", "blacklistGridStore"],
		deps: [],
		views: ["basicDeviceView"],
		listeners: {
			"ev_on_launch": function(e, me, views, models, stores, deps, services) {
				this.unRegisterAutoSaveData([
					stores.connectedClientsStore,
					models.accessControl,
					models.accessControlEnableM
				]);
				this.initAccessControl().then(function(){
					me.initClients();
				});
			},
			"ev_before_destroy": function(e, me) {}
		},
		init: function (me, views, models, stores, deps, services) {
			this.configViews({
				id: "basicDeviceView",
				items: [{
					id: "connected-clients-grid",
					configs: {
						popEditor: {
							content: "#connected-clients-grid-popEditor",
							fields: [
								{ name: "deviceName" }
							]
						},
						columns: [{
							dataIndex: "deviceName",
							cls: "m-hide l-hide xl-hide label-empty"
						}, {
							dataIndex: "mac",
							cls: "m-hide l-hide xl-hide label-empty",
							renderer: function(val, rawVal) {
								var inHTML = "";
								var hostCls = rawVal.host ? " host" : "";
								inHTML += "<div class=\"device-type-container widget-container\">";
								inHTML += "<span class=\"icon icon-" + "pc" + hostCls + " \"></span>";
								// inHTML += "<span class=\"icon icon-" + me.getBrandName(rawVal.mac).toLowerCase() + hostCls + " \"></span>";
								inHTML += "</div>";
								var mac = rawVal.mac;
								var ip = rawVal.ip;
								inHTML += "<div class=\"device-info-container widget-container\">";
								inHTML += "<div class=\"mac\">" + mac + "</div>";
								inHTML += "<div class=\"ip\">" + ip + "</div>";
								inHTML += "</div>";
								return inHTML;
							}
						}, {
							text: $.su.CHAR.BASIC_DEVICE.TYPE,
							width: 130,
							dataIndex: "mac",
							cls: "s-hide",
							renderer: function(val, rawVal) {
								var inHTML = "";
								var hostCls = rawVal.host ? " host" : "";
								inHTML += "<div class=\"device-type-container widget-container\">";
								inHTML += "<span class=\"icon icon-" + "pc" + hostCls + " \"></span>";
								// inHTML += "<span class=\"icon icon-" + me.getBrandName(rawVal.mac).toLowerCase() + hostCls + " \"></span>";
								inHTML += "</div>";
								return inHTML;
							}
						}, {
							text: $.su.CHAR.BASIC_DEVICE.INFORMATION,
							dataIndex: "deviceName",
							cls: "s-hide",
							renderer: function(val, rawVal) {
								var inHTML = "";
								if ($.type(rawVal) === "object") {
									var deviceName = rawVal.deviceName;
									var mac = rawVal.mac;
									var ip = rawVal.ip;
									inHTML += "<div class=\"device-info-container widget-container\">";
									inHTML += "<div class=\"name\" title=\"" + deviceName + "\">" + deviceName + "</div>";
									inHTML += "<div class=\"mac\">" + mac + "</div>";
									inHTML += "<div class=\"ip\">" + ip + "</div>";
									inHTML += "</div>";
								}
								return inHTML;
							}
						}, {
							text: $.su.CHAR.BASIC_DEVICE.CONNECTION,
							dataIndex: "deviceTag",
							renderer: function(val, rawVal) {
								var inHTML = "";
								inHTML += "<div class=\"connection-container widget-container\">";
								inHTML += me.tagToText(val);
								inHTML += "</div>";
								return inHTML;
							}
						}, {
							text: $.su.CHAR.BASIC_DEVICE.OPERATION,
							xtype: "actioncolumn",
							renderer: function(val, rawVal) {
								var inHTML = "";
								inHTML += "<a href=\"javascript:void(0)\" class=\"grid-content-btn grid-content-btn-edit btn-edit\">";
								inHTML +=   "<span class=\"icon\"></span>";
								inHTML +=   "<span class=\"text\"></span>";
								inHTML += "</a>";

								var blockIcon = rawVal.host ? "btn-block-grey" : "btn-block";
								inHTML += "<a href=\"javascript:void(0)\" class=\"grid-content-btn " + blockIcon + "\">";
								inHTML +=   "<span class=\"icon\"></span>";
								inHTML +=   "<span class=\"text\"></span>";
								inHTML += "</a>";
								return inHTML;
							}
						}]
					}
				}]
			});
			this.listen({
			})
			this.control({
				"#connected-clients-grid": {
					"ev_grid_edit": function(e, key) {
						services.timer.clearInterval(this, this.clientsInterval);
					},
					"ev_grid_save": function(e) {
						this.initClients();
					},
					"ev_grid_cancel": function(e) {
						this.initClients();
					}
				},
				"#connected-clients-grid => .btn-block": {
					"ev_grid_action_click": function(e, key) {
						this.blockKey = key;
						views.blockConfirmMsg.show();
					}
				},
				"#map-clients-access-control-btn": {
					"ev_button_click": function(e) {
						services.moduleRouter.goTo("accessControl");
					}
				},
				"#block-confirm-msg": {
					"ev_msg_ok": function(e) {
						this.blockDevice();
					}
				}
			});
		}
	}, function (me, views, models, stores, deps, services) {
		return {
			clientsInterval: null,
			initAccessControl: function() {
				this.blacklistMap = {};
				var enableDfd = $.Deferred();
				var modeDfd = $.Deferred();
				var blackListDfd = $.Deferred();
				models.accessControlEnableM.load({
					success: function () {
						enableDfd.resolve();
					}
				});
				models.accessControl.load({
					success: function() {
						if (models.accessControl.accessMode.getValue() === "black") {
							views.mapClientsAccessControlBtn.setText($.su.CHAR.NETWORK_MAP.VIEW_BLACKLIST);
						} else {
							views.mapClientsAccessControlBtn.setText($.su.CHAR.NETWORK_MAP.VIEW_WHITELIST);
						}
						modeDfd.resolve();
					}
				})
				this.getBlackListMap({
					success: function(){
						blackListDfd.resolve();
					}
				});
				return $.when(enableDfd, modeDfd, blackListDfd);
			},
			getBlackListMap: function(options) {
				options = options || {};
				stores.blacklistGridStore.load({
					success: function(data) {
						var blacklistData = stores.blacklistGridStore.getData();
						me.blacklistMap = {};
						$.each(blacklistData, function(i, device) {
							me.blacklistMap[device.mac.toUpperCase()] = i;
						});
						options.success && options.success(data);
					}
				});
			},
			initClients: function() {
				services.timer.clearInterval(this, this.clientsInterval);
				this.clientsInterval = services.timer.setInterval(this, function() {
					me.loadClients();
				}, 5000, true);
			},
			loadClients: function(loadAccessControl) {
				services.ajax.request({
					proxy: "allClientsProxy",
					method: "read",
					success: function(data) {
						if (!me.isRunning()) {
							return;
						}
						var getClients = function(data) {
							data.list = me.filterGridByAccessControl(data.list);
							stores.connectedClientsStore.loadData(data, true);
						}
						if (loadAccessControl) {
							me.getBlackListMap({
								success: function() {
									getClients(data);
								}
							});
						} else {
							getClients(data);
						}

					}
				});
			},
			
			blockDevice: function() {
				var data = stores.connectedClientsStore.getModelByKey(this.blockKey).getData();
				// 如果access control未开启，则会开启access control并切换黑名单模式
				// 自动开启并切换 可能导致block设备时和原本黑名单中的条目冲突
				// 因此如果是自动开启并切换，添加黑名单设备时需要检查是否存在冲突
				var needCheck = false;
				var addBlackList = function(){
					stores.blacklistGridStore.addDevice({
						data: {
							mac: data.mac,
							name: data.deviceName
						},
						success: function() {
							me.loadClients(true);
						}
					});
				};
				var blockDeviceAfterCheck = function(){
					if(me.blacklistMap.hasOwnProperty(data.mac.toUpperCase())){
						me.loadClients(true);
					}else{
						addBlackList();
					}
				};
				if (models.accessControlEnableM.enable.getValue() !== "on") {
					models.accessControlEnableM.toggle("on",
					{
						success: function(){
							models.accessControlEnableM.load();
						}
					});
					needCheck = true;
				}
				if (models.accessControl.accessMode.getValue() !== "black") {
					models.accessControl.switchMode("black",
					{
						success: function(){
							models.accessControl.load();
						}
					});
					needCheck = true;
					views.mapClientsAccessControlBtn.setText($.su.CHAR.NETWORK_MAP.VIEW_BLACKLIST);
				}
				if(needCheck){
					blockDeviceAfterCheck();
				}else{
					addBlackList();
				}
				
				
			},
			tagToText: function(val) {
				switch (val) {
					case "wireless2g":
						return $.su.CHAR.BASIC_DEVICE.WIRELESS + " ("+ $.su.CHAR.BASIC_DEVICE.G24 + ")";
					case "wireless5g":
						return $.su.CHAR.BASIC_DEVICE.WIRELESS + " ("+ $.su.CHAR.BASIC_DEVICE.G5 + ")";
					case "guest2g":
						return $.su.CHAR.BASIC_DEVICE.GUEST + " ("+ $.su.CHAR.BASIC_DEVICE.G24 + ")";
					case "guest5g":
						return $.su.CHAR.BASIC_DEVICE.GUEST + " ("+ $.su.CHAR.BASIC_DEVICE.G5 + ")";
					case "wired":
						return $.su.CHAR.BASIC_DEVICE.WIRED;
					case "offline":
						return $.su.CHAR.BASIC_DEVICE.OFFLINE;
					default:
						return $.su.CHAR.BASIC_DEVICE.WIRED;
				}
			},
			convertByte: function(speed) {
				var unit;
				var kSpeed = 1024;
				var mSpeed = kSpeed * 1024;
				var gSpeed = mSpeed * 1024;
				if (speed >= gSpeed) {
					speed = speed / gSpeed;
					unit = $.su.CHAR.BASIC_DEVICE.GBPS
				} else if (speed >= mSpeed) {
					speed = speed / mSpeed;
					unit = $.su.CHAR.BASIC_DEVICE.MBPS
				} else if (speed >= kSpeed) {
					speed = speed / kSpeed;
					unit = $.su.CHAR.BASIC_DEVICE.KBPS
				} else {
					unit = $.su.CHAR.BASIC_DEVICE.BPS
				}
				return {
					speed: speed ? speed.toFixed(1): speed,
					unit: unit
				};
			},
			parseLimitRate: function(speedObj) {
				var speed = speedObj.speed;
				var unit = speedObj.unit;
				var result = {};
				if(speed) {
					result.speed = speed;
					result.unit = unit;
				} else {
					result.speed = "---";
					result.unit = $.su.CHAR.BASIC_DEVICE.KBPS;
				}
				return result;
			},
			getBrandName: function(mac) {
				var brandArr = [
					/*{name:"TP-LINK", mac:"00-0A-EB,00-14-78,00-19-E0,00-1D-0F,00-21-27,00-23-CD,00-25-86,00-27-19,08-57-00,0C-72-2C,0C-82-68,10-FE-ED,14-75-90,14-86-92,14-CC-20,14-CF-92,14-E6-E4,1C-FA-68,20-DC-E6,28-2C-B2,30-B5-C2,38-83-45,3C-46-D8,40-16-9F,50-BD-5F,50-C7-BF,54-C8-0F,54-E6-FC,5C-63-BF,5C-89-9A,60-E3-27,64-56-01,64-66-B3,64-70-02,6C-E8-73,74-EA-3A,78-A1-06,80-89-17,88-25-93,8C-21-0A,90-AE-1B,90-F6-52,94-0C-6D,9C-21-6A,A0-F3-C1,A8-15-4D,A8-57-4E,B0-48-7A,BC-D1-77,C0-4A-00,C0-61-18,C4-6E-1F,C4-E9-84,CC-34-29,D0-C7-C0,D4-01-6D,D8-15-0D,D8-5D-4C,E0-05-C5,E4-D3-32,E8-94-F6,E8-DE-27,EC-17-2F,EC-26-CA,EC-88-8F,F0-F3-36,F4-EC-38,F4-F2-6D,F8-1A-67,F8-D1-11,FC-D7-33"},*/
					{
						name: "Apple",
						mac: "00-03-93,00-05-02,00-0A-27,00-0A-95,00-0D-93,00-10-FA,00-11-24,00-14-51,00-16-CB,00-17-F2,00-19-E3,00-1B-63,00-1C-B3,00-1D-4F,00-1E-52,00-1E-C2,00-1F-5B,00-1F-F3,00-21-E9,00-22-41,00-23-12,00-23-32,00-23-6C,00-23-DF,00-24-36,00-25-00,00-25-4B,00-25-BC,00-26-08,00-26-4A,00-26-B0,00-26-BB,00-30-65,00-3E-E1,00-50-E4,00-61-71,00-88-65,00-A0-40,00-C6-10,00-F4-B9,00-F7-6F,04-0C-CE,04-15-52,04-1E-64,04-26-65,04-48-9A,04-54-53,04-DB-56,04-E5-36,04-F1-3E,04-F7-E4,08-00-07,08-70-45,08-74-02,0C-15-39,0C-30-21,0C-3E-9F,0C-4D-E9,0C-74-C2,0C-77-1A,0C-BC-9F,10-1C-0C,10-40-F3,10-41-7F,10-93-E9,10-9A-DD,10-DD-B1,14-10-9F,14-5A-05,14-8F-C6,14-99-E2,18-20-32,18-34-51,18-9E-FC,18-AF-61,18-AF-8F,18-E7-F4,18-EE-69,18-F6-43,1C-1A-C0,1C-AB-A7,1C-E6-2B,20-78-F0,20-7D-74,20-A2-E4,20-C9-D0,24-24-0E,24-A0-74,24-A2-E1,24-AB-81,24-E3-14,28-0B-5C,28-37-37,28-5A-EB,28-6A-B8,28-6A-BA,28-CF-DA,28-CF-E9,28-E0-2C,28-E1-4C,28-E7-CF,28-F0-76,2C-1F-23,2C-B4-3A,2C-BE-08,2C-F0-EE,30-10-E4,30-90-AB,30-F7-C5,34-12-98,34-15-9E,34-36-3B,34-51-C9,34-A3-95,34-C0-59,34-E2-FD,38-0F-4A,38-48-4C,38-C9-86,3C-07-54,3C-15-C2,3C-AB-8E,3C-D0-F8,3C-E0-72,40-30-04,40-33-1A,40-3C-FC,40-6C-8F,40-A6-D9,40-B3-95,40-D3-2D,44-2A-60,44-4C-0C,44-D8-84,44-FB-42,48-43-7C,48-60-BC,48-74-6E,48-D7-05,48-E9-F1,4C-7C-5F,4C-8D-79,4C-B1-99,50-7A-55,50-EA-D6,54-26-96,54-72-4F,54-9F-13,54-AE-27,54-E4-3A,54-EA-A8,58-1F-AA,58-55-CA,58-B0-35,5C-59-48,5C-8D-4E,5C-95-AE,5C-96-9D,5C-97-F3,5C-F5-DA,5C-F9-38,60-03-08,60-33-4B,60-69-44,60-92-17,60-C5-47,60-D9-C7,60-F8-1D,60-FA-CD,60-FB-42,60-FE-C5,64-20-0C,64-76-BA,64-9A-BE,64-A3-CB,64-B9-E8,64-E6-82,68-09-27,68-5B-35,68-64-4B,68-96-7B,68-9C-70,68-A8-6D,68-AE-20,68-D9-3C,6C-3E-6D,6C-40-08,6C-70-9F,6C-94-F8,6C-C2-6B,70-11-24,70-14-A6,70-3E-AC,70-56-81,70-73-CB,70-CD-60,70-DE-E2,70-E7-2C,70-EC-E4,74-81-14,74-E1-B6,74-E2-F5,78-31-C1,78-3A-84,78-6C-1C,78-7E-61,78-9F-70,78-A3-E4,78-CA-39,78-D7-5F,78-FD-94,7C-11-BE,7C-6D-62,7C-6D-F8,7C-C3-A1,7C-C5-37,7C-D1-C3,7C-F0-5F,7C-FA-DF,80-00-6E,80-49-71,80-92-9F,80-BE-05,80-E6-50,80-EA-96,84-29-99,84-38-35,84-78-8B,84-85-06,84-8E-0C,84-B1-53,84-FC-FE,88-1F-A1,88-53-95,88-63-DF,88-C6-63,88-CB-87,8C-00-6D,8C-29-37,8C-2D-AA,8C-58-77,8C-7B-9D,8C-7C-92,8C-FA-BA,90-27-E4,90-3C-92,90-72-40,90-84-0D,90-8D-6C,90-B2-1F,90-B9-31,90-FD-61,94-94-26,94-E9-6A,94-F6-A3,98-03-D8,98-5A-EB,98-B8-E3,98-D6-BB,98-E0-D9,98-F0-AB,98-FE-94,9C-04-EB,9C-20-7B,9C-35-EB,9C-F3-87,9C-FC-01,A0-18-28,A0-99-9B,A0-ED-CD,A4-31-35,A4-5E-60,A4-67-06,A4-B1-97,A4-C3-61,A4-D1-D2,A8-20-66,A8-5B-78,A8-66-7F,A8-86-DD,A8-88-08,A8-8E-24,A8-96-8A,A8-BB-CF,A8-FA-D8,AC-29-3A,AC-3C-0B,AC-7F-3E,AC-87-A3,AC-CF-5C,AC-FD-EC,B0-34-95,B0-65-BD,B0-9F-BA,B4-18-D1,B4-F0-AB,B8-09-8A,B8-17-C2,B8-78-2E,B8-8D-12,B8-C7-5D,B8-E8-56,B8-F6-B1,B8-FF-61,BC-3B-AF,BC-4C-C4,BC-52-B7,BC-67-78,BC-92-6B,C0-1A-DA,C0-63-94,C0-84-7A,C0-9F-42,C0-CE-CD,C0-F2-FB,C4-2C-03,C8-1E-E7,C8-2A-14,C8-33-4B,C8-6F-1D,C8-85-50,C8-B5-B7,C8-BC-C8,C8-E0-EB,C8-F6-50,CC-08-E0,CC-29-F5,CC-78-5F,CC-C7-60,D0-03-4B,D0-23-DB,D0-25-98,D0-33-11,D0-4F-7E,D0-A6-37,D0-E1-40,D4-9A-20,D4-F4-6F,D8-00-4D,D8-1D-72,D8-30-62,D8-96-95,D8-9E-3F,D8-A2-5E,D8-BB-2C,D8-CF-9C,D8-D1-CB,DC-2B-61,DC-37-14,DC-86-D8,DC-9B-9C,E0-66-78,E0-AC-CB,E0-B5-2D,E0-B9-BA,E0-C9-7A,E0-F5-C6,E0-F8-47,E4-25-E7,E4-8B-7F,E4-98-D6,E4-C6-3D,E4-CE-8F,E8-04-0B,E8-06-88,E8-80-2E,E8-8D-28,EC-35-86,EC-85-2F,F0-24-75,F0-99-BF,F0-B4-79,F0-C1-F1,F0-CB-A1,F0-D1-A9,F0-DB-E2,F0-DB-F8,F0-DC-E2,F0-F6-1C,F4-1B-A1,F4-37-B7,F4-F1-5A,F4-F9-51,F8-1E-DF,F8-27-93,FC-25-3F,FC-E9-98,FC-FC-48"
					},
					{
						name: "Samsung",
						mac: "00-00-F0,00-02-78,00-07-AB,00-09-18,00-0D-AE,00-0D-E5,00-12-47,00-12-FB,00-13-77,00-15-99,00-15-B9,00-16-32,00-16-6B,00-16-6C,00-16-DB,00-17-C9,00-17-D5,00-18-AF,00-1A-8A,00-1B-98,00-1C-43,00-1D-25,00-1D-F6,00-1E-7D,00-1E-E1,00-1E-E2,00-1F-CC,00-1F-CD,00-21-19,00-21-4C,00-21-D1,00-21-D2,00-23-39,00-23-3A,00-23-99,00-23-C2,00-23-D6,00-23-D7,00-24-54,00-24-90,00-24-91,00-24-E9,00-25-38,00-25-66,00-25-67,00-26-37,00-26-5D,00-26-5F,00-73-E0,00-E0-64,00-E3-B2,00-F4-6F,04-18-0F,04-1B-BA,04-FE-31,08-08-C2,08-37-3D,08-3D-88,08-D4-2B,08-EC-A9,08-EE-8B,08-FC-88,08-FD-0E,0C-14-20,0C-71-5D,0C-89-10,0C-B3-19,0C-DF-A4,10-1D-C0,10-30-47,10-3B-59,10-77-B1,10-92-66,10-D3-8A,10-D5-42,14-32-D1,14-49-E0,14-89-FD,14-A3-64,14-B4-84,14-F4-2A,18-16-C9,18-1E-B0,18-22-7E,18-26-66,18-3A-2D,18-3F-47,18-46-17,18-67-B0,18-83-31,18-E2-C2,1C-5A-3E,1C-62-B8,1C-66-AA,1C-AF-05,20-13-E0,20-64-32,20-6E-9C,20-D3-90,20-D5-BF,24-4B-03,24-4B-81,24-C6-96,24-DB-ED,24-F5-AA,28-98-7B,28-BA-B5,28-CC-01,2C-44-01,30-19-66,30-C7-AE,30-CD-A7,30-D5-87,30-D6-C9,34-23-BA,34-31-11,34-AA-8B,34-BE-00,34-C3-AC,38-01-95,38-01-97,38-0A-94,38-0B-40,38-16-D1,38-2D-D1,38-94-96,38-AA-3C,38-EC-E4,3C-5A-37,3C-62-00,3C-8B-FE,3C-A1-0D,40-0E-85,44-4E-1A,44-6D-6C,44-F4-59,48-44-F7,4C-3C-16,4C-A5-6D,4C-BC-A5,50-01-BB,50-32-75,50-56-BF,50-85-69,50-A4-C8,50-B7-C3,50-CC-F8,50-F0-D3,50-F5-20,50-FC-9F,54-40-AD,54-88-0E,54-92-BE,54-9B-12,54-FA-3E,58-C3-8B,5C-0A-5B,5C-2E-59,5C-3C-27,5C-A3-9D,5C-E8-EB,5C-F6-DC,60-6B-BD,60-77-E2,60-8F-5C,60-A1-0A,60-AF-6D,60-D0-A9,64-6C-B2,64-77-91,64-B3-10,64-B8-53,68-05-71,68-48-98,68-EB-AE,6C-2F-2C,6C-83-36,6C-B7-F4,6C-F3-73,70-F9-27,74-45-8A,74-5F-00,78-1F-DB,78-25-AD,78-40-E4,78-47-1D,78-52-1A,78-59-5E,78-9E-D0,78-A8-73,78-AB-BB,78-BD-BC,78-D6-F0,78-F7-BE,7C-F8-54,7C-F9-0E,80-18-A7,80-4E-81,80-57-19,84-0B-2D,84-11-9E,84-25-DB,84-2E-27,84-38-38,84-51-81,84-55-A5,84-A4-66,88-32-9B,88-9B-39,8C-71-F8,8C-77-12,8C-BF-A6,8C-C8-CD,90-00-DB,90-18-7C,90-F1-AA,94-01-C2,94-35-0A,94-51-03,94-63-D1,94-D7-71,98-0C-82,98-1D-FA,98-52-B1,98-83-89,9C-02-98,9C-3A-AF,9C-65-B0,9C-D3-5B,9C-E6-E7,A0-07-98,A0-0B-BA,A0-21-95,A0-75-91,A0-82-1F,A0-B4-A5,A4-9A-58,A4-EB-D3,A8-06-00,A8-7C-01,A8-9F-BA,A8-F2-74,AC-36-13,AC-5A-14,B0-C4-E7,B0-C5-59,B0-D0-9C,B0-DF-3A,B0-EC-71,B4-07-F9,B4-3A-28,B4-62-93,B4-79-A7,B4-EF-39,B8-5A-73,B8-5E-7B,B8-6C-E8,B8-C6-8E,B8-D9-CE,BC-14-85,BC-20-A4,BC-44-86,BC-47-60,BC-72-B1,BC-79-AD,BC-85-1F,BC-8C-CD,BC-B1-F3,C0-65-99,C0-BD-D1,C4-42-02,C4-50-06,C4-57-6E,C4-62-EA,C4-73-1E,C4-88-E5,C8-14-79,C8-19-F7,C8-7E-75,C8-A8-23,C8-BA-94,CC-05-1B,CC-07-AB,CC-3A-61,CC-F9-E8,CC-FE-3C,D0-17-6A,D0-22-BE,D0-59-E4,D0-66-7B,D0-C1-B1,D0-DF-C7,D4-87-D8,D4-88-90,D4-E8-B2,D8-31-CF,D8-57-EF,D8-90-E8,DC-71-44,E0-99-71,E0-CB-EE,E0-DB-10,E4-12-1D,E4-32-CB,E4-40-E2,E4-58-E7,E4-7C-F9,E4-92-FB,E4-B0-21,E4-E0-C5,E4-F8-EF,E8-03-9A,E8-11-32,E8-4E-84,E8-50-8B,E8-E5-D6,EC-1F-72,EC-E0-9B,F0-08-F1,F0-25-B7,F0-5A-09,F0-6B-CA,F0-72-8C,F0-E7-7E,F4-09-D8,F4-7B-5E,F4-9F-54,F4-D9-FB,F8-04-2E,F8-84-F2,F8-D0-BD,FC-00-12,FC-19-10,FC-1F-19,FC-8F-90,FC-A1-3E,FC-C7-34"
					},
					{
						name: "LG",
						mac: "00-05-C9,00-0B-29,00-12-56,00-14-80,00-19-A1,00-1C-62,00-1E-75,00-1E-B2,00-1F-6B,00-1F-E3,00-21-FB,00-22-A9,00-24-83,00-25-E5,00-26-E2,00-50-CE,00-AA-70,00-E0-91,0C-48-85,10-68-3F,10-F9-6F,1C-08-C1,20-21-A5,2C-54-CF,30-76-6F,34-4D-F7,34-FC-EF,3C-BD-D8,3C-CD-93,3C-E6-24,40-B0-FA,48-59-29,50-55-27,58-3F-54,58-A2-B5,5C-17-D3,64-89-9A,64-99-5D,6C-D0-32,6C-D6-8A,70-05-14,74-A7-22,88-C9-D0,8C-3A-E3,8C-54-1D,94-44-44,98-93-CC,98-D6-F7,A0-39-F7,A8-16-B2,A8-92-2C,B0-61-C7,B0-89-91,B0-98-9F,B4-0E-DC,BC-F5-AC,C0-41-F6,C4-36-6C,C4-43-8F,C4-9A-02,C8-02-10,C8-08-E9,CC-2D-8C,CC-FA-00,E8-5B-5B,E8-92-A4,E8-F2-E2,EC-2E-4E,F0-18-2B,F0-1C-13,F8-0C-F3,F8-95-C7,F8-A9-D0"
					},
					{
						name: "Lenovo",
						mac: "00-06-1B,00-12-FE,00-59-07,14-36-C6,14-9F-E8,1C-56-FE,20-76-93,44-80-EB,50-3C-C4,5C-51-88,60-99-D1,60-D9-A0,6C-5F-1C,70-72-0D,74-04-2B,80-CF-41,88-70-8C,98-FF-D0,A4-8C-DB,AC-38-70,C8-DD-C9,CC-07-E4,D4-22-3F,D8-71-57,E0-2C-B2,E4-90-7E,E8-91-20,EC-89-F5,F8-CF-C5"
					},
					{
						name: "HuaWei",
						mac: "00-18-82,00-1E-10,00-22-A1,00-25-68,00-25-9E,00-46-4B,00-66-4B,00-E0-FC,04-BD-70,04-C0-6F,04-F9-38,08-19-A6,08-63-61,08-7A-4C,08-E8-4F,0C-37-DC,0C-96-BF,10-1B-54,10-47-80,10-51-72,10-C6-1F,14-B9-68,18-C5-8A,1C-1D-67,1C-8E-5C,20-08-ED,20-0B-C7,20-2B-C1,20-F3-A3,24-09-95,24-69-A5,24-7F-3C,24-9E-AB,24-DB-AC,28-31-52,28-3C-E4,28-5F-DB,28-6E-D4,30-87-30,30-D1-7E,30-F3-35,34-00-A3,34-6B-D3,34-CD-BE,38-F8-89,3C-47-11,3C-DF-BD,3C-F8-08,40-4D-8E,40-CB-A8,44-55-B1,48-46-FB,48-62-76,4C-1F-CC,4C-54-99,4C-8B-EF,4C-B1-6C,50-9F-27,54-39-DF,54-89-98,54-A5-1B,58-1F-28,58-2A-F7,58-7F-66,5C-4C-A9,5C-7D-5E,5C-B3-95,5C-B4-3E,5C-F9-6A,60-DE-44,60-E7-01,64-16-F0,64-3E-8C,68-8F-84,68-A0-F6,70-54-F5,70-72-3C,70-7B-E8,70-A8-E3,74-88-2A,74-A0-63,78-1D-BA,78-6A-89,78-D7-52,78-F5-FD,7C-60-97,7C-A2-3E,80-38-BC,80-71-7A,80-B6-86,80-D0-9B,80-FB-06,84-A8-E4,84-DB-AC,88-53-D4,88-86-03,88-A2-D7,88-CE-FA,88-E3-AB,8C-34-FD,90-17-AC,90-4E-2B,90-67-1C,94-04-9C,94-77-2B,9C-28-EF,9C-37-F4,9C-C1-72,A4-99-47,AC-4E-91,AC-85-3D,AC-E2-15,AC-E8-7B,B0-5B-67,B4-15-13,B4-30-52,B8-BC-1B,BC-25-E0,BC-76-70,C0-70-09,C4-05-28,C4-07-2F,C8-D1-5E,CC-53-B5,CC-96-A0,CC-A2-23,CC-CC-81,D0-2D-B3,D0-7A-B5,D4-6A-A8,D4-6E-5C,D4-B1-10,D4-F9-A1,D8-49-0B,DC-D2-FC,E0-19-1D,E0-24-7F,E0-97-96,E4-68-A3,E8-08-8B,E8-CD-2D,EC-23-3D,EC-CB-30,F4-55-9C,F4-9F-F3,F4-C7-14,F4-DC-F9,F4-E3-FB,F8-01-13,F8-3D-FF,F8-4A-BF,F8-BF-09,F8-E8-11,FC-48-EF,FC-E3-3C"
					},
					{
						name: "ZTE",
						mac: "00-15-EB,00-19-C6,00-1E-73,00-22-93,00-25-12,00-26-ED,08-18-1A,0C-12-62,14-60-80,18-44-E6,20-89-86,2C-26-C5,2C-95-7F,30-0C-23,30-F3-1D,34-4B-50,34-4D-EA,34-DE-34,34-E0-CF,38-46-08,38-D8-2F,3C-DA-2A,44-F4-36,48-28-2F,4C-09-B4,4C-16-F1,4C-AC-0A,4C-CB-F5,54-22-F8,68-1A-B2,6C-8B-2F,6C-A7-5F,70-9F-2D,78-31-2B,78-66-AE,78-E8-B6,84-74-2A,8C-79-67,8C-E0-81,90-1D-27,94-A7-B7,98-6C-F5,98-F5-37,9C-A9-E4,9C-D2-4B,A0-EC-80,A4-7E-39,A8-A6-68,B0-75-D5,B4-98-42,B4-B3-62,C8-64-C7,C8-7B-5B,CC-1A-FA,CC-7B-35,D0-15-4A,D0-5B-A8,D4-37-D7,D8-55-A3,D8-74-95,DC-02-8E,E0-C3-F3,E4-77-23,EC-1D-7F,EC-8A-4C,F0-84-C9,F4-6D-E2,F4-B8-A7,F8-DF-A8,FC-C8-97"
					},
					{
						name: "Coolpad",
						mac: "00-16-6D,18-DC-56,EC-5A-86"
					},
					{
						name: "XiaoMi",
						mac: "00-9E-C8,0C-1D-AF,14-F6-5A,18-59-36,28-E3-1F,34-80-B3,64-09-80,64-B4-73,68-DF-DD,74-51-BA,7C-1D-D9,8C-BE-BE,98-FA-E3,9C-99-A0,A0-86-C6,AC-F7-F3,C4-6A-B7,D4-97-0B,F0-B4-29,F8-A4-5F"
					},
					{
						name: "MeiZu",
						mac: "38-BC-1A,68-3E-34"
					},
					{
						name: "Google",
						mac: "00-1A-11,3C-5A-B4,54-60-09,94-EB-2C,A4-77-33,F4-03-04,F4-F5-E8,F8-8F-CA"
					},
					{
						name: "Microsoft",
						mac: "00-03-FF,00-0D-3A,00-12-5A,00-15-5D,00-17-FA,00-1D-D8,00-22-48,00-25-AE,00-50-F2,0C-41-3E,0C-E7-25,10-2F-6B,14-9A-10,20-62-74,20-A9-9B,28-18-78,2C-29-97,30-0D-43,30-59-B7,3C-83-75,48-50-73,48-86-E8,4C-0B-BE,50-1A-C5,60-45-BD,74-E2-8C,7C-1E-52,7C-ED-8D,80-C5-E6,84-63-D6,9C-6C-15,B4-AE-2B,B8-4F-D5,C0-33-5E,D0-92-9E,D4-8F-33,DC-B4-C4,EC-59-E7"
					},
					{
						name: "Nokia",
						mac: "00-02-EE,00-0B-E1,00-0E-ED,00-0F-BB,00-10-B3,00-11-9F,00-12-62,00-13-70,00-13-FD,00-14-A7,00-15-2A,00-15-A0,00-15-DE,00-16-4E,00-16-BC,00-17-4B,00-17-B0,00-18-0F,00-18-42,00-18-8D,00-18-C5,00-19-2D,00-19-4F,00-19-79,00-19-B7,00-1A-16,00-1A-89,00-1A-DC,00-1B-33,00-1B-AF,00-1B-EE,00-1C-35,00-1C-9A,00-1C-D4,00-1C-D6,00-1D-3B,00-1D-6E,00-1D-98,00-1D-E9,00-1D-FD,00-1E-3A,00-1E-3B,00-1E-A3,00-1E-A4,00-1F-00,00-1F-01,00-1F-5C,00-1F-5D,00-1F-DE,00-1F-DF,00-21-08,00-21-09,00-21-AA,00-21-AB,00-21-FC,00-21-FE,00-22-65,00-22-66,00-22-FC,00-22-FD,00-23-B4,00-24-03,00-24-04,00-24-7C,00-24-7D,00-25-47,00-25-48,00-25-CF,00-25-D0,00-26-68,00-26-69,00-26-CC,00-40-43,00-BD-3A,00-E0-03,04-5A-95,04-A8-2A,0C-C6-6A,0C-DD-EF,10-F9-EE,14-36-05,14-C1-26,18-14-56,18-86-AC,20-D6-07,28-47-AA,28-D1-AF,2C-5A-05,2C-CC-15,2C-D2-E7,30-38-55,34-7E-39,34-C8-03,38-19-2F,3C-18-9F,3C-25-D7,3C-36-3D,3C-C2-43,3C-F7-2A,40-7A-80,48-DC-FB,4C-25-78,4C-7F-62,50-2D-1D,54-44-08,54-79-75,5C-57-C8,60-A8-FE,6C-9B-02,6C-A7-80,6C-E9-07,70-8D-09,78-2E-EF,78-92-3E,78-CA-04,80-50-1B,88-44-F6,90-CF-15,94-00-70,94-20-53,94-3A-F0,9C-18-74,9C-4A-7B,9C-CA-D9,A0-4E-04,A0-71-A9,A0-F4-19,A4-77-60,A4-81-EE,A4-E7-31,A8-44-81,A8-7B-39,A8-7E-33,A8-E0-18,AC-81-F3,AC-93-2F,B0-35-8D,B0-5C-E5,BC-C6-DB,C0-38-F9,C0-64-C6,C8-3D-97,C8-97-9F,C8-D1-0B,C8-DF-7C,CC-89-FD,D0-DB-32,D4-5D-42,D4-93-98,D4-C1-FC,D4-CB-AF,D8-2A-7E,D8-75-33,D8-EF-CD,DC-3E-F8,DC-9F-A4,DC-C7-93,DC-F1-10,E0-A6-70,E4-EC-10,E8-15-0E,E8-CB-A1,EC-9B-5B,EC-F3-5B,F4-8E-09,F4-F5-A5,F8-5F-2A,FC-92-3B,FC-E5-57"
					},
					{
						name: "Sony",
						mac: "00-00-95,00-01-4A,00-04-1F,00-0A-D9,00-0E-07,00-0F-DE,00-12-EE,00-13-15,00-13-A9,00-15-C1,00-16-20,00-16-B8,00-18-13,00-19-63,00-19-C5,00-1A-75,00-1A-80,00-1B-59,00-1C-A4,00-1D-0D,00-1D-28,00-1D-BA,00-1E-45,00-1E-DC,00-1F-A7,00-1F-E4,00-21-9E,00-22-98,00-22-A6,00-23-45,00-23-F1,00-24-8D,00-24-BE,00-24-EF,00-25-E7,00-D9-D1,00-EB-2D,08-00-46,0C-FE-45,18-00-2D,1C-7B-21,20-54-76,24-21-AB,28-0D-FC,30-17-C8,30-39-26,30-75-12,30-A8-DB,30-F9-ED,3C-07-71,40-2B-A1,40-B8-37,44-74-6C,44-D4-E0,4C-21-D0,54-42-49,54-53-ED,58-17-0C,58-48-22,5C-B5-24,68-76-4F,6C-0E-0D,6C-23-B9,70-9E-29,78-84-3C,84-00-D2,84-8E-DF,8C-64-22,90-C1-15,94-CE-2C,A0-E4-53,A8-E3-EE,AC-9B-0A,B4-52-7D,B4-52-7E,B8-F9-34,BC-6E-64,C4-3A-BE,D0-51-62,D8-D4-3C,E0-63-E5,F0-BF-97,F8-D0-AC,FC-0F-E6,FC-F1-52"
					},
					{
						name: "HTC",
						mac: "00-09-2D,00-23-76,00-EE-BD,04-C2-3E,18-87-96,1C-B0-94,2C-8A-72,38-E7-D8,50-2E-5C,64-A7-69,7C-61-93,80-01-84,84-7A-88,90-21-55,90-E7-C4,98-0D-2E,A0-F4-50,A8-26-D9,B4-CE-F6,BC-CF-CC,D4-0B-1A,D4-20-6D,D8-B3-77,E8-99-C4,F8-DB-7F"
					},
					{
						name: "HP",
						mac: "00-1B-3F,00-1C-2E,00-1D-B3,00-1F-28,00-1F-FE,00-21-F7,00-23-47,00-24-A8,00-25-61,00-26-F1,B4-39-D6,C0-91-34,F0-62-81"
					},
					{
						name: "Dell",
						mac: "00-06-5B,00-08-74,00-0B-DB,00-0D-56,00-0F-1F,00-11-43,00-12-3F,00-13-72,00-14-22,00-15-C5,00-16-F0,00-18-8B,00-19-B9,00-1A-A0,00-1C-23,00-1D-09,00-1E-4F,00-1E-C9,00-21-70,00-21-9B,00-22-19,00-23-AE,00-24-E8,00-25-64,00-26-B9,00-B0-D0,00-C0-4F,10-98-36,14-FE-B5,18-03-73,18-A9-9B,18-FB-7B,1C-40-24,20-47-47,24-6E-96,24-B6-FD,34-17-EB,34-E6-D7,44-A8-42,4C-76-25,54-9F-35,5C-26-0A,5C-F9-DD,64-00-6A,74-86-7A,74-E6-E2,78-2B-CB,78-45-C4,84-2B-2B,84-8F-69,90-B1-1C,98-90-96,A4-1F-72,A4-BA-DB,B0-83-FE,B8-2A-72,B8-AC-6F,B8-CA-3A,BC-30-5B,C8-1F-66,D0-43-1E,D0-67-E5,D4-AE-52,D4-BE-D9,E0-DB-55,EC-F4-BB,F0-1F-AF,F0-4D-A2,F8-B1-56,F8-BC-12,F8-DB-88"
					},
					{
						name: "Acer",
						mac: "00-00-E2,00-01-24,00-60-67,00-A0-60,C0-98-79"
					},
					{
						name: "Toshiba",
						mac: "00-00-39,00-06-00,00-08-0D,00-0E-7B,00-15-B7,00-1C-7E,00-23-18,24-2F-FA,88-73-84,98-6D-C8,B8-6B-23,E8-9D-87,E8-E0-B7,EC-21-E5,F4-64-5D"
					},
					{
						name: "Hasee",
						mac: "00-22-C0"
					},
					{
						name: "ASUS",
						mac: "00-04-0F,00-0C-6E,00-0E-A6,00-11-2F,00-11-D8,00-13-D4,00-15-F2,00-17-31,00-18-F3,00-1A-92,00-1B-FC,00-1D-60,00-1E-8C,00-1F-C6,00-22-15,00-23-54,00-24-8C,00-26-18,00-E0-18,08-60-6E,08-62-66,10-BF-48,10-C3-7B,14-DA-E9,14-DD-A9,1C-B7-2C,20-CF-30,30-85-A9,38-2C-4A,40-16-7E,48-5B-39,50-46-5D,54-04-A6,54-A0-50,60-A4-4C,74-D0-2B,78-24-AF,90-E6-BA,AC-22-0B,AC-9E-17,BC-AE-C5,BC-EE-7B,C8-60-00,D8-50-E6,E0-3F-49,E0-CB-4E,F0-79-59,F4-6D-04,FC-C2-33"
					},
					{
						name: "Vivo",
						mac: "10-12-12,B8-07-16,3C-A5-81,70-78-8B,70-47-E9,90-AD-F7,28-FA-A0,3C-B6-B7,54-19-C8,F4-B7-B3,F4-29-81,3C-A3-48,F4-29-81,3C-A3-48,28-FA-A0,3C-B6-B7,54-19-C8,F4-B7-B3,9C-A5-C0,1C-DA-27,70-D9-23,3C-A6-16,88-F7-BF,70-B7-AA,4C-C0-0A,E4-5A-A2,EC-DF-3A,F4-70-AB,28-31-66,F0-1B-6C,DC-1A-C5,9C-FB-D5,10-F6-81,20-F7-7C,9C-E8-2B,94-63-72,44-9E-F9,34-E9-11,EC-7D-11,38-6E-A2,94-14-7A,C4-66-99,FC-1A-11,E0-DD-C0,88-6A-B1,18-E2-9F,08-23-B2,60-91-F3,BC-2F-3D,C4-AB-B2"
					},
					{
						name: "Oppo",
						mac: "9C-0C-DF,D4-1A-3F,A0-93-47,C8-F2-30,1C-77-F6,E4-47-90,D4-50-3F,88-D5-0C,E8-BB-A8,BC-3A-EA,8C-0E-E3,6C-5C-14,EC-F3-42,DC-55-83,1C-42-7D,50-29-F5,08-4A-CF,1C-DD-EA,18-D7-17,B4-CB-57,44-04-44,C0-9F-05,CC-2D-83,38-29-5A,4C-1A-3D,A8-1B-5A,DC-6D-CD,78-36-CC,14-C6-97,EC-51-BC,F0-79-E8,F0-6D-78,50-3C-EA,58-7A-6A,E4-C4-83,B0-AA-36,2C-5B-B8,1C-48-CE,7C-6B-9C,1C-C3-EB,98-6F-60,4C-18-9A,3C-F5-91,60-21-01,94-D0-29,30-84-54,44-66-FC,A4-3D-78,EC-01-EE,B8-37-65"
					},
					{
						name: "other"
					}
				];
				var len = brandArr.length - 1; // except `other` brand
				var macItem, target = brandArr[len];
				mac = mac.substring(0, 8).toUpperCase();
				for (var i = 0; i < len; i++) {
					macItem = brandArr[i];
					if (macItem.mac.indexOf(mac) >= 0) {
						target = macItem;
						break;
					}
				}
				return target.name;
			},
			filterGridByAccessControl: function(devices) {
				var result = [];
				for (var i = 0; i < devices.length; i++) {
					var item = devices[i];
					item.mac = item.mac.toUpperCase();
					if (item.mac.length == 0 || item.mac === "00-00-00-00-00-00") {
						break;
					}
					if (
						models.accessControlEnableM.enable.getValue() === "on" &&
						models.accessControl.accessMode.getValue() === "black" &&
						this.blacklistMap &&
						this.blacklistMap.hasOwnProperty(item.mac)
					) {
						continue;
					}
					result.push(item);
				}
				return result;
			}
		};
	});
})(jQuery);
