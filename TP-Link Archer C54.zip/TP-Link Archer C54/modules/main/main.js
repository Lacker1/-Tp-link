//@ sourceURL=modules/main/main.js

// JavaScript Document
(function($) {
	$.su.moduleManager.define("main", {
		services: [
			"moduleRouter", "user", "ajax", "device"
		],
		models: ["localLoginControl", 'systemDataM'],
		stores: [],
		deps: [],
		views: ["main"],
		listeners: {
			"ev_on_launch": function(e, me, views, models, stores, deps, services){
				this.unRegisterAutoSaveData(models.systemDataM);

				services.device.getGdpr();  //从后台获取gdpr是否开启
				//如果有token，则可能是登录后，需要获取加密器；
				if (me.syncTokenFromStorage()) {
					//如果token有效，且及加密器有效，能顺利完成登录
					//如果token有效，但解密出错，回到登录前
					//如果token无效，后台返回密文，能解密，重新登录
					//如果token无效，后台返回密文，解密出错，回到登录前
					//token无效，后台返回明文，解密出错，回到登录前
					//token无效，后台返回明文，没做解密，重新登录
					if (services.device.getConfig().gdpr) {
						try {
							$.su.encryptor = $.encrypt.encryptManager.getEncryptor();
						} catch(e) {
							location.href = "./error.html";
						}
					}
				}
				
				var timer = setTimeout(function() {
					me.hideSplash();
				}, 600);
				services.moduleRouter.setPageContainer(views.basicModuleLoader, "main");
				services.ajax.request({
					proxy: "checkIsDefaultProxy",
					success: function(data){
						services.moduleRouter.init();
						services.device.getDomain();
						services.device.getFunctionSupport();
						models.systemDataM.load({
							success: function(data) {
								var isDefault = true;
								//初次切换其他模式也要走QS，按标识位来判断，转换成二进制
								//0000为全没有配置过，各个位依次代表router、ap、re、wisp
								isDefault = me.getResetSign(data.mode, data.setWzd);

								if (isDefault || localStorage.getItem("upgraded")) {
									services.moduleRouter.goTo("quickSetup");
								} else {
									me.loadBasicModule("index");
								}
							}
						});

					},
					fail: function(results) {
						me.updateAuthInfo(results);
						me.loadLoginPage();
					}
				});
			},
			"ev_login_timeout": function(){
				this.onLoginTimeout();
			}
		},
		init: function(me, views, models, stores, deps, services) {
			this.control({
				"#global-confirm": {
					"ev_msg_ok": function() {
						me.globalConfirmSuccessCallback && me.globalConfirmSuccessCallback.call();
						me.globalConfirmSuccessCallback = null;
					},
					"ev_msg_no": function() {
						me.globalConfirmFailCallback && me.globalConfirmFailCallback.call();
						me.globalConfirmFailCallback = null;
					}
				}
			});
		}
	}, function(me, views, models, stores, deps, services) {
		var me = this;
		return {
			waitingId: false,
			waitingTime: 20 * 1000,
			loadBasicModule: function(name, callback) {
				views.basicModuleLoader.loadChildModule({
					module: name
				}).then(callback);
			},
			splashTime: 1000,
			showSplash: function(){
				views.splash.show();
			},
			hideSplash: function(){
				views.splash.fadeOut(400);
			},
			showError: function(msg) {
				if (msg) {
					views.globalError.setContent(msg);
					views.globalError.show();
				}
			},
			startReboot: function(duration,others){
				duration = duration || services.device.getRebootTime();
				var me = this;
				views.rebootMsg.show(function() {
					views.rebootProgress.animate({
						duration: duration,
						percentageStart: 0,
						percentageEnd: 100,
						callback: function() {
							me.checkReboot();
							!!others && others();
						}
					});
				});
			},
			checkReboot: function(){
				views.rebootMsg.hide();

			},
			showNotice: function(text, type){
				views.globalNotice.show(text, type);
			},
			hideNotice: function(time){
				views.globalNotice.hide(time);
			},
			checkLogin: function(){

			},
			login: function(pwd, success, fail) {
				models.localLoginControl.getProxy().auth({
					pwd: pwd,
					success: function(data, ret) {
						var session = $.su.encrypt($.authInfo[3], pwd, $.authInfo[4]);
						if (localStorage) {
							me.setToken(session);
							me.setPwd(pwd);
						}
						success && success.call();
					},
					fail: function (data, errorcode) {
						fail && fail.apply(me, arguments);
					},
					error: function () {
						fail && fail.apply(me, arguments);
					}
				});
			},
			updateAuthInfo: function(results) {
				$.authInfo = $.authInfo || [];
				var authInfo = $.authInfo;
				authInfo[1] = results[0];
				authInfo[2] = results[1];
				authInfo[3] = results[2];
				authInfo[4] = results[3];
			},
			getLocalTmpKey: function() {
				var dfd = $.Deferred();
				services.ajax.request({
					proxy: "checkIsDefaultProxy",
					method: "getLoginParams",
					fail: function(results) {
						me.updateAuthInfo(results);
						dfd.resolve();
					}
				});
				return dfd.promise();
			},
			getCloudTmpKey: function () {
				var dfd = $.Deferred();
				services.ajax.request({
					proxy: "getCloudTmpKeyProxy",
					fail: function (results) {
						me.updateAuthInfo(results);
						dfd.resolve();
					}
				});
				return dfd.promise();
			},
			cloudAuthWithId: function (cloudAuth) {
				var dfd = $.Deferred();
				services.ajax.request({
					proxy: "cloudAuthProxy",
					method: "auth",
					options: {
						data: {
							cloudAuth: cloudAuth
						}
					},
					success: function (data) {
						var session = $.su.encrypt($.authInfo[3], cloudAuth, $.authInfo[4]);
						me.setToken(session);
						me.setCloudAuth(cloudAuth);
						dfd.resolve();
					},
					fail: function () {
						dfd.reject();
					},
					error: function () {
						dfd.reject();
					}
				});
				return dfd.promise();
			},
			isCloudLogin: function() {
				return !!this.getCloudAuth();
			},
			resetEncryptor: function(user, pwd) {
				var dfd = $.Deferred();
				var RESEND_TIMES = 3;
				var RESEND_DELAY = 5 * 1000;
				var count = 0;
				var resendInterval;
				if (services.device.getConfig().gdpr) {
					var encryptor = $.encrypt.encryptManager.getEncryptor() || $.encrypt.encryptManager.genEncryptor();
					var getParams = function() {
						services.ajax.request({
							proxy: "gdprProxy",
							method: "getParams",
							preventErrorEvent: true,
							preventFailEvent: true,
							success: function(data) {
								clearInterval(resendInterval);
								encryptor.setRSAKey(data.nn, data.ee);
								encryptor.setSeq(data.seq);
								encryptor.genAESKey();
								encryptor.setHash(user, pwd); //TODO not in use
								$.encrypt.encryptManager.recordEncryptor();
								dfd.resolve();
							}
						});
					};
					getParams();
					resendInterval = setInterval(function() {
						if (++count > RESEND_TIMES) {
							clearInterval(resendInterval);
							dfd.reject();
							$.su.raise({
								msg: "ev_ajax_error",
								type: "ajax_error"
							});
							return;
						}
						getParams();
					}, RESEND_DELAY);
					
				} else{
					dfd.resolve();
				}
				return dfd.promise();
			},
			syncEncryptor: function() {
				var dfd = $.Deferred();
				if (services.device.getConfig().gdpr) {
					var encryptor = $.encrypt.encryptManager.getEncryptor();
					services.ajax.request({
						proxy: "gdprProxy",
						method: "setParams",
						data: encryptor.getEncodeAESKey(),
						success: function(data) {
							dfd.resolve();
						}
					});
				} else{
					dfd.resolve();
				}
				return dfd.promise();
			},
			//重启后需要重新设置加密器并同步给后台
			resetAndSyncEncryptor: function() {
				var dfd = $.Deferred();
				var me = this;
				if (services.device.getConfig().gdpr) {
					me.resetEncryptor("admin", "").then(function() {
						me.syncEncryptor().then(function() {
							$.su.encryptor = $.encrypt.encryptManager.getEncryptor();
							dfd.resolve();
						});
					}, function () {
						dfd.reject();
					});
				} else {
					dfd.resolve();
				}
				return dfd.promise();
			},
			setPwd: function(value){
				localStorage.setItem("lgkey", value);
			},
			setCloudAuth: function (value) {
				localStorage.setItem("cloudkey", value);
			},
			getPwd: function() {
				return localStorage.getItem("lgkey");
			},
			getCloudAuth: function (value) {
				return localStorage.getItem("cloudkey");
			},
			setToken: function(value){
				//处理特殊字符如"zyrq[9y.eZsrc0*g8sZTD8!Ogquvu<]"
				localStorage.setItem("token", $.su.encodePara(value));
				$.su.url.session = value;
			},
			clearAuthToken: function () {
				localStorage.setItem("lgkey", "");
				localStorage.setItem("cloudkey", "");
				localStorage.setItem("token", "");
				$.su.url.session= "";
			},
			getResetSign: function(mode, wzd){
				return ('0000'+(parseInt(wzd).toString(2))).slice(-4).split("")[mode-1] == 0;
			},
			setResetSign: function(value) {
				models.systemDataM.load({
					success: function() {
						var wzd = models.systemDataM.setWzd.getValue();
						var mode = services.device.getCurrentMode();
						var tmp = value == 0 ? value : (wzd | [0,8,4,2,1][mode]);
						models.systemDataM.setWzd.setValue(tmp);
						models.systemDataM.submit();
					}
				});
			},
			syncTokenFromStorage: function(){
				var token =  $.su.decodePara(localStorage.getItem("token"));
				$.su.url.session = token;
				return token;
			},
			onLoginTimeout: function(){
				me.loadLoginPage();
			},
			logout: function(url) {
				this.clearAuthToken();
				location.href = url || "/";
			},
			loadLoginPage: function(){
				this.clearAuthToken();
				me.loadBasicModule("login");
			},
			noReferrerRedirect: function(url){
				this.clearAuthToken();
				url = url || ("http://" + services.device.getDomain());
				$("body").append("<a rel='nofollow noopener noreferrer' id='jump_link' target='_self' href='" + url + "'></a>");
				$("#jump_link")[0].click();
			},
			reload: function(){
				location.href = "/";
			},
			showMask: function(){
				views.transparentMask.show('global-trans-mask');
			},
			hideMask: function(){
				views.transparentMask.hide('global-trans-mask');
			},
			confirm: function(msg, success, fail, yesText, cancelText) {
				if (msg) {
					views.globalConfirm.setContent(msg);
					views.globalConfirm.show();
					views.globalConfirm.setButtonText('ok', yesText || $.su.CHAR.OPERATION.YES_UPPERCASE);
					views.globalConfirm.setButtonText('no', cancelText || $.su.CHAR.OPERATION.CANCEL_UPPERCASE);
					me.globalConfirmSuccessCallback = success || function() {};
					me.globalConfirmFailCallback = fail  || function() {};
				}
			},
			alert: function(msg) {
				if (msg) {
					views.globalAlert.setContent(msg);
					views.globalAlert.show();
				}
			},
			showLoading: function(text) {
				views.loadingMsg.show();
				views.loadingText.setText(text);
			},
			hideLoading: function() {
				views.loadingMsg.hide();
			},
			setWaitingEvent: function (eType, obj, waitingTime) {
				me.waitingId = false;
				var time = waitingTime || me.waitingTime;
				var obj = obj || window;
				obj = obj.jquery ? obj : $(obj);
				me.waitingId = setTimeout(function () {
					obj.trigger(eType);
				}, time);
				return true; // setWaiting success
			},
			clearWaitingEvent: function () {
				if (me.waitingId) {
					clearTimeout(me.waitingId);
					me.waitingId = false;
				}
			},
			showProBar: function (text) {
				views.proBar.reset();
				views.proBarTitle.setText(text);
				views.progressbarWrap.show();
			},
			hideProBar: function () {
				views.progressbarWrap.hide();
			},
			setProBarValue: function (value, time) {
				views.proBar.setValue(value, time);
			},
			setProBarAnimate: function (options) {
				views.proBar.animate(options);
			},
			showErrorCodeMsg: function (errorCode, fn) {
				!!fn && fn();
				var err = errorCode;
				if (err) {
					err = 'E' + err;
					var infos = $.su.CHAR.CLOUD_ERROR_CODE[err];
					if (infos) {
						views.globalError.setContent(infos);
						views.globalError.show();
					}
				}
			}
		};
	});
})(jQuery);
