//@ sourceURL=modules/main/models.js

$.su.define('checkIsDefaultProxy', {
    extend: 'MERProxy',
    preventFailEvent: true,
    reAuth: false,
    gdpr: false,
    ajax: {
        async: false
    },
    url: $.su.url("?code="+ TDDP_AUTH + "&asyn=1", "loginCheck"),
    getLoginParams: function(options) {
        options.url = $.su.url("?code="+ TDDP_READ + "&asyn=1", "loginCheck", false);
        options.gdpr = false;
        this.op("default", options);
    },
    failFilter: function(data){
        var results;
        var relCnt = data;

        if (relCnt.lastIndexOf("\r\n") == relCnt.length - 2)
        {
            relCnt = relCnt.substring(0, relCnt.length - 2);
        }

        results = relCnt.split("\r\n");

        return results;
    }
});

$.su.define('getRemoteProxy', {
    extend: 'MERProxy',
    reAuth: false,
    preventFailEvent: true,
    ajax: {
        async: false
    },
    getRemote: function(options) {
        var mainModule = $.su.moduleManager.query("main");
        var isCloudLogin = mainModule && mainModule.isCloudLogin();
        options.url = $.su.url(("?code="+ (isCloudLogin ? CLOUD_TMP : TDDP_READ) + "&asyn=1"), "loginCheck", false);
        options.gdpr = false;
        if (isCloudLogin) {
            options.data = "get";
        }
        options.failFilter = function(data){
            var results;
            var relCnt = data;
            if (relCnt.lastIndexOf("\r\n") == relCnt.length - 2)
            {
                relCnt = relCnt.substring(0, relCnt.length - 2);
            }
            results = relCnt.split("\r\n");
            return results[4];
        };
        this.op("default", options);
    }
    
});

$.su.define('getRoleProxy', {
    extend: 'MERProxy',
    preventFailEvent: true,
    blocks: CLOUD_CURRENT_USER_CFG_DATA_ID,
    ajax: {
        async: false
    },
    readFilter: function(data) {
        return data.role
    }
});

$.su.modelManager.define("systemDataM", {
    type: "model",
    fields: [{
        name: "setWzd"
    }],
    proxy: {
        ajax: {
            async: false
        },
        blocks: [SYSTEM_DATA_ID]
    }
});


$.su.define("deviceDataProxy", {
    extend: "MERProxy",
    blocks: DEVICE_DATA_ID,
    preventFailEvent: true
});

$.su.define("timeServiceProxy", {
    extend: "MERProxy",
    blocks: [SNTPC_CONFIG_DATA_ID, SNTPC_TIME_DATA_ID],
    preventSuccessEvent: true,
    preventFailEvent: true,
    readFilter: function(data) {
        data = $.extend({}, data[SNTPC_CONFIG_DATA_ID], data[SNTPC_TIME_DATA_ID]);
        return {
            hour24Enable: data.timedisplay == '0' ? "on" : "off",
            time: (data.hour < 10 ? ('0' + data.hour) : data.hour) + ":" + (data.minute < 10 ? ('0' + data.minute):data.minute) + ":" + (data.second < 10 ? ('0' + data.second):data.second),
            date: (data.month < 10 ? ('0' + data.month) : data.month) + "/" + (data.day < 10 ? ('0' + data.day):data.day) + "/" + data.year
        };
    }
});
$.su.define("languageProxy", {
    extend: "MERProxy",
    blocks: [LANGUAGE_DATA_ID],
    setLocale: function(options) {
        var data = {
            currentLanguage: options.data.locale
        };
        this.write($.extend(options, {
            data: data,
            addId: true
        }));
    }
});
$.su.define("deviceModeProxy", {
    extend: "MERProxy",
    blocks: SYSTEM_DATA_ID,
    preventFailEvent: true
});

$.su.define("switchModeProxy", {
    extend: "MERProxy",
    switchMode: function(options) {
        options.url = $.su.url("?code=" + TDDP_CHGMODE + "&asyn=0&mode="+options.data.mode);
        options.data = "1";
        return this.op("urlRequest", options);
    }
});

$.su.define("getPeerMacProxy", {
    url: $.su.url("?code=" + TDDP_GETPEERMAC + "&asyn=0"),
    preventFailEvent: true,
    extend: "MERProxy",
    readFilter: function(data) {
        return $.trim(data).toUpperCase();
    }
});

$.su.define("tokenInstr", {
    extend: "MERProxy",
    preventSuccessEvent: true,
    ajax: {
        async: false
    },
    tokenRead: function (options) {
        options.data = "main cloud -devMgt_getToken";
        return this.instr(options);
    },
    loginTokenRead: function (options) {
        options.data = "main cloud -devMgt_getToken";
        options.url = $.su.url("?code=" + CLOUD_AUTH + "&asyn=0");
        return this.op("instr", options);
    }
});

$.su.define("tokenProxyIndex", {
    extend: "MERProxy",
    blocks: [CLOUD_CURRENT_USER_CFG_DATA_ID]
});

$.su.define("deviceInfoProxyIndex", {
    extend: "MERProxy",
    blocks: [CLOUD_CURRENT_USER_CFG_DATA_ID, DEVICE_DATA_ID, CLOUD_CURRENT_USER_DATA_ID]
});

$.su.define("deviceInfoWithoutUserProxy", {
    extend: "MERProxy",
    blocks: [CLOUD_CURRENT_USER_CFG_DATA_ID, DEVICE_DATA_ID]
});

$.su.define("languageProxy", {
    extend: "MERProxy",
    blocks: [LANGUAGE_DATA_ID],
    setLocale: function(options) {
        var data = {
            currentLanguage: options.data.locale
        };
        this.write($.extend(options, {
            data: data,
            addId: true
        }));
    }
});

$.su.define("checkNetConnProxy", {
    extend: "MERProxy",
    blocks: [LINK_STATUS_DATA_ID]
});

$.su.define("checkCloudLoginProxy", {
    extend: "MERProxy",
    preventSuccessEvent: true,
    blocks: [CLOUD_CURRENT_USER_CFG_DATA_ID]
});
$.su.define("linkStatusProxy", {
    extend: "MERProxy",
    preventSuccessEvent: true,
    blocks: [LINK_STATUS_DATA_ID]
});
$.su.define('firmwareProxy', {
    extend: 'MERProxy',
    blocks: [CLOUD_FW_UPGRADE_DATA_ID],
    preventFailEvent: true,
    preventErrorEvent: true,
    seUpgraded: function(options) {
        var data = {
            upgraded: options.data.upgraded
        };
        this.write($.extend(options, {
            data: data,
            addId: true
        }));
    },
    readFilter: function(data) {
        return {
            upgraded:  data.upgraded == 1
        };
    }
});

$.su.define("cloudLoginProxy", {
    extend: "MERProxy",
    cloudLogin: function (options) {
        options.data = "main cloud -account_login needBind:" + (options.data || "1");
        return this.instr(options);
    }
});

$.su.define("gdprProxy", {
    extend: "MERProxy",
    gdpr: false,
    getEnable: function(options) {
        options.url = $.su.url("?code="+ HTTP_OP_GDPRCFG +"&asyn=0", "gdprEnable");
        options.data = "enable";
        this.op("default", options);
    },
    getParams: function(options) {
        options.url = $.su.url("?code="+ HTTP_OP_GDPRCFG +"&asyn=0");
        options.data = "get";
        options.readFilter = function(data) {
            data = data.split('\r\n');
            return {
                ee: data[0],
                nn: data[1],
                seq: data[2]
            }
        };
        this.op("default", options);
    },
    setParams: function(options) {
        options.url = $.su.url("?code="+ HTTP_OP_GDPRCFG +"&asyn=0");
        options.data = "set " + options.data;
        this.op("default", options);
    }
});

$.su.define('getCloudTmpKeyProxy', {
    extend: 'MERProxy',
    preventFailEvent: true,
    gdpr: false,
    reAuth: false,
    url: $.su.url("?code=" + CLOUD_TMP + "&asyn=0"),
    failFilter: function (data) {
        var results;
        var relCnt = data;

        if (relCnt.lastIndexOf("\r\n") == relCnt.length - 2) {
            relCnt = relCnt.substring(0, relCnt.length - 2);
        }

        results = relCnt.split("\r\n");

        return results;
    }
});

$.su.define("cloudAuthProxy", {
    extend: "MERProxy",
    gdpr: false,
    auth: function (option) {
        option = option || {};
        var cloudAuth = option.data.cloudAuth || "";
        var url = "?code=" + CLOUD_TMP + "&asyn=0";
        var session = $.su.encrypt($.authInfo[3], cloudAuth, $.authInfo[4]);
        url += ("&id=" + $.su.encodePara(session));
        option.url = $.su.url(url);
        delete option.data;
        this.op("urlRequest", option);
    }
});

$.su.define("checkCloudOwner", {
    extend: "MERProxy",
    blocks: [CLOUD_OWNER_DATA_ID]
});

$.su.define("rebootIPProxy", {
    extend: "MERProxy",
    blocks: [LAN_DATA_ID, TPDOMAIN_DATA_ID]
});
$.su.define('getFuncSupportProxy', {
    extend: 'MERProxy',
    preventFailEvent: true,
    blocks: WEB_SWITCH_DATA_ID,
    ajax: {
        async: false
    }
});

$.su.define("setAuthKeyProxy", {
    extend: "MERProxy",
    preventFailEvent: true,
    setAuth: function(option) { 
        option = option|| {};
        var url = "?code="+ HTTP_OP_AUTHKEY +"&asyn=0";
        var pwd = option.data;
        var RSAParams = $.su.serviceManager.get('device').getRSAParams();
        option.url = $.su.url(url);
        option.data = $.su.RSAencrypt(pwd, [RSAParams.nn, RSAParams.ee]);
        this.op("urlRequest", option);
    }
});