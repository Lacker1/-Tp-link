//@ sourceURL=modules/networkBasic/wisp/models.js

$.su.modelManager.define("wispInternet", {
    type: "model",
    fields: [{
      name: "bBridgeEnabled"
    }, {
      name: "mac",
      allowBlank: false
    }, {
      name: "cSsid",
      vtype: "string_visible_allow_blank",
      maxLength: 32,
      allowBlank: false
    }, {
      name: "hidden"
    }, {
      name: "security"
    }, {
      name: "cPskSecret",
      // vtype: "psk_password",
      allowBlank: false,
      maxLength: 64
    }/*, {
      name: "cKeyVal",
      allowBlank: false
    }*/],
    convert: function (result) {
      var apcData = result.apc;

      var data = {
        bBridgeEnabled: apcData.bBridgeEnabled,
        cSsid: apcData.cBridgedSsid,
        mac: apcData.cBridgedBssid,
        security: apcData.uSecurityType,
        cPskSecret: apcData.cPassWD
        // cKeyVal: apcData.uWepIndex
      };

      return data;
    },
    serialize: function (result) {
      var data = {
        id: WLAN_BASIC_DATA_ID,
        apc: {
          bBridgeEnabled: result.bBridgeEnabled,
          uSecurityType: result.security,
          cBridgedSsid: result.cSsid,
          cBridgedBssid: result.mac,
          cPassWD: result.cPskSecret
          // uWepIndex: result.cKeyVal
        }
      }
      return data;
    },
    proxy: {
      blocks: [WLAN_BASIC_DATA_ID+'|1,0,0']
    }
  });

  $.su.storeManager.define("wispSecuCombo", {
    type: "store",
    fields: [{
      name: "name"
    }, {
      name: "value"
    }],
    data: [{
      name: $.su.CHAR.HOST_NW.NO_SECU,
      value: WLAN_WDS_AUTH_NONE
    }, {
      name: $.su.CHAR.HOST_NW.SECU_PERSONAL,
      value: WLAN_WDS_AUTH_PSK2_AES
    }, {
      name: $.su.CHAR.HOST_NW.SECU_WEP,
      value: WLAN_WDS_AUTH_WEP_HEX
    }]
  });
