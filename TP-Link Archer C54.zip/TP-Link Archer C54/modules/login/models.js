//@ sourceURL=modules/login/localLogin/models.js

$.su.modelManager.define("localLoginControl", {
    type: "model",
    fields: [{
        name: "password",
        maxLength: 32,
        minLength: 1,
        allowBlank: false
    }],
    proxy: "localLoginProxy"
});
$.su.define("localLoginProxy", {
    extend: "MERProxy",
    reAuth: false,
    gdpr: false,
    preventFailEvent: true,
    // init: function(option) {
    //     option = option || {};
    //     var url = "?code="+ TDDP_AUTH +"&asyn=0";
    //     option.url = $.su.url(url);
    //     this.op("urlRequest", option);
    // },
    auth: function(option) {
        option = option|| {};
        var pwd = option.pwd || "";
        var url = "?code="+ TDDP_AUTH +"&asyn=0";
        var session = $.su.encrypt($.authInfo[3], pwd, $.authInfo[4]);
        url += ("&id=" + $.su.encodePara(session));
        option.url = $.su.url(url);
        this.op("urlRequest", option);
    },
    failFilter: function(data){
        var results;
        var relCnt = data;

        if (relCnt.lastIndexOf("\r\n") == relCnt.length - 2)
        {
            relCnt = relCnt.substring(0, relCnt.length - 2);
        }

        results = relCnt.split("\r\n");
        
        return results;
    }
});