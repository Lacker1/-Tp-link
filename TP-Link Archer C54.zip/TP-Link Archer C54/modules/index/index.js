//@ sourceURL=modules/index/index.js

// JavaScript Document
(function ($) {
	$.su.moduleManager.define("index", {
		services: ["moduleManager","moduleRouter", "device", "ajax"],
		models: [],
		stores: ["searchStore"],
		deps: ["navigatorController", "main"],
		views: ["index"],
		listeners: {
			"ev_on_launch": function(e, me, views, models, stores, deps, services){

				
				$("#navigator").attr("tabindex", "0");
				$(".page-content").attr("tabindex", "1");

				var productName = services.device.getProductName();
				document.title = productName;
				views.productName.setValue(productName);
				
				services.moduleRouter.setPageContainer(views.pageContainer, "index");
				deps.navigatorController.pcMainMenu = views.pcMainMenu;
				deps.navigatorController.pcSliderNavigator = views.pcSliderNavigator;
				deps.navigatorController.pageContainer = views.pageContainer;
				deps.navigatorController.loadingSimpleDom = views.pageLoadingSd;
				deps.navigatorController.loadNavigatorData();

				//需要写在navigator加载后
				if (services.device.getConfig().cloud === true) {
					//显示tplinkid的按钮,仅router模式有该功能
					if (services.device.getCurrentMode() == SYSTEM_MODE_ROUTER) {
						this.setCloudSt();
						$('.tplinkId').removeClass("hidden");  //pc web button
					}
					
					//显示upgrade按钮
					models.onlineUpgradeModel.load({
						success: function() {
							var data = models.onlineUpgradeModel.getData();
							if (!data.latestFlag) {
								$('#upgrade-button').removeClass("hidden");
							}
						}
					})
				}
				if (services.device.getConfig().search !== false) {
					//显示tplinkid的按钮,仅router模式有该功能
					$('#search-button').removeClass("hidden");  //pc web button
				}
				
			},
			"ev_after_launch": function(e, me, views, models, stores, deps, services) {
				//在ev_after_launch事件中，index的状态才是running，之后才能在加载子模块。
				// 在ev_on_launch中index的状态时available，此时如果加载子模块会认为index没加载完成，反复加载index
				var name = services.moduleRouter.getMetaPage("index") ||
					(location.hash && location.hash.substr(1)) || services.moduleRouter._getMainMenuDefaultPage();
				name === "index" && (name = services.moduleRouter._getMainMenuDefaultPage());
				//goto想去的模块名即可。goto中会做getDefaultPage
				services.moduleRouter.goTo(name);
			}

		},
		init: function (me, views, models, stores, deps, services) {
			$(window).off('ev_resize.menu').on('ev_resize.menu', function(e, widgetSize, clientWidth, oldWidgetSize) {
				if (oldWidgetSize == 's' && widgetSize != 's') {
					//if resize from s to no s, reset the pcSliderNavigator
					deps.navigatorController.pcSliderNavigatorReset();
					me.setMobileMenuStatus('close');
				} else if (oldWidgetSize != 's' && widgetSize =='s') {
					//if resize from no s to s, close the mobile menu
					me.setMobileMenuStatus('close');
				}
			});

			this.control({
				"#main-menu": {
					"ev_navigator_clicked": function (e, name) {
						if (name == "logout") {
							deps.main.confirm($.su.CHAR.INDEX.CONFIRM_LOGOUT, function() {
								me.logout();
							});
							me.setMobileMenuStatus('close');
							return;
						}
						if (name == "support") {
							window.open($('#support-link').attr('href'));
							return;
						}
						if (name == "tplinkId") {
							services.moduleRouter.goTo("tpLinkCloud");
							me.setMobileMenuStatus('close');
							return;
						}
						var module = deps.navigatorController.mainMenuClicked(name, $.su.widgetSize == 's');
						if (module && module.children && module.children.length > 0 && $.su.widgetSize == 's') {
							me.setMobileMenuStatus('level2', module.text);
						} else {
							me.setMobileMenuStatus('close');
						}
					}
				},
				"#navigator": {
					"ev_navigator_clicked": function (e, name) {
						var module = deps.navigatorController.pcNavigatorClicked(name, $.su.widgetSize == 's');
						if (!module || !module.children || module.children.length == 0) {
							me.setMobileMenuStatus('close');
						}
					}
				},
				".index-common-save-btn": {
					"ev_button_click": function (e) {
						var me = this;
						var defaultEvent = $.su.getDefaultEvent(this, function () {
							me.submitDirtyData(function () {
								$(e.target).trigger("ev_auto_saved");
							});
						});
						$(e.target).trigger("ev_will_auto_save", [defaultEvent.ev, me._toSaveArr]);
						defaultEvent.exe();
					}
				},
				"#back-to-top": {
					"ev_button_click": function () {
						$(".page-content").animate({scrollTop: '0px'}, 200);
					}
				},
				"#menu-button": {
					"click": function () {
						var btn = me.menuBtn();
						var status = btn.status();
						if (status == 'close' || status === undefined) {
							me.setMobileMenuStatus('level1');
						} else if (status == 'level2') {
							me.setMobileMenuStatus('level1');
						} else {
							me.setMobileMenuStatus('close');
						}
					}
				},
				"#search-button": {
					"ev_button_click": function () {
						services.moduleRouter.goTo("search");
					}
				},
				"#user-button": {
					"ev_button_click": function () {
						services.moduleRouter.goTo("tpLinkCloud");
					}
				},
				"#logout-button": {
					"ev_button_click": function () {
						deps.main.confirm($.su.CHAR.INDEX.CONFIRM_LOGOUT, function() {
							me.logout();
						});
					}
				},
				"#upgrade-button": {
					"ev_button_click": function() {
						services.moduleRouter.goTo("firmware");
					}
				}
			});

			this.listen();
		}
	}, function (me, views, models, stores, deps, services) {
		var dataBindInArray = function(dataBind, arr) {
			return $.inArray(dataBind, arr);
		};
		return {
			"logout": function () {
				var proxy = services.ajax.request({
					proxy: "logoutProxy",
					method: "logout",
					success: function () {
						deps.main.logout();
					},
					fail: function () {
						deps.main.logout();
					},
					error: function () {
						deps.main.logout();
					}
				});
			},
			"mobileTopBar": views.mobileTopBar,
			"menuBtn": function () {
				return views.mobileTopBar.leftBtn();
			},
			"funcBtn": function () {
				return views.mobileTopBar.rightBtn();
			},
			"setMobileMenuStatus": function (status, barText) {
				var bar = me.mobileTopBar;
				if (bar.viewObjs.length == 0) {
					return;
				}
				var leftBtn = me.menuBtn();
				var rightBtn = me.funcBtn();
				var oldStatus = leftBtn.status();
				switch (status) {
					case "level1":
						bar.setCenterText('');
						bar.addClass('menu-open');
						leftBtn.status('level1');
						rightBtn.addClass('s-hide');
						deps.navigatorController.pcSliderNavigatorReset();
						views.pcSliderNavigator.addClass('s-hide');
						views.pcMainMenu.removeClass('s-hide');
						if (oldStatus == 'close' || oldStatus == undefined) {
							views.pcMainMenu.addClass('menu-open');
							setTimeout(function () {
								views.pcMainMenu.removeClass('menu-open');
							}, 300);
						}

						break;
					case "level2":
						bar.setCenterText(barText);
						bar.addClass('menu-open');
						leftBtn.status('level2');
						rightBtn.addClass('s-hide');
						views.pcMainMenu.addClass('s-hide');
						views.pcSliderNavigator.removeClass('s-hide');
						break;
					case "close":
					default :
						if (oldStatus == 'level1') {
							views.pcMainMenu.addClass('menu-close');
							setTimeout(function () {
								views.pcMainMenu.removeClass('menu-close');
								views.pcMainMenu.addClass('s-hide');
								bar.setCenterText('');
								bar.removeClass('menu-open');
								leftBtn.status('close');
								rightBtn.removeClass('s-hide');
							}, 300);
						} else if (oldStatus == 'level2') {
							views.pcSliderNavigator.addClass('menu-close');
							setTimeout(function () {
								views.pcSliderNavigator.removeClass('menu-close');
								views.pcSliderNavigator.addClass('s-hide');
								bar.setCenterText('');
								bar.removeClass('menu-open');
								leftBtn.status('close');
								rightBtn.removeClass('s-hide');
							}, 300);
						} else {
							views.pcSliderNavigator.addClass('s-hide');
							views.pcSliderNavigator.addClass('s-hide');
							bar.setCenterText('');
							bar.removeClass('menu-open');
							leftBtn.status('close');
							rightBtn.removeClass('s-hide');
						}
						break;
				}
			},
			setCloudSt: function () {
				services.ajax.request({
					proxy: "deviceInfoProxyIndex",
					method: "read",
					success: function (data) {
						var name = data[CLOUD_CURRENT_USER_DATA_ID];
						var status = data[CLOUD_CURRENT_USER_CFG_DATA_ID];

						if (status.logInCloud == 1) {
							me.changeTPLinkID(name.curUserName);
						} else {
							me.changeTPLinkID($.su.CHAR.INDEX.TPLINK_ID);
						}
					}
				});
			},
			"_toSaveArr": [],
			"_dataCheckDirtyTimeout": {},
			"_dataAutoSaveHock": function (e) {
				var data = this;
				var index = dataBindInArray(data, me._toSaveArr);
				if (data.isDirty()) {
					if (index < 0) {
						me._toSaveArr.push(data);
					}
				} else {
					if (index >= 0) {
						me._toSaveArr.splice(index, 1);
					}
				}
				me.updateSaveBtnDisplayStatus();
			},
			"_toSaveLoadingArr": [],
			"_dataSaveLoadingHook": function (e) {
				var data = this;
				var index = dataBindInArray(data, me._toSaveLoadingArr);
				var inCommonSave = dataBindInArray(data, me._toSaveArr) >= 0;
				var isBeforeSync = e.type === "ev_model_before_submit" || e.type === "ev_store_before_sync";
				if(isBeforeSync && inCommonSave) {
					if(index < 0) {
						me._toSaveLoadingArr.push(data);
					}
				} else {
					if(index >= 0) {
						me._toSaveLoadingArr.splice(index, 1);
					}
				}
				me.updateSaveBtnLoadingStatus();
			},
			"submitDirtyData": function (callback) {
				var me = this;
				var toSaveLength = me._toSaveArr.length;
				for (var i = 0; i < toSaveLength; i++) {
					if (!!me._toSaveArr[i].validate && !me._toSaveArr[i].validate()) {
						return false;
					}
				};

				$.each(me._toSaveArr, function (index, data) {
					var defaultEvent = $.su.getDefaultEvent(data, function () {
						if (data.submit) {
							data.submit({
								success: function () {
									if (--toSaveLength === 0) {
										!!callback && callback();
									}
								}
							});
						} else {
							data.sync({
								success: function () {
									if (--toSaveLength === 0) {
										!!callback && callback();
									}
								}
							});
						}
					});
					data.trigger("ev_will_auto_save", [defaultEvent.ev]);
					defaultEvent.exe();
				});
			},
			"registerAutoSaveData": function (data) {
				// Change of dataFields will also trigger ev_data_change in Store/Model
				data.on("ev_data_change", me._dataAutoSaveHock);
				data.on("ev_data_record", me._dataAutoSaveHock);
				data.on("ev_loaded", me._dataAutoSaveHock);
				data.on("ev_model_submit", me._dataAutoSaveHock);
				data.on("ev_store_sync_success", me._dataAutoSaveHock);
			},
			"unRegisterAutoSaveData": function (data) {
				data.off("ev_data_change", me._dataAutoSaveHock);
				data.off("ev_data_record", me._dataAutoSaveHock);
				data.off("ev_loaded", me._dataAutoSaveHock);
				data.off("ev_model_submit", me._dataAutoSaveHock);
				data.off("ev_store_sync_success", me._dataAutoSaveHock);
				var index = dataBindInArray(data, me._toSaveArr);
				if (index >= 0) {
					me._toSaveArr.splice(index, 1);
				}
				me.updateSaveBtnDisplayStatus();
			},
			"updateSaveBtnDisplayStatus": $.su.debounce(function () {
				// update display of save button
				if ((me._toSaveArr.length == 0) && $.isEmptyObject(me._saveBtnManualShowHideMap)) {
					me.hideSaveBtn();
					me.hideLoadingSaveBtn();
				} else {
					me.showSaveBtn();
				}
			}, 0),
			registerSaveLoading: function(data) {
				// model
				data.on("ev_model_before_submit", me._dataSaveLoadingHook);
				data.on("ev_model_submit_complete", me._dataSaveLoadingHook);
				// store
				data.on("ev_store_before_sync", me._dataSaveLoadingHook);
				data.on("ev_store_sync_complete", me._dataSaveLoadingHook);
			},
			unRegisterSaveLoading: function(data) {
				// model
				data.off("ev_model_before_submit", me._dataSaveLoadingHook);
				data.off("ev_model_submit_complete", me._dataSaveLoadingHook);
				// store
				data.off("ev_store_before_sync", me._dataSaveLoadingHook);
				data.off("ev_store_sync_complete", me._dataSaveLoadingHook);

				var index = dataBindInArray(data, me._toSaveLoadingArr);
				if (index >= 0) {
					me._toSaveLoadingArr.splice(index, 1);
				}
				me.updateSaveBtnLoadingStatus();
			},
			updateSaveBtnLoadingStatus: $.su.debounce(function () {
				// update loading of save button
				if (me._toSaveLoadingArr.length === 0) {
					me.hideLoadingSaveBtn();
				} else {
					me.showLoadingSaveBtn();
				}
			}, 0),
			hideSaveBtn: function () {
				// views.saveButton.hide();
				$(".index-common-save-btn").addClass("hidden");
			},
			showSaveBtn: function () {
				// views.saveButton.show();
				$(".index-common-save-btn").removeClass("hidden");
			},
			disableSaveBtn: function () {
				views.saveButton.disable();
			},
			enableSaveBtn: function () {
				views.saveButton.enable();
			},
			showLoadingSaveBtn: function() {
				views.saveButton.loading(true);
			},
			hideLoadingSaveBtn: function() {
				views.saveButton.loading(false);
			},

			//keep an map which stores all the module which can not use common save
			_saveBtnManualShowHideMap: {},
			alwaysShowSaveBtn: function (name) {
				me._saveBtnManualShowHideMap[name] = true;
				this.showSaveBtn();
			},
			cancelAlwaysShowSaveBtn: function (name) {
				delete me._saveBtnManualShowHideMap[name];
				me.updateSaveBtnDisplayStatus();
			},
			showLoading: function(){
				deps.main.showMask();
				views.pageLoadingSd.show();
			},
			hideLoading: function(){
				deps.main.hideMask();
				views.pageLoadingSd.hide();
			},
			changeTPLinkID: function (name) {
				views.userButton.setText(name);
				$('.tplinkId .sub-navigator-text').html(name);
			}
		};
	});
})(jQuery);
