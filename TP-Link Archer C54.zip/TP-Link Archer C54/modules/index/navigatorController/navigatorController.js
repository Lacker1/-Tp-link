//@ sourceURL=modules/index/navigatorController/navigatorController.js

/*
 * @description navigator's control module
 *   the navigator map's item can only be valued(named) as a string, ensuring the hash map work well
 * @author KYJ
 * @change
 *   2017/06/21: create file
 *
 * */
(function($) {
    $.su.moduleManager.define("navigatorController", {
        services: ["moduleLoader","moduleRouter", "moduleManager", "ajax"],
        stores: [],
        views: [],
        deps: ["main"],
        listeners: {
        },
        init: function(me, views, models, stores, deps, services) {
            services.moduleRouter.on("ev_router_change", function(e,operation, page, path, position){
                var navigatorItems = me.getItems();
                //path不包含自己那一层
                for(var i = 0; i < path.length - 1; i ++){
                    var index = this.findItems(path[i], "name", navigatorItems);           
                    if(!index) 
                        return;
                    if(i == path.length - 2 && operation == "add"){
                        //此时page是模块的内容
                        var postion = Math.min(navigatorItems[index].children.length, Number(position));
                        navigatorItems[index].children.splice(postion, 0, page);
                    } else if(i == path.length - 2 && operation == "delete"){
                        //此时page是模块名
                        var position = this.findItems(page, "name", navigatorItems[index].children);
                        if(position)
                            navigatorItems[index].children.splice(position, 1);
                    } else {
                        navigatorItems = navigatorItems[index].children;
                    }
                }
            });
            services.moduleRouter.on("ev_sync_navigator", function(e, name, option){
                me._syncNavigatorView(name);
            });
        }
    }, function(me, views, models, stores, deps, services) {
        var MOBILE_ANIMATE_TIME = 300;
        var _hashMap = $.extend({}, services.moduleRouter.getHashMap());
        for(var i in _hashMap){
            if (_hashMap.hasOwnProperty(i)) {
                if (_hashMap[i].self.notInNavigator) {
                    delete _hashMap[i];
                }
            }
        }
        var _navigatorItems = [];

        return {
            pcMainMenu: null,
            pcSliderNavigator: null,

            initItems: function(items){
                for(var i = items.length - 1; i >=0; i --){
                    if(items[i].notInNavigator){
                        items.splice(i ,1);
                    }
                }
                return items;
            },
            //make the later search easy
            loadNavigatorData: function(callback){
                var navigatorData = services.moduleRouter.getNavigatorData();
                _navigatorItems = me.initItems(navigatorData);
                !!this.pcMainMenu && this.pcMainMenu.loadItems(this._calcMainNavigatorItems());
                !!this.pcSliderNavigator && this.pcSliderNavigator.loadItems(this._calcSliderNavigatorItems());
                if(callback) {
                    callback(_navigatorItems);
                }
                
            },

            findItems: function(items, property, array){
                for(var i = 0; i < array.length; i ++){
                    if(array[i][property] == items)
                        return i;
                }
            },
            getItems: function(){
                return _navigatorItems;
            },

            getItemsInfo: function(){
                return _hashMap;
            },
	        /**
             * reset pcSliderNavigator to currentPage, used by mobile
             */
            pcSliderNavigatorReset: function() {
                this._syncNavigatorView(services.moduleRouter.getCurrentPage());
            },
            mainMenuClicked: function(name, isMobile){
                var currentPage = services.moduleRouter.getCurrentPage();
                if (isMobile) {
                    var children = this._calcSliderNavigatorItems(name) || [];
                    if (children.length > 0) {
                        if (currentPage && _hashMap[currentPage] && _hashMap[currentPage].path[0] == name) {
                            //currentPage在name下，加入选中状态;
                            this._syncNavigatorView(currentPage);
                        } else {
                            //currentPage不在name下，只加载选项
                            this.pcSliderNavigator.loadItems(children, isMobile);
                        }
                    } else {
                        setTimeout(function() {
                            services.moduleRouter.goTo(name);
                        }, isMobile ? MOBILE_ANIMATE_TIME : 0)
                    }
                } else {
                    services.moduleRouter.goTo(name);
                }
				return _hashMap[name] && _hashMap[name].self;
            },

            pcNavigatorClicked: function(name, isMobile){
                var moduleName = _hashMap[name].self.module;
                if (services.moduleManager.hasModule(moduleName)) {
                    //一般有子菜单的模块都不存在，但也有特殊需求：自身是可用模块且有子菜单。
                    setTimeout(function() {
                        services.moduleRouter.goTo(name);
                    }, isMobile ? MOBILE_ANIMATE_TIME : 0)
                }
                return _hashMap[name].self;
            },

            _calcMainNavigatorItems: function(){
                return _navigatorItems;
            },
            _calcSliderNavigatorItems: function(mainMenuItem){
                if(!mainMenuItem){
                    return [];
                }
                var index = this.findItems(mainMenuItem, "name", _navigatorItems);
                if(index && _navigatorItems[index]["children"]) {
                    return _navigatorItems[index]["children"];
                }
            },

            _syncNavigatorView: function(name, option){
                //在index中渲染才需要做同步，即index不加载就不需要同步
                var info = _hashMap[name];
                if (!info) {
                    return;
                }
                //此处的moduleNotInMenu仅包含在index中渲染，但是又不在menu中的路由，即只有search一项
                //因为在main中渲染的东西直接覆盖了当前内容，跟菜单没有关系了
                if(info.self.notInMenu){
                    this.pcMainMenu.unSelectAll();
                    this.pcSliderNavigator.loadItems([]);
                    return;
                }
                var path = info.path;
                var pathLen = path.length;
                var currentPage = services.moduleRouter.getCurrentPage();
                
                var children = this._calcSliderNavigatorItems(path[0]);
                //如果pcSliderNavigator中的条目和children不相等，则重新渲染，这里取巧只做了指针判断，没判断具体内容
                if(this.pcSliderNavigator.getItems() !== children){
                    if(children && children.length > 0){
                        !!this.pcSliderNavigator && this.pcSliderNavigator.loadItems(children);
                    }else{
                        !!this.pcSliderNavigator && this.pcSliderNavigator.loadItems([]);
                    }
                }
                //根据路径选择打开
                switch(pathLen){
                    case 1:
                        this.pcMainMenu.select(path[0]);
                        $(".page").addClass("no-navigator");
                        !!this.pcSliderNavigator && this.pcSliderNavigator.loadItems([]);
                        break;
                    case 2:
                        //special case, ep Homecare
                        this.pcMainMenu.select(path[0]);
                        $(".page").removeClass("no-navigator");
                        if (this.pcSliderNavigator)
                        this.pcSliderNavigator.select(path[1]);
                        break;
                    case 3:
                        $(".page").removeClass("no-navigator");
                        this.pcMainMenu.select(path[0]);
                        this.pcSliderNavigator.open(path[1]);
                        this.pcSliderNavigator.select(path[2]);
                        break;
                }
            }
        };
    });
})(jQuery);
