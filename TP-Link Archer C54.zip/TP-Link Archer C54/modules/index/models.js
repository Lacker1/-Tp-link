//@ sourceURL=modules/index/models.js

$.su.storeManager.define("searchStore", {
	type: "store",
	fields: [
		{name: "name"},
		{name: "text"}
	],
	data: []
});

$.su.define("factoryRestoreProxy", {
	extend: "MERProxy",
	blocks: [FACTORY_DATA_ID, TPDOMAIN_DATA_ID],
	factoryRestore: function(options) {
		options.url = $.su.url("?code=" + TDDP_RESET + "&asyn=1");
		return this.op("urlRequest", options);
	},
	resetRestore: function(options) {
		options.url = $.su.url("?code=" + HTTP_OP_CLOUD_RESET + "&asyn=1");
		return this.op("urlRequest", options);
	}
});

$.su.define("rebootProxy", {
	extend: "MERProxy",
	reboot: function(options) {
		options.url = $.su.url("?code=" + TDDP_REBOOT + "&asyn=1");
		return this.op("urlRequest", options);
	}
});

$.su.define("logoutProxy", {
	extend: "MERProxy",
	logout: function(option) {
		option.url = $.su.url("?code="+ TDDP_LOGOUT +"&asyn=0");
		this.op("urlRequest", option);
	}
});