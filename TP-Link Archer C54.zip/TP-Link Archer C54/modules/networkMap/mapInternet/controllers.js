//@ sourceURL=modules/networkMap/mapInternet/controllers.js

/*
 * @description @module mapInternet
 * @author
 * @change
 *
 * */
(function($) {
	$.su.moduleManager.define("mapInternet", {
		services: ["ajax", "device"],
		models: ["wispInternet", "lanAdvLanModel"],
		stores: [],
		views: ["mapInternetView"],
		listeners: {
			"ev_on_launch": function(e, me, views, models, stores, deps, services) {
				if(services.device.getCurrentMode() == SYSTEM_MODE_WISP){
					views.intConnStatus.hide();
					views.wispIntConnStatus.show();
					models.wispInternet.load();
				}else{
					views.wispIntConnStatus.hide();
					views.intConnStatus.show();
				}
				if(services.device.getCurrentMode() == SYSTEM_MODE_AP){
					views.wanIpv4Ipaddr.hide();
					models.lanAdvLanModel.load();
					models.lanAdvLanModel.macaddr.show();
					models.lanAdvLanModel.customValue.show();
					models.lanAdvLanModel.ipaddr.show();
				}
			},
			"ev_before_destroy": function(e, me) {
				me.beforeDestroy();
			}
		},
		init: function(me, views, models, stores, deps, services) {
			this.configViews({
				id: "mapInternetView",
				items: [{
					id: "internet-conn-note",
					title: $.su.CHAR.NETWORK_MAP.TRY_FOLLOW,
					items: [{
						text: $.su.CHAR.NETWORK_MAP.TRY_1
					}, {
						text: $.su.CHAR.NETWORK_MAP.TRY_2
					}, {
						text: $.su.CHAR.NETWORK_MAP.TRY_3
					}, {
						text: $.su.CHAR.NETWORK_MAP.TRY_4
					}]
				}]
			});
			this.listen({

			});
			this.control({

			});
		}
	}, function(me, views, models, stores, deps, services) {
		return {
			setInternetStatus: function(data) {
				if( data.status == LINK_DOWN &&
					data.code == LINK_CODE_PHYDOWN ) {
					views.internetFieldset.hide();
					views.noInternetFieldset.show();
				} else {
					views.internetFieldset.show();
					views.noInternetFieldset.hide();
				}
				views.wanIpv4Ipaddr.setValue(data.ip);
				if (services.device.getCurrentMode() != SYSTEM_MODE_AP && !views.wanIpv4Mac.getValue()) {
					views.wanIpv4Mac.show();
					services.ajax.request({
						proxy: "getMacProxy",
						method: "read",
						success: function(data) {
							views.wanIpv4Mac.setValue(data.mac[1].toUpperCase());
						}
					});
				}
			},
			setConnectionType: function(data) {
				var str = {};
				str[LINK_TYPE_DHCP] = $.su.CHAR.WAN_ADV.DYN;
				str[LINK_TYPE_STATIC_IP] = $.su.CHAR.WAN_ADV.STATIC;
				str[LINK_TYPE_PPPOE] = $.su.CHAR.WAN_ADV.PPPOE;
				str[LINK_TYPE_L2TP] = $.su.CHAR.WAN_ADV.L2TP;
				str[LINK_TYPE_PPTP] = $.su.CHAR.WAN_ADV.PPTP;
				str[LAN_MODE_SMARTIP_AUTO] = $.su.CHAR.WAN_ADV.DYN;
				str[LAN_MODE_SMARTIP_MANUAL] = $.su.CHAR.WAN_ADV.STATIC;
				views.wanIpv4Conntype.setValue(str[data]);
			},
			beforeDestroy: function() {
			}
		};
	});
})(jQuery);

