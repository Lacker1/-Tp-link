//@ sourceURL=modules/networkMap/controllers.js

/*
 * @description @module networkMap
 * @author
 * @change
 *
 * */
(function ($) {
	$.su.moduleManager.define("networkMap", {
		services: ["ajax", "device", "timer"],
		models: [],
		stores: [],
		deps: [],
		views: ["networkMapView"],
		listeners: {
			"ev_on_launch": function(e, me, views, models, stores, deps, services) {
				switch(parseInt(services.device.getCurrentMode())){
					case SYSTEM_MODE_ROUTER:
						views.mapRouterModeLoader.load();
						break;
					case SYSTEM_MODE_AP:
						views.mapRouterModeLoader.load();
						break;
					case SYSTEM_MODE_RE:
						views.mapReModeLoader.load();
						break;
					case SYSTEM_MODE_WISP:
						views.mapWispModeLoader.load();
						break;
				}
			}
		},
		init: function (me, views, models, stores, deps, services) {
		}
	}, function (me, views, models, stores, deps, services) {
		return {
		};
	});
})(jQuery);
