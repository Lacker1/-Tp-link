//@ sourceURL=modules/networkMap/models.js

(function($) {
	var idDualband = $.su.serviceManager.get("device").getIsDualband();
	$.su.define("getMacProxy", {
		extend: "MERProxy",
		blocks: SYSTEM_DATA_ID
	});
	$.su.define("getSmartConProxy", {
		extend: "MERProxy",
		blocks: LAN_DATA_ID
	});
	$.su.define("getStatusProxy", {
		extend: "MERProxy",
		blocks: [LINK_DATA_ID, LINK_STATUS_DATA_ID]
	});
	$.su.define("wlanWdsStProxy", {
        extend: "MERProxy",
        preventSuccessEvent: true,
        instrs: {
            get: {
                instr: idDualband?"wlan wdsstatus":"wlan wdsstatus 2g"
            }
        }
    });

    $.su.define("extendMacProxy", {
		extend: "MERProxy",
		preventSuccessEvent: true,
		getMac2g: function(option) {
			option.data = "wlan getWirelessMac 2g";
			this.instr(option);
		},
		getMac5g: function(option) {
			option.data = "wlan getWirelessMac 5g";
			this.instr(option);
		}
	});
})(jQuery);

