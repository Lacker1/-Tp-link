//@ sourceURL=modules/networkMap/mapRouter/models.js

(function($){
	$.su.storeManager.define("ethernetStatusStore", {
		type: "store",
		fields: [{
			name: "type"
		}, {
			name: "status"
		}, {
			name: "speed"
		}, {
			name: "duplex"
		}, {
			name: "serial"
		}],
		convert: function(data) {
			var speedMap = {};
			speedMap[LINK_MODE_AUTO] = 0;
			speedMap[LINK_MODE_10MF] = 10;
			speedMap[LINK_MODE_10MH] = 10;
			speedMap[LINK_MODE_100MF] = 100;
			speedMap[LINK_MODE_100MH] = 100;
			speedMap[LINK_MODE_1000MF] = 1000;
			speedMap[LINK_MODE_1000MH] = 1000;

			var duplexMap = {};
			duplexMap[LINK_MODE_AUTO] = "FULL";
			duplexMap[LINK_MODE_10MF] = "FULL";
			duplexMap[LINK_MODE_10MH] = "HALF";
			duplexMap[LINK_MODE_100MF] = "FULL";
			duplexMap[LINK_MODE_100MH] = "HALF";
			duplexMap[LINK_MODE_1000MF] = "FULL";
			duplexMap[LINK_MODE_1000MH] = "HALF";

			var serialMap = {};
			serialMap[PHY_INDEX_LAN1] = 1;
			serialMap[PHY_INDEX_LAN2] = 2;
			serialMap[PHY_INDEX_LAN3] = 3;
			serialMap[PHY_INDEX_LAN4] = 4;
			serialMap[PHY_INDEX_WAN] = 0;
			serialMap[PHY_INDEX_CPU] = -1;

			var stack = [];
			for(var i = 0; i<data.list.length; i++){
				if(data.list[i].nameId != PHY_INDEX_INVALID){
					stack.push(data.list[i]);
				}
			}
			data.list = stack;
			// data.list = data.list.filter(({ nameId }) => nameId != PHY_INDEX_INVALID);

			var list = data.list.sort(function(a, b) {
				return serialMap[a.nameId] - serialMap[b.nameId];
			});
			var res = $.map(list, function(v) {
				var serial = serialMap[v.nameId];
				return {
					type: serial > 0 ? 'lan' : 'wan',
					serial: serial,
					status: v.alive == 1 ? "connected" : "disconnected",
					speed: speedMap[v.mode],
					duplex: duplexMap[v.mode]
				};
			});
			return res;
		},
		methods: {
			loadInterfaces: function(options) {
				var me = this;
				this.getProxy().instr({
					preventSuccessEvent: true,
					data: "main eth",
					success: function() {
						me.load(options);
					}
				})
			}
		},
		proxy: {
			blocks: [ETHERNET_INFO_DATA_ID]
		}
	});

	$.su.modelManager.define("wirelessMapModel", {
		type: "model",
		fields: [{
			name: "enable",
			mapping: "bEnable"
		}, {
			name: "ssid",
			mapping: "cSsid",
			vtype: "string_visible_allow_blank",
			maxLength: 32,
			allowBlank: false
		}, {
			name: "password"
		}, {
			name: "uChannel"
		}],
		methods: {
			getRealChannel: function(options) {
				options = options || {};
				var cmd = "wlan autoChannel 2g";
				options.data = cmd;
				this.getProxy().instr(options);
			}
		},
		convert: function (data) {
			var fn = $.su.ClassManager.getInstance().get("MERProxy");
			var wlanBasicData = data[WLAN_BASIC_DATA_ID + "|1,0,0"];
			var wlanMbssidData = data[MBSSID_MAIN_DATA_ID + "|1,1,0"];//fn.findBlock(MBSSID_MAIN_DATA_ID, [1,1,0]);
			wlanMbssidData.uChannel = wlanBasicData.uChannel == 0 ? $.su.CHAR.WIRELESS_BASIC.AUTO : wlanBasicData.uChannel;
			wlanMbssidData.cBridgedBssid = wlanBasicData.apc.cBridgedBssid;

			var uAuthType = wlanMbssidData.bSecurityEnable == 0 ? "0" : wlanMbssidData.uAuthType;
			switch (parseInt(uAuthType)) {
				case WLAN_PRIVACY_MODE_PSK_PSK2:
					// WPA/WPA2-Personal
					wlanMbssidData.password = wlanMbssidData.cPskSecret;
					break;
				case WLAN_PRIVACY_MODE_WPA_WPA2:
					// WPA/WPA2-Enterprise
					wlanMbssidData.password = wlanMbssidData.cRadiusSecret;
					break;
				case WLAN_PRIVACY_MODE_WEP:
					// WEP
					wlanMbssidData.password = wlanMbssidData.privacyRcd[0].cKeyVal;
					break;
				default:
					// none
					wlanMbssidData.password = "";
			};
			return wlanMbssidData;
		},
		serialize: function (data) {
	        if(data.bEnable == 0){
	            return [{
	                id: MBSSID_MAIN_DATA_ID,
	                layers: [1,1,0],
	                bEnable: 0
	            }, {
	                id: WLAN_BASIC_DATA_ID,
	                layers: [1,0,0],
	                bEnabled: 0
	            }];
	        }
			data.id = MBSSID_MAIN_DATA_ID;
			data.layers = [1,1,0];
			delete data.cBridgedBssid;
			delete data.password;
			return [data, {
	            id: WLAN_BASIC_DATA_ID,
	            layers: [1,0,0],
	            bEnabled: 1
	        }];
		},
		proxy: {
			blocks: [WLAN_BASIC_DATA_ID, MBSSID_MAIN_DATA_ID]
		}
	});
	$.su.modelManager.define("wirelessMap5gModel", {
		type: "model",
		fields: [{
			name: "enable",
			mapping: "bEnable"
		}, {
			name: "ssid",
			mapping: "cSsid",
			vtype: "string_visible_allow_blank",
			maxLength: 32,
			allowBlank: false
		}, {
			name: "password"
		}, {
			name: "uChannel"
		}],
		methods: {
			getRealChannel: function(options) {
				options = options || {};
				var cmd = "wlan autoChannel 5g";
				options.data = cmd;
				this.getProxy().instr(options);
			}
		},
		convert: function (data) {			
			//var fn = $.su.ClassManager.getInstance().get("MERProxy");
			var wlanBasicData = data[WLAN_BASIC_DATA_ID + "|2,0,0"];
			var wlanMbssidData = data[MBSSID_MAIN_DATA_ID + "|2,1,0"];
			wlanMbssidData.uChannel = wlanBasicData.uChannel == 0 ? $.su.CHAR.WIRELESS_BASIC.AUTO : wlanBasicData.uChannel;
			wlanMbssidData.cBridgedBssid = wlanBasicData.apc.cBridgedBssid;
			
			var uAuthType = wlanMbssidData.bSecurityEnable == 0 ? "0" : wlanMbssidData.uAuthType;
			switch (uAuthType) {
				case "3":
					// WPA/WPA2-Personal
					wlanMbssidData.password = wlanMbssidData.cPskSecret;
					break;
				case "2":
					// WPA/WPA2-Enterprise
					wlanMbssidData.password = wlanMbssidData.cRadiusSecret;
					break;
				case "1":
					// WEP
					wlanMbssidData.password = wlanMbssidData.privacyRcd[0].cKeyVal;
					break;
				default:
					// none
					wlanMbssidData.password = "";
			}
			return wlanMbssidData;
		},
		serialize: function (data) {
	        if(data.bEnable == 0){
	            return [{
	                id: MBSSID_MAIN_DATA_ID,
	                layers: [2,1,0],
	                bEnable: 0
	            }, {
	                id: WLAN_BASIC_DATA_ID,
	                layers: [2,0,0],
	                bEnabled: 0
	            }];
	        }
			data.id = MBSSID_MAIN_DATA_ID;
			data.layers = [2,1,0];
			delete data.cBridgedBssid;
			delete data.password;
			return [data, {
	            id: WLAN_BASIC_DATA_ID,
	            layers: [2,0,0],
	            bEnabled: 1
	        }];
		},
		proxy: {
			blocks: [WLAN_BASIC_DATA_ID, MBSSID_MAIN_DATA_ID]
		}
	});
	$.su.modelManager.define("guestNetworkMap", {
		type: "model",
		fields: [{
			name: "enable",
			mapping: "bEnable"
		}, {
			name: "ssid",
			mapping: "cSsid"
		}],
		proxy: {
			blocks: [MBSSID_MAIN_DATA_ID + '|1,2,0']
		}
	});
	$.su.modelManager.define("guestNetworkMap5g", {
		type: "model",
		fields: [{
			name: "enable",
			mapping: "bEnable"
		}, {
			name: "ssid",
			mapping: "cSsid"
		}],
		proxy: {
			blocks: [MBSSID_MAIN_DATA_ID + '|2,2,0']
		}
	});
})(jQuery);
