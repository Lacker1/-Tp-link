//@ sourceURL=modules/networkMap/mapRouter/controllers.js

/*
 * @description @module mapRouter
 * @author
 * @change
 *
 * */
(function($) {
	$.su.moduleManager.define("mapRouter", {
		services: ["device", "ajax", "moduleRouter", "timer", "device"],
		models: ["lanAdvLanModel", "wirelessMapModel", "guestNetworkMap", "wirelessMap5gModel", "guestNetworkMap5g"],
		stores: ["ethernetStatusStore"],
		deps: ["navigatorController"],
		views: ["mapRouterView"],
		listeners: {
			"ev_on_launch": function(e, me, views, models, stores, deps, services) {
				this.unRegisterAutoSaveData([
					models.lanAdvLanModel,
					models.wirelessMapModel,
					models.guestNetworkMap,
					models.wirelessMap5gModel,
					models.guestNetworkMap5g
				]);
				var productName = services.device.getProductName() || $.su.CHAR.NETWORK_MAP.ROUTER;
				views.deviceName.setValue(productName);
				models.lanAdvLanModel.load();
				
				models.guestNetworkMap.load();
				me.getIPv6();
				me.getMAC();

				services.timer.setInterval(this, function() {
					stores.ethernetStatusStore.loadInterfaces();
				}, 3000, true);
				if(services.device.getCurrentMode() == "4"){
					models.wirelessMapModel.enable.hide();
					if(services.device.getIsDualband()){
						models.wirelessMap5gModel.enable.hide();
					}
					views.wispDisplay.show();
				}
				if(services.device.getIsDualband()){
					models.guestNetworkMap5g.load();
					$("#wireless-5g-panel").removeClass('hidden');
					$("#guest-5g-panel").removeClass('hidden');
				}else{
					$("#wireless-5g-panel").addClass('hidden');
					$("#guest-5g-panel").addClass('hidden');
					$("#wireless-panel").addClass('single-column');
					$("#guest-panel").addClass('single-column');
					
				}
			}
		},
		init: function(me, views, models, stores, deps, services) {
			this.configViews({
				id: "mapRouterView",
				items: []
			});
			this.control({
				"#map-router-wireless-button": {
					"ev_button_click": function(e) {
						services.moduleRouter.goTo("hostNwAdv");
					}
				},
				"#map-router-guest-button": {
					"ev_button_click": function(e) {
						services.moduleRouter.goTo("guestNetworkAdv");
					}
				},
				"#wireless2g-enable-switch": {
					"ev_view_change": function() {
						models.wirelessMapModel.submit();
					}
				},
				"#guestNetwork2g-enable-switch": {
					"ev_view_change": function() {
						models.guestNetworkMap.submit();
					}
				},
				"#wireless5g-enable-switch": {
					"ev_view_change": function() {
						models.wirelessMap5gModel.submit();
					}
				},
				"#guestNetwork5g-enable-switch": {
					"ev_view_change": function() {
						models.guestNetworkMap5g.submit();
					}
				}
			});
			this.listen({
				"models.wirelessMapModel": {
					"ev_loaded": function(e){
						if(models.wirelessMapModel.enable.getValue() != "1"){
							models.guestNetworkMap.enable.disable();
						}else{
							models.guestNetworkMap.enable.enable();
						}
						var autoStr = $.su.CHAR.WIRELESS_BASIC.AUTO;
						var uChannel = models.wirelessMapModel.uChannel.getValue();
						if (uChannel == autoStr) {
							models.wirelessMapModel.getRealChannel({
								preventSuccessEvent: true,
								success: function(data) {
									views.uChannel2g.setValue(autoStr + " (" + $.trim(data) + ")");
								}
							});
						} else {
							views.uChannel2g.setValue(uChannel);
						}
					},
					"ev_model_submit": function(e){
						if(models.wirelessMapModel.enable.getValue() != "1"){
							models.guestNetworkMap.enable.disable();
						}else{
							models.guestNetworkMap.enable.enable();
						}
					}
				},
				"models.wirelessMap5gModel": {
					"ev_loaded": function(e){
						if(models.wirelessMap5gModel.enable.getValue() != "1"){
							models.guestNetworkMap5g.enable.disable();
						}else{
							models.guestNetworkMap5g.enable.enable();
						}
						var autoStr = $.su.CHAR.WIRELESS_BASIC.AUTO;
						var uChannel = models.wirelessMap5gModel.uChannel.getValue();
						if (uChannel == autoStr) {
							models.wirelessMap5gModel.getRealChannel({
								preventSuccessEvent: true,
								success: function(data) {
									views.uChannel5g.setValue(autoStr + " (" + $.trim(data) + ")");
								}
							});
						} else {
							views.uChannel5g.setValue(uChannel);
						}
					},
					"ev_model_submit": function(e){
						if(models.wirelessMap5gModel.enable.getValue() != "1"){
							models.guestNetworkMap5g.enable.disable();
						}else{
							models.guestNetworkMap5g.enable.enable();
						}
					}
				}
			});
		}
	}, function(me, views, models, stores, deps, services) {
		return {
			getMAC: function(){
				services.ajax.request({
					proxy: "getMacProxy",
					method: "read",
					success: function(data) {
						views.lanMacaddr.setValue(data.mac[0].toUpperCase());
					},
					fail: function () {
						views.lanMacaddr.setValue("00-00-00-00-00-00");
					}
				});
			},
			getIPv6: function(){
				services.ajax.request({
                    proxy: "networkWanAndLanStatusProxy",
                    method: "read",
					success: function (data) {
						views.lanIpv6Ipaddr.setValue(data.linkLocalIp);
					},
					fail: function () {
						views.lanIpv6Ipaddr.setValue("");
					}
				});
			},
            ipv6AddrFormat: function (addr, len) {
                if (addr === "" || addr === undefined) {
                    return addr;
                }
                if ($.trim(addr) == "" || $.trim(addr) == "::") {
                    return "";
                }
                if (len == null) {
                    return addr;
                }
                return addr + "/" + len;
            }
		};
	});
})(jQuery);

