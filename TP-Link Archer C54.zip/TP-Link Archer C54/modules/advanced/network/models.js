//@ sourceURL=modules/advanced/network/lanAdv/lanAdvLan/models.js

(function ($) {
	$.su.modelManager.define("lanAdvLanModel", {
		type: "model",
		fields: [{
			name: "macaddr",
			mapping: "mac"
		}, {
			name: "ipaddr",
			mapping: "ip",
			vtype: "ip",
			allowBlank: false
		}, {
			name: "maskType",
			mapping: "mode",
			valueType: "number"
		}, {
			name: "customValue",
			mapping: "mask",
			allowBlank: false,
			vtype: "netmask",
			defaultValue: "255.255.255.0"
		}],
		convert: function(result){
			var lanData = result[LAN_DATA_ID];
			var ret = {};
			ret.mac = result[SYSTEM_DATA_ID].mac[0].toUpperCase()||"00-00-00-00-00-00";
			ret.ip = lanData.ip;
			switch(lanData.mask){
				case("255.255.255.0"):
					ret.mode = 0;
					break;
				case("255.255.0.0"):
					ret.mode = 1;
					break;
				case("255.0.0.0"):
					ret.mode = 2;
					break;
				default:
					ret.mode = 3;
					break;
			}
			ret.mask = lanData.mask;
			return ret;
		},
		serialize: function(data){
			var ret = {};
			switch(data.mode){
				case 0:
					ret.mask = "255.255.255.0";
					break;
				case 1:
					ret.mask = "255.255.0.0";
					break;
				case 2:
					ret.mask = "255.0.0.0";
					break;
				default:
					ret.mask = data.mask;
					break;
			}
			ret.ip = data.ip;
			ret.mode = data.mode;
			return ret;
		},
		proxy: {
			blocks: [LAN_DATA_ID, SYSTEM_DATA_ID]
		}
	});

	$.su.storeManager.define("lanAdvSubnetCombo", {
		type: "store",
		fields: [{
			name: "name"
		}, {
			name: "value"
		}, {
			name: "boxlabel"
		}],
		data: [{
			name: "255.255.255.0",
			value: 0,
			boxlabel: "255.255.255.0"
		}, {
			name: "255.255.0.0",
			value: 1,
			boxlabel: "255.255.0.0"
		}, {
			name: "255.0.0.0",
			value: 2,
			boxlabel: "255.0.0.0"
		}, {
			name: $.su.CHAR.NETWORK_LAN.CUSTOM,
			value: 3,
			boxlabel: "custom"
		}]
	});


	$.su.modelManager.define("lanAdvWanModel", {
		type: "model",
		fields: [{
			name: "wanIpv4Ipaddr"
		}, {
			name: "wanMacaddr"
		}, {
			name: "wanIpv4Netmask"
		}, {
			name: "wanIpv4Gateway"
		}, {
			name: "wanIpv4Pridns"
		}, {
			name: "wanIpv4Snddns"
		}, {
			name: "wanIpv4Conntype"
		}, {
			name: "lanIpv4Ipaddr"
		}, {
			name: "lanIpv4Netmask"
		}, {
			name: "lanMacaddr"
		}, {
			name: "lanIpv4DhcpEnable"
		},{
			name: "wanIpv4SndIpaddr"
		},{
			name: 'wanIpv4SndNetmask'
		}],
		convert: function(result){
			var data = {};
			data.wanIpv4Ipaddr = result[LINK_STATUS_DATA_ID].ip;
			data.wanIpv4Netmask = result[LINK_STATUS_DATA_ID].mask;
			data.wanIpv4Conntype = result[LINK_DATA_ID].linkType;
			data.wanIpv4SndIpaddr = result[LINK_STATUS_DATA_ID].dualIp;
			data.wanIpv4SndNetmask = result[LINK_STATUS_DATA_ID].dualMask;

			// do not delete below
			/*data.wanMacaddr = result[SYSTEM_DATA_ID].mac[1];
			data.wanIpv4Gateway = result[LINK_STATUS_DATA_ID].gateway;
			data.wanIpv4Pridns = result[LINK_STATUS_DATA_ID].dns[0];
			data.wanIpv4Snddns = result[LINK_STATUS_DATA_ID].dns[1];
			data.lanIpv4Ipaddr = result[LAN_DATA_ID].ip;
			data.lanIpv4Netmask = result[LAN_DATA_ID].mask;
			data.lanMacaddr = result[SYSTEM_DATA_ID].mac[0];
			data.lanIpv4DhcpEnable = result[DHCPS_DATA_ID].enable;*/

			return data;
		},
		proxy: {
			// blocks: [LINK_STATUS_DATA_ID, SYSTEM_DATA_ID, LINK_DATA_ID, LAN_DATA_ID, DHCPS_DATA_ID]
			blocks: [LINK_STATUS_DATA_ID, LINK_DATA_ID]
		}
	});


})(jQuery);