//@ sourceURL=modules/advanced/security/accessControl/models.js

(function() {
	$.su.modelManager.define("accessControlEnableM", {
		type: "model",
		fields: [{
			name: "enable"
		}],
		convert: function(data) {
			return {
				enable: data.ctrlEnable == "1" ? "on" : "off"
			};
		},
		serialize: function(data) {
			return {
				ctrlEnable: data.enable == "on" ? "1" : "0"
			};
		},
		methods: {
			toggle: function(enable, options) {
				enable = enable || this.enable.getValue();
				options = options || {};
				options.data = "advanced bm " + (enable === "on" ? "-enable" : "-disable");
				this.getProxy().instr(options);
			}
		},
		proxy: {
			blocks: ACCESS_CONTROL_SWITCH_DATA_ID
		}
	});
	$.su.modelManager.define("accessControl", {
		type: "model",
		fields: [{
			name: "accessMode"
		}],
		convert: function(data) {
			return {
				accessMode: data.isWhiteList == "1" ? "white" : "black"
			};
		},
		serialize: function(data) {
			return {
				isWhiteList: data.accessMode == "white" ? "1" : "0"
			};
		},
		methods: {
			switchMode: function(mode, options) {
				var accessMode = mode || this.accessMode.getValue();
				options = options || {};
				options.data = "advanced bm -list " + (accessMode === "white" ? "white" : "black");
				this.getProxy().instr(options);
			}
		},
		proxy: {
			blocks: ACCESS_CONTROL_SWITCH_DATA_ID
		}
	});
	$.su.modelManager.define("addAccessControl", {
		type: "model",
		fields: [{
			name: "addDeviceMethod",
			defaultValue: 0
		}, {
			name: "newMac",
			vtype: "mac",
			allowBlank: false
		}, {
			name: "name",
			allowBlank: false,
			maxLength: 32
		}]
	});
	$.su.storeManager.define("accessModeStore", {
		type: "store",
		fields: [{
			name: "name"
		}, {
			name: "value"
		}, {
			name: "selected"
		}, {
			name: "boxlabel"
		}, {
			name: "content"
		}],
		data: [{
			name: "accessMode1",
			value: "black",
			selected: true,
			boxlabel: $.su.CHAR.ACCESS_CONTROL.BLACKLIST,
			content: "<span>" + $.su.CHAR.ACCESS_CONTROL.BLACKLIST_INTRODUCTION + "</span>"
		}, {
			name: "accessMode2",
			value: "white",
			boxlabel: $.su.CHAR.ACCESS_CONTROL.WHITELIST,
			content: "<span>" + $.su.CHAR.ACCESS_CONTROL.WHITELIST_INTRODUCTION + "</span>"
		}]
	});
	$.su.storeManager.define("addDeviceStore", {
		type: "store",
		fields: [{
			name: "name"
		}, {
			name: "value"
		}, {
			name: "boxlabel"
		}, {
			name: "selected"
		}],
		data: [{
			name: "addDeviceMethod",
			value: 0,
			selected: true,
			boxlabel: $.su.CHAR.ACCESS_CONTROL.SELECT_FROM_DEVICE_LIST
		}, {
			name: "addDeviceMethod",
			value: 1,
			boxlabel: $.su.CHAR.ACCESS_CONTROL.ADD_MANUALLY
		}]
	});
	$.su.storeManager.define("blacklistGridStore", {
		type: "store",
		fields: [{
			name: "deviceType"
		}, {
			name: "name"
		}, {
			name: "mac"
		}, {
			name: "host"
		}],
		convert: function(data) {
			return convertDeviceData(data.blackList, false);
		},
		methods: {
			addDevice: function(options) {
				var index = this.getData().length;
				var data = $.each([].concat(options.data), function(i, item) {
					item.index = index + i;
				});
				options.data = data;
				this.getProxy().addDevice(options);
			}
		},
		proxy: "blacklistGridProxy"
	});
	$.su.storeManager.define("whitelistGridStore", {
		type: "store",
		fields: [{
			name: "deviceType"
		}, {
			name: "name"
		}, {
			name: "mac"
		}, {
			name: "host"
		}],
		convert: function(data) {
			var result =  convertDeviceData(data.whiteList, true);
			var deviceMode = Number($.su.serviceManager.get("device").getCurrentMode());
			var needFilterDhcp = deviceMode === SYSTEM_MODE_AP || deviceMode === SYSTEM_MODE_RE;
			if(needFilterDhcp){
				var ipToFilter = null; 
				var ajaxServcie = $.su.serviceManager.get("ajax");
				ajaxServcie.request({
					proxy: "lanDhcpIpProxy",
					ajax:{
						async: false
					},
					method: "instrGet",
					success: function(dhcpIp){
						ipToFilter = $.appUtils.ipToInt(dhcpIp)
					}
				});
				var macToFilter = null;
				ajaxServcie.request({
					proxy: "allClientsProxy",
					method: "read",
					ajax:{
						async: false
					},
					success: function(data) {
						for(var i=0, len = data.list.length, item = null; i<len; i++){
							item = data.list[i];
							if( $.appUtils.ipToInt(item.ip) === ipToFilter || item.mac==="00-00-00-00-00-00"){
								macToFilter = item.mac;
								break;
							}
						}
					}});
				if(macToFilter){
					for(var i=0, len= result.length; i<len; i++){
						if(result[i].mac.toUpperCase() === macToFilter.toUpperCase()){
							result.splice(i, 1);
							break;
						}
					}
				}
			
		}
			return result;
		},
		methods: {
			addDevice: function(options) {
				var index = this.getData().length;
				var data = $.each([].concat(options.data), function(i, item) {
					item.index = index + i;
				});
				options.data = data;
				this.getProxy().addDevice(options);
			}
		},
		proxy: "whitelistGridProxy"
	});
	$.su.storeManager.define("blacklistOnlineStore", {
		type: "store",
		fields: [{
			name: "deviceType"
		}, {
			name: "deviceName"
		}, {
			name: "mac"
		}, {
			name: "ip"
		}, {
			name: "host"
		}]
	});
	$.su.storeManager.define("whitelistOnlineStore", {
		type: "store",
		fields: [{
			name: "deviceType"
		}, {
			name: "deviceName"
		}, {
			name: "mac"
		}, {
			name: "ip"
		}, {
			name: "host"
		}]
	});
	$.su.define("blacklistGridProxy", {
		extend: "MERProxy",
		blocks: ACCESS_CONTROL_BlACK_LIST_DATA_ID,
		addDevice: function(options) {
			sendAddDeviceCmd(this, true, options);
		},
		deleteDevice: function(options) {
			deleteAddDeviceCmd(this, true, options);
		}
	});
	$.su.define("whitelistGridProxy", {
		extend: "MERProxy",
		blocks: ACCESS_CONTROL_WHITE_LIST_DATA_ID,
		addDevice: function(options) {
			sendAddDeviceCmd(this, false, options);
		},
		deleteDevice: function(options) {
			deleteAddDeviceCmd(this, false, options);
		}
	});
	function convertDeviceData(list) {
		var convertDevType = function(val) {
			return "pc";
			// return ["pc", "phone"][val] || "pc";
			// 根据后台要求，统一只显示电脑图标
		};
		var hostMac = $.su.serviceManager.get("device").getHostMac();
		var availableData = $.grep(list, function(item) {
			return item.mac && item.mac !== "00-00-00-00-00-00";
		});
		var result = [];
		$.each(availableData, function(i, item) {
			var device = {
				name: item.devName,
				deviceType: convertDevType(item.devType),
				mac: item.mac.toUpperCase(),
				host: $.su.App.utils.isSameMac(item.mac, hostMac)
			}
			result.push(device);
		});
		return result;
	}
	function sendAddDeviceCmd(proxy, isBlackList, options) {
			// 格式：advanced bm -add list:[white/black] name:xxx mac:xx-xx-xx-xx-xx-xx [; name:xxx mac:xx-xx-xx-xx-xx; …….]
			// list_value取值为white表示white list，取值为black表示black list。
			var listValue = isBlackList ? "black" : "white";
			var getCmd = function(data) {
				var cmd = "advanced bm -add";
				cmd += " list:" + listValue;
				$.each(data, function(i, item) {
					if (i > 0) {
						cmd += " ;"
					}
					cmd += " name:" + encodeURIComponent(item.name);
					cmd += " mac:" + item.mac;
				});
				return cmd;
			};
			options.data = getCmd(options.data);
			proxy.instr(options);
	};
	function deleteAddDeviceCmd(proxy, isBlackList, options) {
			// 删除单个条目：
			// advanced bm –del list:black mac:xx-xx-xx-xx-xx-xx
			// 删除多个条目，暂未有此交互
			// advanced bm –del list:white mac:xx-xx-xx-xx-xx-xx; mac:xx-xx-xx-xx-xx-xx
			// list_value取值为white表示white list，取值为black表示black list。
			var listValue = isBlackList ? "black" : "white";
			var data = options.data;
			var getCmd = function(data) {
				return "advanced bm rule -del list:" + listValue + " mac:" + data.mac;
			};
			options.data = getCmd(data);
			proxy.instr(options);
	};
})()

