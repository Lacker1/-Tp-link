(function($){
	$.su = $.su || {};

	var urlMapPath = "./data/mer/url_to_text/";
	var urlMapFiles = [
		"url_to_text_hwl.txt"
	];
	var urlMap = {};

	for (var i in urlMapFiles){
		var urlFileName = urlMapFiles[i];
		$.ajax({
			type: "GET",
			url: urlMapPath + urlFileName,
			async: false,
			dataType: "text",
			cache: false,
			success: function(data){
				// var items = data.replace(/\#.*$/gm, '').split(/\n+/g);
				var items = data.split(/\n+/g);
				for (var j = 0; j < items.length; j++) {
					var item = items[j].replace(/^ +| +$/, '');	//$.trim(items[j])
					if(item.length > 1){
						item = item.split(/=>/);
						if(item[0]){
							urlMap[item[0]] = './data/mer/' + item[1];
						}
					}
				}
			},
			error: function(){
			}
		});
	}



	$.su.url = function(url,data){
		var queryString = url.match(/(\?(.*))/)[2];
		data = data || queryString;
		if (data) {
			for (var i in urlMap) {
				if (urlMap.hasOwnProperty(i)) {
					if (data && data.indexOf(i) == 0) {
						return urlMap[i]+url;
					}
				}
			}
		}

		return "./data/mer/blocks" + url;
	};

	$.su.url.stok = "";
	$.su.url.anotherStok = "12345";

	$.su.ozkerurl = function(url){
		return ozkersubs + $.su.url.stok + url;
	};

})(jQuery);