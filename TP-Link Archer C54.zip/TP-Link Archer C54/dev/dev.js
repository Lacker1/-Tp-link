(function($){
    if (window.console && (typeof console.log === 'function')){
		$.su = $.su || {};
	    if (typeof  console.log.bind === 'function') { 
		    //通过bind方法，在控制台报错时能定位到具体代码，而不是dev.js
		    $.su.debug = (function() {
			    return {
				    log: console.log.bind(console),
				    warn: console.warn.bind(console),
				    error: console.error.bind(console)
			    }
		    })();
	    } else {
		    $.su.debug = {
			    log: function(){
				    return console.log.apply(console, arguments);
			    },
			    warn: function(){
				    return console.warn.apply(console, arguments);
			    },
			    error: function(){
				    return console.error.apply(console, arguments);
			    }
		    };
	    }
        
    }else{
		$.su.debug = {
			log: function () {
			},
			warn: function () {
			},
			error: function () {
			}
		};
	}
	$.su.development = true;
})(jQuery);