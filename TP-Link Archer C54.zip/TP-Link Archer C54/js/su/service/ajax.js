(function($){
    $.su = $.su || {};
	$.su.Services = $.su.Services || {};
    //service
    $.su.Services.Ajax = (function(){

        var defaults = {
            url: null,
			ajax: {
				contentType: "text/plain;charset=UTF-8",
				dataType: "text",
				timeout: 15 * 1000
			},
            root: null,
			params: {}
        };
		
        var Ajax = function(options){
            if (typeof Ajax.instance === 'object') {
                return Ajax.instance;
            }
			$.extend(true, defaults.ajax, options.ajax);

			this.failHandler = options.failHandler;
			this.errorHandler = options.errorHandler;
            this.name = 'ajax';
	        this.proxyMap = {};
			$.su.Service.call(this);

            Ajax.instance = this;
        };

		$.su.inherit($.su.Service, Ajax);

        /*
        * option:
        *   url: url
        *   success:
        *   fail:
        *   error:
        *
        * */
        Ajax.prototype.request = function(option){
			if(option.url){
				$.su.debug.log('can not use url:' + option.url + ' in services ajax');
			}
			var dataAndCallback = {
				url: option.url,
				ajax: $.extend(true, {}, defaults.ajax, option.ajax),
				data: option.data,
				success: option.success,
				fail: this.failHandler ? this.failHandler(option.fail) : option.fail,
				error: this.errorHandler ? this.errorHandler(option.error, option.preventDefaultError) : option.error,
				params: option.params,
				preventSuccessEvent: option.preventSuccessEvent,
				preventFailEvent: option.preventFailEvent,
				preventErrorEvent: option.preventErrorEvent
			};
	        $.extend(dataAndCallback, option.options);
			this.sendRequest($.extend({
				proxy: option.proxy || $.su.settings.AjaxService.defaultProxy,
				method: option.method
			}, dataAndCallback));
		};

        Ajax.prototype.upload = function(option){
			var me = this;
			var dataAndCallback = {
				fileId: option.fileId,
				data: option.data,
				success: option.success,
				fail: option.fail,
				error: option.error,
				timeout: option.timeout,
				ajax: option.ajax || {}
			};
			this.sendRequest($.extend({
				proxy: option.proxy || $.su.settings.AjaxService.defaultProxy,
				method: "upload"
			}, dataAndCallback));
		};

		Ajax.prototype.download = function(fileName){
			var manager = $.su.ClassManager.getInstance();
			var proxy = (manager.get($.su.settings.AjaxService.defaultProxy)).create(proxyOption);
			proxy.download(fileName);
		};

	    Ajax.prototype.createProxy = function(name, options) {
		    var manager = $.su.ClassManager.getInstance();
		    var proxy = (manager.get(name)).create(options);
		    return proxy;
		};
		
		
		Ajax.prototype.sendRequest = function(option) {
			var me = this;
			var async = option.ajax.async;
			var doRequest = function(option) {
				var proxy = option.proxy; // instance of proxy
				var method = option.method;
				delete option.proxy;
				delete option.method;
				if (method && proxy[method]) {
					proxy[method].call(proxy, option);
				} else {
					proxy.op("default", option);
				}
			};
			if (async === false) {
				if (!this.proxyMap[option.proxy]) {
					this.proxyMap[option.proxy] = $.su.createSync(option.proxy);
				}
				option.proxy = this.proxyMap[option.proxy];
				doRequest(option);
			} else {
				var getProxyDfd = $.Deferred();
				if (!this.proxyMap[option.proxy]) {
					$.su.create(option.proxy).done(function(proxy){
						me.proxyMap[option.proxy] = proxy;
						getProxyDfd.resolve(proxy);
					});
				} else {
					getProxyDfd.resolve(me.proxyMap[option.proxy]);
				}
				getProxyDfd.then(function(proxy) {
					option.proxy = proxy;
					doRequest(option);
				});
			}
		};

        return Ajax;
    })();

})(jQuery);