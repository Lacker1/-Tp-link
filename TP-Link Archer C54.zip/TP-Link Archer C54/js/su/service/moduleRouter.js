(function($){
    $.su = $.su || {};
    $.su.Services = $.su.Services || {};
    $.su.Services.ModuleRouter = (function(){
        var _hashMap = {};
        var ModuleRouter = function(object){
            //单例模式
            if(typeof ModuleRouter.instance === 'object'){
                return ModuleRouter.instance;
            }
            //$.extend(true, map, hashMap);
            this.currentPage = null;
            this.mainPageContainer = null;
            this.indexPageContainer = null;
            //this.notDefaultPage = ['quickSetupAp', 'quickSetup'];
            this.attrEnable = ['module', 'name', 'text', 'default', 'alias', 'redirect', 'container', 'meta'];
            //原始数据保存成菜单用
            //添加和删除路由，要向菜单进行同步
            this.init(object.hashMap);
            this.name = "moduleRouter";
            $.su.Service.call(this);
            ModuleRouter.instance = this;
        };
        $.su.inherit($.su.Service, ModuleRouter);

        /**
         *  根据底层节点，过滤掉data中有bind字段且底层不支持该字段的条目
         * @param data
         * @returns {*}
         * @private
         */
        var _filterData = function(data) {
            var bindvalue;
            var functionSupport = $.su.serviceManager.get("device").getFunctionSupport();
            if (!functionSupport) {
                return data;
            }
            for (var i = 0; i < data.length; i++) {
                bindvalue = data[i].bind;
                if (bindvalue) {
                    if (bindvalue.indexOf("!") === 0) {
                        bindvalue = bindvalue.slice(1);
                        //只有当值为1时进行删除
                        if (functionSupport[bindvalue] == 1 ) {
                            data.splice(i, 1);
                            i--;
                        }
                    } else {
                        //如果值不存在或为0时删除
                        if (functionSupport[bindvalue] != 1 ) {
                            data.splice(i, 1);
                            i--;
                        }
                    }
                    //如果functionSupport中不存在或值不为1，删掉
                } else if (data[i].children && data[i].children.length) {
                    _filterData(data[i].children);
                }
            }
            return data;
        };
        
        
        ModuleRouter.prototype.getNavigatorData = function() {
            var me = this;
            if (!this.navigatorData) {
                var _convert = (function(){
                    var _convert = function(data){
                        for(var i=0; i<data.length; i++){
                            var key = data[i].text;
                            var realText = $.su.CHAR.MENU_ITEMS_NAME[key] || $.su.CHAR.INDEX[key];
                            if(realText !== undefined){
                                data[i].text = realText;
                            }else{
                                $.su.debug.warn("'" + data[i].name + "' has no menu name text defined in $.su.CHAR");
                            }
                            if(data[i].children){
                                _convert(data[i].children);
                            }
                        }
                    };
                    return function(data){
                        _convert(data);
                    };
                })();
                var mode = $.su.serviceManager.get("device").getCurrentMode();
                var url = $.su.settings.navigatorUrl[mode];
                if (!url) {
                    throw new Error("mode Error!")
                }
                $.ajax(url, {
                    async: false,
                    method: "GET",
                    dataType: "json",
                    success: function(data){
                        _filterData(data);
                         _convert(data);
                        me.navigatorData = data;
                    }
                });
            }
            return this.navigatorData;
        };
        ModuleRouter.prototype.init = function(hashMap){
            var me = this;
            
            hashMap = hashMap || this.getNavigatorData();
            //初始化服务，先将读进来的数据hash化，然后做一些预处理
            (function(){
                if($.type(hashMap) !== "array"){
                    hashMap = JSON.parse(hashMap);
                }
                _hashMap = {};
                function seralize(array, pathArray, resultObj){
                    var iLength = array.length;
                    for(var i=0; i<iLength; i++){
                        var item = array[i];
                        var name = item["name"];
                        item.module = item.module || item.name;
                        var itemPath = pathArray.slice(0);  //only string
                        itemPath.push(name);
                        resultObj[name] = {
                            path: itemPath,
                            self: item
                        };
                        if(item["children"]){
                            seralize(item["children"], itemPath, resultObj);
                        }
                    }
                }
                seralize(hashMap, [], _hashMap);
            })();
            //先将路由序列化,路由应当添加所有结点
            //从localStorage中提取出登录之后可能要跳转的元信息
            var indexMeta =localStorage.getItem("indexMeta");
            if(indexMeta){
                this.setAttr(["index"], "meta", {name: indexMeta});
                localStorage.removeItem("indexMeta");
            }
            $(window).off('hashchange').on('hashchange', function() {
                var name = location.hash && location.hash.substr(1);
				if (me.currentPage != name) {
                    me.goTo(name);
                    //浏览器输入hash值
                }
            });
        };
        ModuleRouter.prototype._syncModule = function(self, path, option1, option2){
            //直接从path的第二层开始向前查找，如果有的话
            //根据传引用的特性，其实不用这么复杂，暂时写着
            //外层赋值内层的self
            //新增
            var moduleName = self.name;
            var position;
            var index;
            if(option1 == "add"){
                //有option2代表新增模块的位置，默认插入最后面，否则是新增属性
                for(var i = path.length - 2; i >= 0; i --){
                    if(i == path.length - 2 && option2){
                        if(option2 == "default") 
                            position = _hashMap[path[i]].self.children.length;
                        else{
                            position = Math.min(_hashMap[path[i]].self.children.length, Number(option2));
                            _hashMap[path[i]].self.children.splice(position, 0, self);
                        }
                    } else{
                        //新增属性和其他同步都是直接赋值即可。
                        index = this.findItems(moduleName, "name", _hashMap[path[i]].self.children);
                        _hashMap[path[i]].self.children[index] = self;
                    }
                    self = _hashMap[path[i]].self;
                    moduleName = _hashMap[path[i]].self.name;
                }
            } 
            if(option1 == "delete"){
                //有option2是删除的模块，否则是删除属性
                for(var i = path.length - 2; i >= 0; i --){
                    if(i == path.length - 2 && option2){
                        //删除模块
                        index = this.findItems(moduleName, "name", _hashMap[path[i]].self.children);
                        _hashMap[path[i]].self.children.splice(index, 1);
                    } else{
                        //删除属性和其他同步都是直接赋值即可。
                        index = this.findItems(moduleName, "name", _hashMap[path[i]].self.children);
                        _hashMap[path[i]].self.children[index] = self;
                    }
                    self = _hashMap[path[i]].self;
                    moduleName = _hashMap[path[i]].self.module;
                }
            } 
        };
        ModuleRouter.prototype.addRouter = function(page, path, position, option){
            if(page.name && !_hashMap[page.name]){
                page.module = page.module || page.name;
                _hashMap[page.name] = {
                    path: path,
                    self: page
                };
                //再递归式向路径中的父类同步值。
                this._syncModule(_hashMap[page.name].self,_hashMap[page.name].path, "add", position);
                //如果同步到菜单，则触发给菜单同步
                if(option)
                    this.trigger("ev_router_change", ["add", page, path, position]);
            }
        };
        ModuleRouter.prototype.deleteRouter = function(moduleName, option){
            if(_hashMap[moduleName]){
                var self = _hashMap[moduleName].self;
                var path = _hashMap[moduleName].path;
                delete _hashMap[moduleName];
                //递归式向路径中的父类同步值
                this._syncModule(self, path, "delete", true);
                if(option)
                    this.trigger("ev_router_change", ["delete", moduleName, path, position]);
            }
        };
        ModuleRouter.prototype.setAttr = function(moduleName, attr, value){
            if($.inArray(attr, this.attrEnable) < 0)
                return;
            //moduleName是一个数组或单个名字
            if($.type(moduleName) !== "array"){
                moduleName = [moduleName];
            }
            //可批量设置属性
            for(var i = 0; i < moduleName.length; i ++){
                if(_hashMap[moduleName[i]]){
                    _hashMap[moduleName[i]].self[attr] = value;
                    this._syncModule(_hashMap[moduleName[i]].self,_hashMap[moduleName[i]].path, "add");
                }
            }
        };
        ModuleRouter.prototype.deleteAttr = function(moduleName, attr){
            if($.inArray(attr, this.attrEnable) < 0)
                return;
            //可批量刪除属性
            if($.type(moduleName) !== "array"){
                moduleName = [moduleName];
            }
            for(var i = 0; i < moduleName.length; i ++){
                delete _hashMap[moduleName[i]].self[attr];
                var self = _hashMap[moduleName[i]].self;
                var path = _hashMap[moduleName[i]].path;
                this._syncModule(self, path, "delete");
            }
        };
        ModuleRouter.prototype.setPageContainer = function(pageContainer, level){
            if(level == "main"){
                this.mainPageContainer = pageContainer;
            } else if(level == "index"){
                this.indexPageContainer = pageContainer;
            }
        };
        ModuleRouter.prototype.findItems = function(items, property, array){
            for(var i = 0; i < array.length; i ++){
                if(array[i][property] == items)
                    return i;
            }
        };
        ModuleRouter.prototype.splitHash = function(parameterHash){
            var name, parameter;
            var resultObj;
            //匹配a=b&c=d的结构
            var reg = /(\w+=\w+&)+\w+=\w+/;
            parameterHash = parameterHash.split('?');
            name = parameterHash[0];
            if(parameterHash[1] && reg.test(parameterHash[1])){
                parameter = parameterHash[1];
                parameter = parameter.split('&');
                var temp;
                resultObj = {};
                for(var i=0; i<parameter.length; i++){
                    temp = parameter[i].split('=');
                    resultObj[temp[0]] = temp[1];
                }
                return [name, resultObj];
            }
            else 
                return [name];
        }
        //添加额外的属性
        ModuleRouter.prototype.goTo = function(parameterHash){
            
            var module;
            var hash;
            var parameter;
            var me = this;
            if(parameterHash == "") 
                return;
            var resultObj = this.splitHash(parameterHash);
            var name = resultObj[0];
            if(resultObj[1]){
                parameter = resultObj[1];
            }
            //重定向优先级更高
            //有重定向则走重定向
            if(_hashMap[name] && _hashMap[name].self.redirect && _hashMap[_hashMap[name].self.redirect]) {
                name = _hashMap[name].self.redirect;
            }
                
            // if(_hashMap[name] && _hashMap[name].self.redirect && _hashMap[_hashMap[name].self.redirect])
            //     name = _hashMap[name].self.redirect;
            // else
            //暂时将parameter传入即将要到达的子模块
            name = this._getDefaultPage(name);
            module = _hashMap[name];
            if(module.self.container && module.self.container == "main"){
                me.currentPage = name;
                location.hash = name;
                $.su.serviceManager.get("moduleLoader").load({
                    module: "main"
                }, {
                    module: module.self.module,
                    params: parameter
                }, this.mainPageContainer);
            } else{
                //如果当前渲染的页面没有index，则需要重新渲染index，此时为了保存当前要走的路径，
                //通过meta记录元信息，当index加载完成之后即会通过meta加载新的内容
                //meta信息使用一次之后即可擦除
                if($.su.serviceManager.get("moduleManager").get('index') && $.su.serviceManager.get("moduleManager").get('index').status == "running"){
                    $.su.serviceManager.get("moduleManager").get('index').showLoading();
                    //触发菜单的同步信息
                    this.trigger("ev_sync_navigator", [name]);
                    this.loadPage(name, parameter, function(){
                            // !!me.loadingSimpleDom && me.loadingSimpleDom.hide();
                            $.su.serviceManager.get("moduleManager").get('index').hideLoading();
                        });
                } else{
                    this.setAttr(["index"], "meta", {"name":name});
                    //this.goTo("index", parameter);
                    $.su.serviceManager.get("moduleLoader").load({
                        module: "main"
                    }, {
                        module: "index"
                    }, this.mainPageContainer, function(){
                    });
                    //$.su.moduleManager.get("main").loadBasicModule("index", function(){

                }
            }
        };
        ModuleRouter.prototype.loadPage = function(name, parameter, callback){
            //所有可去的模块都有module
            var moduleName = _hashMap[name].self.module;
            var me = this;
            //避免执行hash变化的回调函数
            this.currentPage = name;
            location.hash = name;
            $.su.serviceManager.get("moduleLoader").load({
                module: "index"
            }, {
                module: moduleName,
                params: parameter
            }, this.indexPageContainer, function(){
                me.indexPageContainer.removeClass(function(index, oldClass) {
                    var reg = /\bmodule-\w*\b/g;
                    var match = oldClass.match(reg);
                    if (match) {
                        return match[0];
                    }
                }).addClass('module-' + name);
                if ($.isFunction(callback)) {
                    callback()
                }
            });


        };
        ModuleRouter.prototype._getDefaultPage = function(name){
            
            var hashObj = _hashMap[name];
            //模块名非法,则返回默认界面
            if(!hashObj || hashObj.self.unreachable){
                return this._getMainMenuDefaultPage();
            } else{
                var moduleName = hashObj.self.module;
                hashObj = hashObj.self;
                //如果存在子模块,且当前页面没有该模块(hasModule只有index和当前页面的最终模块)
                //即菜单中的模块
                while(!$.su.serviceManager.get("moduleManager").hasModule(moduleName) && hashObj.children && hashObj.children.length > 0) {
                    //如果当前模块有默认的子模块,否则使用第一个可以是default的模块
                    var defaultChildren = hashObj.defaultPage;
                    if(defaultChildren){
                        var index = this.findItems(defaultChildren, "name", hashObj.children);
                        hashObj = hashObj.children[index];
                    } else{
                        for (var i = 0; i < hashObj.children.length; i++) {
                            if (!hashObj.children[i].notDefaultPage) {
                                hashObj = hashObj.children[i];
                                break;
                            }
                        }
                    }
                }
                return hashObj.name;
            }

        };
        //将不在菜单中的特殊路由补入router
        ModuleRouter.prototype._getMainMenuDefaultPage = function(){
            if (this.defaultPage) {
                return this.defaultPage;
            } else {
                for (var i in _hashMap) {
                    if(_hashMap.hasOwnProperty(i)) {
                        if (_hashMap[i].self.defaultPage) {
                            this.defaultPage = _hashMap[i].self.name;
                            return this.defaultPage;
                        }
                    }
                }
            }
        };
        ModuleRouter.prototype.getCurrentPage = function(){
            return this.currentPage;
        };
        ModuleRouter.prototype.getHashMap = function(){
            return _hashMap;
        };
        ModuleRouter.prototype.getMetaPage = function(name){
            //返回元信息，并作删除
            var meta = _hashMap[name].self.meta;
            if(meta){
                //看元信息是否是持久化存储的
                if(!(meta.persistence == true)){
                    this.deleteAttr(name, "meta");
                }
                return meta.name;
            }
        };
        return ModuleRouter;
    })();
})(jQuery);