(function($){
    $.su = $.su || {};

    $.su.Services = $.su.Services || {};

    /*
     * @service ModuleLoader
     * */
    $.su.Services.ModuleLoader= (function() {
        var ModuleLoader = function () {
            if (typeof ModuleLoader.instance === 'object') {
                return ModuleLoader.instance;
            }

            this.name = 'moduleLoader';
            $.su.Service.call(this);

            ModuleLoader.instance = this;

            this._map = {};
            this.loadingModule = {};
            // this._
        };

        $.su.inherit($.su.Service, ModuleLoader);

        var _searchViewInfo = function (arr, id) {
            //tree
            return arr[id];
        };

        var generateMapItemID = function(module, view){
            return module + '_' + view;
        };


        ModuleLoader.prototype.load = function (parentViewInfo, childViewInfo, htmlLoader, callback) {
            var me = this;
            var htmlLoader = (htmlLoader && htmlLoader.viewObjs) ? htmlLoader.viewObjs[0] : htmlLoader;
            if (!htmlLoader) {
                return;
            }
            var parentViewModule = parentViewInfo.module;
            var parentModule = $.su.moduleManager.query(parentViewModule);
            if (!parentModule) {
                return;
            }
            this.isBusy = true;
            var parentView = parentViewInfo.view || parentModule.view[0];
            var parentId = generateMapItemID(parentViewModule, parentView);
            var parentItem = _searchViewInfo(this._map, parentId);
            var childViewModule = childViewInfo.module;

            // save current loading id
            // to cancel all previous loading
            var timeStamp = $.su.randomId("timestamp");
            this.loadingModule[childViewModule] = {};
            this.loadingModule[childViewModule][timeStamp] = "running";

            if (!parentItem) {
                parentItem = this._map[parentId] = {
                    id: parentId,
                    module: parentViewModule,
                    view: parentView,
                    children: [],
                    htmlLoader: null,
                    parent: null
                };
            }
            me.unLoad(htmlLoader);

            $.su.moduleManager.load(childViewModule).then(function () {
                if(!me.loadingModule[childViewModule][timeStamp]) {
                    // when A->B repeatly, the second loading may not launch because it's status is 'running'
                    // so ignore the first launch
                    return $.Deferred().reject("Waring: Loading module too fast.");
                }
                if(htmlLoader.dataObj === null) {
                    // when A->B->C repeatly, htmlLoader in B may be unloaded (in second time)
                    // then B->C throws error (in first time)
                    // so cancel the first loading
                    return $.Deferred().reject("Waring: Loading module too fast.");
                }
                var childModule = $.su.moduleManager.query(childViewModule);
                var childView = childViewInfo.view || childModule.view[0];
                var childId = generateMapItemID(childViewModule, childView);

                if (!me._map[childId]) {
                    me._map[childId] = {
                        id: childId,
                        module: childViewModule,
                        view: childView,
                        children: [],
                        htmlLoader: null,
                        parent: parentId
                    }
                } else {
                    if (me._map[childId].htmlLoader) {
                        me.unLoad(me._map[childId].htmlLoader);
                    }
                }
                me._map[childId].htmlLoader = htmlLoader;
                if ($.inArray(childId, parentItem.children) < 0) {
                    parentItem.children.push(childId);
                }
                htmlLoader.bind(childViewInfo);
                me.isBusy = false;
                return childModule.load(childViewInfo.params);
            }).then(function() {
                delete me.loadingModule[childViewModule][timeStamp];
                htmlLoader.initEmitter();
                !!callback && callback($.su.moduleManager.query(childViewModule));
            }).fail(function(err) {
                $.su.debug.warn(err);
            });
        };

        ModuleLoader.prototype.unLoad = function (htmlLoader) {
            var _notifyItemModule = function (map, item) {
                var moduleName = map[item].module;
                var module = $.su.moduleManager.query(moduleName);
                var children = map[item].children.slice(0);
                if (children && (children.length > 0)) {
                    for (var i = 0; i < children.length; i++) {
                        _notifyItemModule(map, children[i]);
                    }
                }

                !!module.fireEvent && module.fireEvent("ev_before_view_unload", [map[item].view]);
                if (map[item].htmlLoader !== null) {
                    map[item].htmlLoader.unload();
                }

                if (module) {
                    module.fireEvent("ev_view_unload", [map[item].view]);
                }
                map[item].children = [];
                map[item].htmlLoader = null;
                if(map[item].parent){
                    var parentInfoNode = _searchViewInfo(map, map[item].parent);
                    var index = $.inArray(item, parentInfoNode.children)
                    if(index >= 0){
                        parentInfoNode.children.splice(index, 1);
                    }
                }
            };

            for (var item in this._map) {
                if (this._map.hasOwnProperty(item)) {
                    if (this._map[item].htmlLoader === htmlLoader) {
                        _notifyItemModule(this._map, item);
                    }
                }
            }
        };

        return ModuleLoader;
    })();

})(jQuery);
