// JavaScript Document
(function ($) {

	$.su = $.su || {};

	$.su.debug = $.su.debug || {
			log: function () {
			},
			warn: function () {
			},
			error: function () {
			}
		};

	/**
	 *@description 定义全局的ajax设置
	 */
	$.ajaxSetup({
		type: "POST",
		cache: true,
		success: function (data, status, xhr) {
			// console.log("ajax success!", xhr, status);
		},
		error: function (xhr, status, error) {
			// console.log("ajax error!", xhr, status, error);
		}
	});

	// $.getScript = function(url, callback){
	// 	return $.ajax({
	// 		url: url,
	// 		type: "get",
	// 		cache: true,
	// 		success: callback,
	// 		dataType: "script"
	// 	});
	// };

	/**
	 *@description 数据格式化相关函数
	 */
	$.su.format = {};
	$.su.format.capitalize = function (string) {
		string = string.toLowerCase();
		return string.replace(/\b(\w)|\s(\w)/g, function (s) {
			return s.toUpperCase();
		});
	};


	/**
	 *@class 数据基类
	 */
	// $.su.Record = function(){
	// 	var _data = {};
	// 	this.getData = function(){
	// 		return _data;
	// 	};
	// 	this.setData = function(data){
	// 		_data = data;
	// 	};
	// };


	//公用函数
	$.su.getAttrObject = function (root, attrString) {
		// transform primitive value
		try {
			var fn = new Function("return " + attrString);
			return fn();
		} catch (e) {}

		attrString = attrString.replace(/[\{,\}]/g, "");

		if (!attrString) {
			return "";
		}

		if (attrString === 'true') {
			return true;
		} else if (attrString === 'false') {
			return false;
		}

		if (/^\d+$/.test(attrString)) {
			return parseInt(attrString, 10);
		}

		var stringList = attrString.split(".");
		var r = root;
		var index = 0;
		var len = stringList.length;

		while (index < len) {
			r = r[stringList[index]];
			if (!r) {
				return false;
				// console.error("$.su.getAttrObject error: ", attrString);
			}
			index++;
		}
		if (!r) {
			return false;
			// console.error("$.su.getAttrObject error: ", attrString);
		}
		return r;
	};

	$.su.formatAttrName = function (name) {
		var attrNameTmpArr = name.split('-');
		for (var num = 0; num < attrNameTmpArr.length; num++) {
			if (num !== 0) {
				attrNameTmpArr[num] = attrNameTmpArr[num].replace(/(\w)/, function (v) {
					return v.toUpperCase();
				});
			}
		}
		return attrNameTmpArr.join('');
	};

	// $.su.getAttrDataModel = function(attrString){
	// 	if(!attrString){
	// 		return false;
	// 	}
	//
	// 	attrString = attrString.replace(/[\{,\}]/g, "");
	// 	var stringList = attrString.split(".");
	//
	// 	if(stringList.length == 1){
	// 		if($.su.modelManager.get(stringList[0])){
	// 			return $.su.modelManager.get(stringList[0]);
	// 		}else if($.su.storeManager.get(stringList[0])){
	// 			return $.su.storeManager.get(stringList[0]);
	// 		}
	// 	}
	//
	// 	if($.su.modelManager.get(stringList[0])){
	// 		return $.su.modelManager.get(stringList[0]).getField(stringList[1]);
	// 	}
	// 	/* else if($.su.storeMgr.get(stringList[0])){	//left to be defined
	// 	 return $.su.storeMgr.get(stringList[0])
	// 	 } */
	//
	// 	return false;
	// };

	// $.su.
	$.su.randomId = function (type) {
		return type + "-" + $.su.guid();
	};

	$.su.guid = function () {

		var hexadecimal = function (num, x, y) {
			if (y !== undefined) {
				return parseInt(num.toString(), y).toString(x);
			} else {
				return parseInt(num.toString()).toString(x);
			}
		};
		var getGUIDDate = function (date) {
			return date.getFullYear() + addZero(date.getMonth() + 1) + addZero(date.getDay());
		};
		var addZero = function (num) {
			if (Number(num).toString() != 'NaN' && num >= 0 && num < 10) {
				return '0' + Math.floor(num);
			} else {
				return num.toString();
			}
		};
		var getGUIDTime = function (date) {
			return addZero(date.getHours()) + addZero(date.getMinutes()) + addZero(date.getSeconds()) + addZero(parseInt(date.getMilliseconds() / 10));
		};

		var formatGUID = function (guidStr) {
			var str1 = guidStr.slice(0, 8) + '-',
				str2 = guidStr.slice(8, 12) + '-',
				str3 = guidStr.slice(12, 16) + '-',
				str4 = guidStr.slice(16, 20) + '-',
				str5 = guidStr.slice(20);
			return str1 + str2 + str3 + str4 + str5;
		};


		var date = new Date();
		var guidStr = '';
		var sexadecimalDate = hexadecimal(getGUIDDate(date), 16);
		var sexadecimalTime = hexadecimal(getGUIDTime(date), 16);
		for (var i = 0; i < 9; i++) {
			guidStr += Math.floor(Math.random() * 16).toString(16);
		}
		guidStr += sexadecimalDate;
		guidStr += sexadecimalTime;
		while (guidStr.length < 32) {
			guidStr += Math.floor(Math.random() * 16).toString(16);
		}

		return formatGUID(guidStr);
	};

	$.su.clone = function (obj) {
		var result, index;
		var type = $.type(obj);
		switch (type) {
			case "array":
				result = [];
				for (index = 0; index < obj.length; index++) {
					result[index] = $.su.clone(obj[index]);
				}
				return result;
			case "object":
				result = {};
				for (index in obj) {
					result[index] = $.su.clone(obj[index]);
				}
				return result;
			case "null":
				return null;
			case "undefined":
				return undefined;
			case "function":
				return obj;
			case "string":
				result = obj;
				return result;
			case "number":
				result = obj;
				return result;
			case "boolean":
				if (!obj) {
					return false;
				} else {
					return true;
				}
				break;
			default:
				return undefined;
		}
	};

	/* 返回一个自定义事件的对象obj，obj.ev可在trigger自定义事件中传给监听函数
	 * 监听函数通过ev.preventDefault()来阻止自定义事件的默认方法执行。
	 * obj.exe()写在trigger之后，会根据监听函数是否preventDefault来确认是否调用func
	 * args: 作用域 函数 参数
	 */
	$.su.getDefaultEvent = function (obj, func, args) {
		var flag = true;
		if (args === undefined || args === null) {
			args = [];
		} else if (!$.isArray(args)) {
			args = [args];
		}

		return {
			exe: function () {
				if (flag) {
					func.apply(obj, args);
				}
				return flag;
			},
			ev: {
				preventDefault: function () {
					flag = false;
				}
			}
		};
	};

	/*
	 * 使用浏览器原生的方法转义特殊字符
	 */
	$.su.transSpecialChar = function (str) {
		var div = document.createElement('div');
		if (div.innerText !== undefined) {
			div.innerText = str;
		} else {
			div.textContent = str;//Support firefox
		}
		return div.innerHTML;
	};

	$.su.inherit = function (parentClass, childClass) {
		if (typeof parentClass != 'function' || typeof childClass != 'function') {
			return false;
		}
		var Tmp = function () {
		};
		Tmp.prototype = parentClass.prototype;
		childClass.prototype = new Tmp();
		childClass.prototype.constructor = childClass;
		childClass.superclass = parentClass.prototype;
	};

	$.su.getCookie = function () {
		var sliceStr;
		var srcStr;
		var tmpstring = document.cookie;
		while (tmpstring.length > 0) {
			var submitStr;
			sliceStr = tmpstring.indexOf(";");
			if (sliceStr == -1) {
				srcStr = tmpstring;
				if (checkCookie(srcStr) === true) {
					sliceStr = srcStr.indexOf("=");
					if (sliceStr == -1)return null;
					submitStr = strmodify(srcStr.slice(sliceStr + 1));
					return submitStr;
				}
			} else {
				srcStr = tmpstring.slice(0, sliceStr);
				if (checkCookie(srcStr) === true) {
					sliceStr = srcStr.indexOf("=");
					if (sliceStr == -1)return null;
					submitStr = strmodify(srcStr.slice(sliceStr + 1));
					return submitStr;
				}
			}
			tmpstring = tmpstring.slice(sliceStr + 1);
		}
		function checkCookie(srcStr) {
			var sliceStr = srcStr.indexOf("=");
			var testStr = strmodify(srcStr.slice(0, sliceStr)).toUpperCase();
			return (testStr == "COOKIE");
		}

		function strmodify(str) {
			var localStr = "";
			var len = str.length;
			var i, j;
			var charStr;
			for (i = 0; i < len; i++) {
				if (document.all) {
					charStr = str.slice(i, i + 1);
					if (charStr != ' ') {
						break;
					}
				} else {
					if (str[i] != ' ') {
						break;
					}
				}
			}
			for (j = (len - 1); j > 0; j--) {
				if (document.all) {
					charStr = str.slice(j, j + 1);
					if (charStr != ' ') {
						break;
					}
				} else {
					if (str[j] != ' ') {
						break;
					}
				}
			}
			if (j < i) {
				return localStr;
			} else {
				localStr = str.slice(i, j + 1);
			}
			return localStr;
		}

		return null;
	};

	// 覆盖原jQuery方法

	// IE8下jQuery的inArray方法会报错，因此选择覆盖此方法
	// add by maihaihua 2017/5/11.
	$.inArray = function (item, arr) {
		if (!$.isArray(arr)) {
			return -1;
		}

		for (var i = 0, len = arr.length; i < len; i++) {
			if (arr[i] === item) {
				return i;
			}
		}
		return -1;
	};

	$.su.getObjectLength = function (object) {
		var length = 0;
		if (object) {
			for (var i in object) {
				if (object.hasOwnProperty(i)) {
					length++;
				}
			}
		}
		return length;
	};

	$.su.isEmptyObject = function (obj) {
		for (var name in obj) {
			return false;
		}
		return true;
	};

	// ie <= 8
	$.su.isIe8 = $.su.isIe = (new Function('return !-[1,];'))();
	$.su.platform = (function () {
		if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
			return 'ios';
		} else if (/(Android)/i.test(navigator.userAgent)) {
			return 'android';
		} else {
			return 'pc';
		}
		;
	})();

	$.su.escapeHtml = function(string){
		if (string && string.toString) {
			var r = string.toString();
			r = r.replace(/\&/g, "&amp;");
			r = r.replace(/\</g, "&lt;");
			r = r.replace(/\>/g, "&gt;");
			r = r.replace(/\"/g, "&quot;");
			r = r.replace(/\s/g ,"&nbsp;");

			return r;
		} else {
			return string;
		}
		
	};

	$.su.unEscapeHtml = function(string){
		if (string && string.toString) {
			var r = string.toString();
			r = r.replace(/&amp;/g, "&");
			r = r.replace(/&lt;/g, "<");
			r = r.replace(/&gt;/g, ">");
			r = r.replace(/&quot;/g, '"');
			r = r.replace(/&nbsp;/g ,' ');

			return r;
		} else {
			return string;
		}
	};

	$.su.getBrowseVersion = function () {
		var Sys = {};
		var ua = navigator.userAgent.toLowerCase();
		var s;
		(s = ua.match(/msie ([\d.]+)/)) ? (Sys["browse"] = "ie", Sys["version"] = s[1]) :
			(s = ua.match(/firefox\/([\d.]+)/)) ? (Sys["browse"] = "firefox", Sys["version"] = s[1]) :
				(s = ua.match(/chrome\/([\d.]+)/)) ? (Sys["browse"] = "chrome", Sys["version"] = s[1]) :
					(s = ua.match(/opera.([\d.]+)/)) ? (Sys["browse"] = "opera", Sys["version"] = s[1]) :
						(s = ua.match(/version\/([\d.]+).*safari/)) ? (Sys["browse"] = "safari", Sys["version"] = s[1]) : 0;
		return Sys;
	};

	/*
	 * 简单扩展对象(extJs方法，去掉了enumerables数组的扩展)
	 */
	$.su.apply = function (object, config, defaults) {
		if (defaults) {
			$.su.apply(object, defaults);
		}

		if (object && config && typeof config === 'object') {
			var i, j, k;

			for (i in config) {
				if (config.hasOwnProperty(i)) {
					object[i] = config[i];
				}
			}

			// if (enumerables) {
			// 	for (j = enumerables.length; j--;) {
			// 		k = enumerables[j];
			// 		if (config.hasOwnProperty(k)) {
			// 			object[k] = config[k];
			// 		}
			// 	}
			// }
		}

		return object;
	};

	$.su.valueEqual = function (a, b) {
		if (a === b) {
			// number(not NaN), string, null, undefined, boolean
			return true;
		}
		var typeA = $.type(a);
		var typeB = $.type(b);
		if (typeA !== typeB) {
			return false;
		} else {
			switch (typeA) {
				case "array":
				case "object":
					return JSON.stringify(a) === JSON.stringify(b);
				default:
					return false;
			}
		}
	};

	$.su.isMobile = function () {
		var check = false;
		(function (a) {
			if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true
		})(navigator.userAgent || navigator.vendor || window.opera);
		return check;
	};

	$.su.encodePara = function(val) {
		if (val && val.toString) {
			return encodeURIComponent(val.toString());
		} else {
			return val;
		}
		
	};
	$.su.decodePara = function(val) {
		if (val && val.toString) {
			return decodeURIComponent(val.toString());
		} else {
			return val;
		}
	};
	// 返回 function 函数的去抖版本, 将延迟函数的执行(真正的执行)在函数最后一次调用时刻的 wait 毫秒之后. 对于必须在一些输入（多是一些用户操作）停止到达之后执行的行为有帮助。
	$.su.debounce = function(func, wait, immediate) {
		var timeout;
		return function() {
			var context = this, args = arguments;
			var later = function() {
				timeout = null;
				if (!immediate) func.apply(context, args);
			};
			var callNow = immediate && !timeout;
			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
			if (callNow) func.apply(context, args);
		};
	};
	// 返回 function 函数的节流版本，至少每隔duration毫秒调用一次该函数，最后一次延迟wait秒执行
	$.su.throttle = function(func, wait, duration) {
		var timeout, startTime = new Date();
		return function() {
			var context = this, args = arguments, curTime = new Date();
			clearTimeout(timeout);
			if(curTime - startTime >= duration) {
				func.apply(context, args);
				startTime = curTime;
			} else {
				timeout = setTimeout(func, wait);
			}
		};
	};
	//get maxZIndex 
	$.su.getMaxZIndex = function () {
		var maxZ = Math.max.apply(null,
			$.map($('body div:visible'), function(e,n) {
				if ($(e).css('position') != 'static' && $(e).width() != 0 && $(e).height() != 0)
					return parseInt($(e).css('z-index')) || 1;
			}));
		return maxZ;
	};
	$.su.adjustViewPort = function() {
		if ($.su.isMobile()) {
			var viewport = $('meta[name="viewport"]')[0];
			viewport.content = "width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=0";
			if ($(window).width() > 767) {
				viewport.content = "width=767,user-scalable=0";
			}
		}
	};
	$.su.waiting = function(fn, failHandler, timeout) {
		if ($.type(fn) !== "function" || $.su.development !== true) {
			return fn;
		}
		timeout = timeout || 2000;
		var timeoutId = setTimeout(failHandler, timeout);
		return function() {
			clearTimeout(timeoutId);
			fn && fn();
		}
	}
	$.su.version = function() {
		return $('head meta[name=version]').attr('content');
	}
})(jQuery);