(function($) {
	$.su = $.su || {};
	$.su.Language = (function() {
		var getDefaults = function(){
			return {
				locale: "en_US",
				DEFAULT_LAN_TYPE: "en_US",
				URL_JS: "./locale/%LAN_TYPE%/lan.js",
				URL_CSS: "./locale/%LAN_TYPE%/lan.css?t=ebd0dc2b",
				URL_HELP: "./locale/%LAN_TYPE%/help.js",
				AJAX: {
					type: "POST",
					async: false,
					contentType: "text/plain;charset=UTF-8",
					dataType: "text",
					timeout: 15*1000,
					url: $.su.url("?code=2&asyn=0"),
					data: "50|1,0,0"
				}
			}
		};

		var Language = function(options) {
			this.settings = $.extend({}, getDefaults(), options);
			this.init();
		};
		Language.prototype.getList = function(){
			return this.languageList || [];
		};
		Language.prototype.init = function(){
			this.changeType(this.getLocale());
		};

		Language.prototype.getLocale = function(){
			var that = this;
			var settings = this.settings;
			if (this.locale) {
				return this.locale
			} else {
				$.ajax($.extend(settings.AJAX, {
					success: function(data){
						try {
							var language = data.match(/\bcurrentLanguage\s(\w*)\b/)[1];
							var lanListOriData = data.match(/\blanguageList\s(.*)\b/)[1];
						} catch (e) {
							throw "data error in language.getLocale"
						}
						
						//var lanListOriData = data.match(/\blanguageList\s\d+\s(.*)\b/g);
						lanListOriData = lanListOriData.split(',');
						that.languageList = [];
						for (var i = 0 ; i < lanListOriData.length; i++) {
							// var tempLan = lanListOriData[i].split(' ')[2];
							var tempLan = lanListOriData[i];
							if (tempLan && tempLan.length > 0) {
								that.languageList.push(tempLan);
							}
						}
						that.locale = language || settings.locale;
					}
				}));
				return this.locale;
			}
		};

		Language.prototype.defineGlobal = function(){};

		Language.prototype.getDeviceLanguage = function(){};

		Language.prototype.getClientLanguage = function(){};

		Language.prototype.reset = function(){
			this.changeType({
				"locale": this.settings.DEFAULT_LAN_TYPE,
				"force": false,
				"model": "",
				"region": "",
				"rebootTime": 0
			});
		};

		Language.prototype.changeType = function(locale){
			var settings = this.settings,
				lanType = locale || settings.DEFAULT_LAN_TYPE;
			var URL_JS = settings.URL_JS.replace("%LAN_TYPE%", lanType);
			var URL_CSS = settings.URL_CSS.replace("%LAN_TYPE%", lanType);

			$("script#lan-js").remove();
			$("link#lan-css").remove();

			$("head").append('<script id="lan-js" type="text/javascript" src="'+URL_JS+' "></script>')
				.append('<link id="lan-css" type="text/css" rel="stylesheet" href="'+URL_CSS+' "/>')
				.append("<script type=\"text/javascript\" src=\"./locale/language.js\" ></script>");
		};

		return Language;
	})();
})(jQuery)
