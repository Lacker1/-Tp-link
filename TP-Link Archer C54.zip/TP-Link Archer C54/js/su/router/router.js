// JavaScript Document
(function($){

	$.su.Router = (function(){

		var Router = function(){
			$.su.Observable.call(this);

			this.routerList = {};
			this.modelsMap = {};
			this.helpMap = {};

		};
		$.su.inherit($.su.Observable, Router);

		Router.prototype.set = function(list){
			var list = list;
			if ($.isEmptyObject(list)){
				return;
			}
			$.each(list, function(module, obj){
				if(typeof obj.controller === "string"){
					obj.controller = {
						_default: obj.controller
					}
				}
				if(typeof obj.view === "string"){
					obj.view = {
						_default: obj.view
					}
				}
			});
			this.routerList = list;
		};


		Router.prototype.setItem = function(name, option){
			if(this.routerList[name]){
				$.extend(true, this.routerList[name], option)
			}else{
				this.routerList[name] = option;
			}
			if(typeof this.routerList[name].controller === "string"){
				this.routerList[name].controller = {
					_default: this.routerList[name].controller
				}
			}
			if(typeof this.routerList[name].view === "string"){
				this.routerList[name].view = {
					_default: this.routerList[name].view
				}
			}
		};

		Router.prototype.query = function(name){
			return this.routerList[name];
		};

		Router.prototype.loadController = function(arg1, arg2, arg3){
			var name = arg1;
			var controller;
			var callback;
			if(typeof arg2 === "function"){
				callback = arg2;
			}else{
				controller = arg2;
				callback = arg3;
			}
			var routerObj = this.routerList[name];

			if(!controller){
				$.su.loader.loadFile(routerObj.controller._default, callback);
			}else{
				if(routerObj.controller[controller]){
					$.su.loader.loadFile(routerObj.controller[controller], callback);
				}
			}
		};
		Router.prototype.loadView = function(arg1, arg2, arg3){
			var name = arg1;
			var view;
			var callback;
			if(typeof arg2 === "function"){
				callback = arg2;
			}else{
				view = arg2;
				callback = arg3;
			}
			var routerObj = this.routerList[name];

			if(!view || !routerObj.view[view]){
				$.su.loader.loadFile(routerObj.view._default, callback);
			}else{
				if(routerObj.view[view]){
					$.su.loader.loadFile(routerObj.view[view], callback);
				}
			}
		};

		Router.prototype.setModelsPath = function(modelsPathMap){
			for(var item in modelsPathMap){
				if(modelsPathMap.hasOwnProperty(item)){
					this.modelsMap[item] = modelsPathMap[item];
				}
			}
		};

		Router.prototype.loadModel = function(name, callback){
			var me = this;
			if(!this.modelsMap[name]){
				throw new Error('Model "' + name + '" has not declare file path');
			}else{
				$.su.loader.loadFile(this.modelsMap[name], callback);
			}
		};

		Router.prototype.setHelpPath = function(helpMap) {
			for (var item in helpMap) {
				if (helpMap.hasOwnProperty(item)) {
					this.helpMap[item] = helpMap[item];
				}
			}
		};

		Router.prototype.loadHelp = function(name, callback) {
			var path;
			if (this.helpMap[name]) {
				path = this.helpMap[name];
			} else {
				// var textName = name.replace(/[A-Z]/g, function(l){
				//     return '_'+l;
				// });
				path = {
					struct: name + '.html',
					name: name
				};
			}
			$.su.loader.loadFile('./help/' + path.struct, function(data) {
				callback(path.name, data);
			});
		};
		return Router;
	}());
})(jQuery);
