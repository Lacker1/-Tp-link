// JavaScript Document
(function($){

$.su = $.su || {};

$.su.ModuleManager = function(){
	var ModuleManager = function(){
		$.su.Manager.call(this);
		this.type = $.su.Module;

		this._depMap = {};
		this._toLoading = [];
		this._toDestroy = [];
	};
	$.su.inherit($.su.Manager, ModuleManager);

	var geneLoadRequiresFn = function(name) {
		var me = this;
		var settings = this._infoMap[name].settings;
		var models = settings.models;
		var stores = settings.stores;
		var deps = settings.deps;
		var views = settings.views;

		var loadModels = function(models) {
			var loadModelsPromises = $.map(models, function(modelName, i) {
				return (function() {
					var dfd = $.Deferred();
					if (!$.su.modelManager.isDefined(modelName)) {
						$.su.modelManager.loadDefine(modelName, dfd.resolve);
					} else {
						dfd.resolve();
					}
					return dfd.promise();
				})();
			});
			return $.when.apply(this, loadModelsPromises);
		};

		var loadStores = function(stores) {
			var loadStoresPromises = $.map(stores, function(storeName, i) {
				return (function() {
					var dfd = $.Deferred();
					if (!$.su.storeManager.isDefined(storeName)) {
						$.su.storeManager.loadDefine(storeName, dfd.resolve);
					} else {
						dfd.resolve();
					}
					return dfd.promise();
				})();
			});
			return $.when.apply(this, loadStoresPromises);
		};

		var loadViews = function(views) {
			var loadViewsPromises = $.map(views, function(viewName, i) {
				return (function() {
					var dfd = $.Deferred();
					if (!$.su.viewManager.isDefined(viewName, name)) {
						$.su.viewManager.loadDefine(viewName, name, dfd.resolve);
					} else {
						dfd.resolve();
					}
					return dfd.promise();
				})();
			});
			return $.when.apply(this, loadViewsPromises);
		};

		var loadDeps = function(deps) {
			var loadDepsPromises = $.map(deps, function(depName, i) {
				return (function() {
					var dfd = $.Deferred();
					if (!$.su.moduleManager.isDefined(depName)) {
						switch ($.su.moduleManager.getStatus(depName)) {
							case $.su.Module.STATUS.DEFINE_NOT_LOADED:
								$.su.moduleManager.loadDefine(depName, dfd.resolve);
								break;
							case $.su.Module.STATUS.LOADING_DEFINE:
								if($.inArray(name, me._infoMap[depName].settings.deps) >= 0) {
									return dfd.reject("Error: module \"" + depName + "\" and \"" + name + "\" can not depend each other in \"deps\"");
								}
								$.su.moduleManager.loadDefine(depName, dfd.resolve);
								break;
							default:
								dfd.resolve();
						}
					} else {
						dfd.resolve();
					}
					return dfd.promise();
				})();
			});
			return $.when.apply(this, loadDepsPromises);
		};

		return $.when(
			loadModels(models)/*.then(function () {console.log(`${name} models: ${models}`)})*/,
			loadStores(stores)/*.then(function () {console.log(`${name} stores: ${stores}`)})*/,
			loadViews(views)/*.then(function () {console.log(`${name} views: ${views}`)})*/,
			loadDeps(deps)/*.then(function () {console.log(`${name} deps: ${deps}`)})*/
		).fail(function(err) {
			$.su.debug.error(err);
		});
	};

	var _updateDepMap = function(module, deps){
		for(var i=0; i<deps.length; i++){
			if(this._depMap.hasOwnProperty(deps[i])){
				if(!($.inArray(this._depMap[deps[i]], module) >= 0)){
					this._depMap[deps[i]].push(module);
				}
			}else{
				this._depMap[deps[i]] = [module];
			}
		}
	};

	var generateDefinedEventName = function(name) {
		return "ev_module_" + name + "_defined";
	}

	ModuleManager.prototype.define = function(name, options, factory){
		var me = this;
		//参数验证
		//var module = new $.su.Module();
		var settings = $.extend({
			"name": name,
			deps: [],
			models: [],
			stores: [],
			views: []
		}, options);

		if(this._infoMap[name]){
			$.su.debug.error('Duplicated module definition "' + name + '"');
			return;
		}

		_updateDepMap.call(this, settings.name, settings.deps);

		this._infoMap[name] = {
			"settings": settings,
			"constructor": null,
			"status": $.su.Module.STATUS.LOADING_DEFINE
		};

		var Module = function(options){
			this.factory = factory;
			$.su.Module.call(this, options);
		};

		$.su.inherit($.su.Module, Module);
		// Module.prototype = $.extend(Module.prototype, injectDeps(factory, settings, _deps).call(Module.prototype));

		this._infoMap[name].constructor = Module;


		geneLoadRequiresFn.call(this, name).then(function(){
			me._infoMap[name].status = $.su.Module.STATUS.DEFINED;
			$(me).trigger(generateDefinedEventName(name));
		});
	};

	// ModuleManager.prototype.loadDefine = function(name, callback){
	// 	$.su.router.load(name, callback);
	// };

	// ModuleManager.prototype.load= function(id, callback){
	// 	if($.su.moduleManager.query(id)){
	// 		$.su.moduleManager.query(id).load(callback);
	// 	}
	// };

	//private func
	ModuleManager.prototype.query = function(id){
		if(this._map[id]){
			return this._map[id];
		}else{
			return false;
		}
	};

	ModuleManager.prototype.unload = function(id){
		if(this._map[id]){
			this._map[id].destroy();	//left
			delete this._map[id];
			this._infoMap[id].status = $.su.Module.STATUS.DEFINED;
		}
	};

	ModuleManager.prototype.loadDefine = function(name, callback){
		var me = this;
		var ev = generateDefinedEventName(name);
		if ($.su.moduleManager.getStatus(name) === $.su.Module.STATUS.DEFINE_NOT_LOADED) {
			$.su.router.loadController(name);
		}
		// if ($.inArray(name, this._toLoading) > -1) {
		// 	console.error("There is a dependencies loop:", this._toLoading.join(" -> ") + " -> " + name);
		// 	return;
		// }
		// this._toLoading.push(name);
		$(this).one(ev, function() {
			// var index = $.inArray(name, me._toLoading);
			// if (index > -1) {
			// 	me._toLoading.splice(index, 1);
			// }
			callback && callback();
		});
	};

	ModuleManager.prototype.load = function(name){
		var me = this;
		var dfd = $.Deferred();
		switch ($.su.moduleManager.getStatus(name)) {
			case $.su.Module.STATUS.DEFINED:
				// controller and models are loaded, module.load() has not run.
			case $.su.Module.STATUS.AVAILABLE:
				// module.load() has run.
				$.su.moduleManager.init(name);
				dfd.resolve();
				break;
			case $.su.Module.STATUS.LOADING_DEFINE:
				// controller is not loaded.
			case $.su.Module.STATUS.DEFINE_NOT_LOADED:
				// controller is loaded, models are not.
				$.su.moduleManager.loadDefine(name, function(){
					$.su.moduleManager.init(name);
					dfd.resolve();
				});
				break;
			default:
				$.su.debug.error("Module \"" + name + "\" is not defined.");
		}
		return dfd.promise();
	};

	ModuleManager.prototype.getStatus = function(name){
		var infoMap = this._infoMap;
		if(infoMap[name]){
			return infoMap[name].status;
		}else if($.su.router.query(name)){
			return $.su.Module.STATUS.DEFINE_NOT_LOADED;
		}else{
			return false;
		}
	};

	ModuleManager.prototype.isDefined = function(name){
		if(this._infoMap[name] && this._infoMap[name].status !== $.su.Module.STATUS.LOADING_DEFINE){
			return true;
		}
		return false;
	};

	ModuleManager.prototype.isAvailable = function(name){
		if(this._infoMap[name] && this._infoMap[name].status === $.su.Module.STATUS.AVAILABLE){
			return true;
		}
		return false;
	};

	ModuleManager.prototype.init = function(name){
		var me = this;
		if(!this._infoMap[name] || this._infoMap[name].status == $.su.Module.STATUS.AVAILABLE){
			return;
		}
		this._map[name] = new this._infoMap[name].constructor(this._infoMap[name].settings);
		this._infoMap[name].status = $.su.Module.STATUS.AVAILABLE;
		this._map[name].addListener("ev_to_destroy", function(e, name){
			me.prepareDestroy(name);
		});
	};

	ModuleManager.prototype.prepareDestroy = function(name){
		if(this._depMap[name]){
			for(var i=0; i<this._depMap[name].length; i++) {
				var module = this._depMap[name][i];
				if(this.isAvailable(module)){
					if($.inArray(name, this._toDestroy) === -1){
						this._toDestroy.push(name);
					}
					return;
				}
			}
		}
		this.unload(name);
		var index = $.inArray(name, this._toDestroy)
		if(index >= 0){
			this._toDestroy.splice(index, 1);
		}

		var deps = this._infoMap[name].settings.deps;
		for(var j=0; j<deps.length; j++) {
			if($.inArray(deps[j], this._toDestroy) >= 0){
				this.prepareDestroy(deps[j]);
			}
		}
	};

	ModuleManager.prototype.launch = function(name, callback){
		this.load(name, function(){
			$.su.moduleManager.query(name).load(callback);
		});
	};

	return ModuleManager;
}();

})(jQuery);