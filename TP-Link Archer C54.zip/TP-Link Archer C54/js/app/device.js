(function() {
	$.su = $.su || {};
	$.su.Services = $.su.Services || {};
	$.su.Services.Device = (function() {

		var defaults = {};
		var Device = function(options) {
			var device = this;
			this.settings = $.extend({}, defaults, options);
			this.settings.CONFIG_URL = "./config/device.json?t=ebd0dc2b";
			this.service = options.service;
			this.config = {};

			$.ajax(this.settings.CONFIG_URL, {
				async: false,
				method: "GET",
				dataType: "json",
				success: function(data ){
					$.extend(device.config, data);
				}
			});

			this.name = 'device';
			$.su.Service.call(this);
		};

		$.su.inherit($.su.Service, Device);
		Device.prototype.getConfig = function(){
			return this.config;
		};
		Device.prototype.getProductName = function(){
			var device = this;
			if (!this.config.deviceName){
				this.service.ajax.request({
					proxy: "deviceDataProxy",
					ajax:{
						async: false
					},
					method: "read",
					success: function(data){
						device.config.deviceName = data.modelName;
					}
				});
			}
			return this.config.deviceName;
		};

		Device.prototype.getLocale = function(){
			return $.su.language.getLocale();
		};

		Device.prototype.getForce = function () {
			return false;
		};

		Device.prototype.getCurrentMode = function(){
			var device = this;
			if (!this.config.mode){
				this.service.ajax.request({
					proxy: "deviceModeProxy",
					ajax:{
						async: false
					},
					method: "read",
					success: function(data){
						device.config.mode = data.mode;
					}
				});
			}
			return this.config.mode;
		};

		Device.prototype.getIsDualband = function(){
			var device = this;
			if (this.config.isDualband===undefined){
				this.service.ajax.request({
					ajax:{
						async: false
					},
					url: this.config.settings.CONFIG_URL,
					success: function(data){
						device.config.isDualband = JSON.parse(data).isDualband;
					}
				});

			}
			return this.config.isDualband;
		};

		Device.prototype.switchMode = function(mode, callback){
			this.service.ajax.request({
				proxy: "switchModeProxy",
				method: "switchMode",
				data: {
					mode: mode
				},
				success: function(data) {
					callback&&callback();
				}
			});
		};

		Device.prototype.getLanIptv = function(){
			return this.supportLanIptv;
		};

		Device.prototype.getHostMac = function() {
			var device = this;
			this.service.ajax.request({
				proxy: "getPeerMacProxy",
				ajax: {
					async: false
				},
				success: function(data) {
					device.config.hostMac = data;
				}
			});
			return this.config.hostMac || "";
		};

		Device.prototype.getRemote = function() {
			var device = this;
			if (this.config.remote === undefined) {
				this.service.ajax.request({
					proxy: "getRemoteProxy",
					method: "getRemote",
					ajax: {
						async: false
					},
					fail: function(data) {
						device.config.remote = data;
					}
				});
			}
			return this.config.remote || "";
		};

		Device.prototype.getRebootTime = function() {
			var rebootTime = this.getFunctionSupport().rebootTime;
			if (rebootTime != undefined && parseInt(rebootTime) > 0) {
				return parseInt(rebootTime) * 1000;
			}
			return this.config.rebootTime || 30000;
		};

		Device.prototype.getDomain = function() {
			var device = this;
			if (this.config.domain === undefined || this.config.domain === "/") {
				this.service.ajax.request({
					proxy: "rebootIPProxy",
					method: "read",
					ajax: {
						async: false
					},
					success: function(data) {
						device.config.domain = data[TPDOMAIN_DATA_ID].name || "/";
					}
				});
			}
			return this.config.domain || "/";
		};
		
		Device.prototype.getGdpr = function() {
			var device = this;
			if (this.config.gdpr === undefined) {
				if (this.config.gdprSupport === false) {
					this.config.gdpr = false
				} else {
					this.service.ajax.request({
						proxy: "gdprProxy",
						method: "getEnable",
						preventFailEvent: true,
						ajax: {
							async: false
						},
						success: function() {
							device.config.gdpr = true;
						},
						fail: function(data) {
							device.config.gdpr = false;
						}
					});
				}
			}
			return this.config.gdpr;
		};

		Device.prototype.getRole = function() {
			var device = this;
			if (this.getConfig().cloud) {
				this.service.ajax.request({
					proxy: "getRoleProxy",
					method: "read",
					ajax: {
						async: false
					},
					success: function(data) {
						device.config.role = data;
					}
				});
			} else {
				this.config.role = "-1"; //0 -- owner; WEB_SWITCH_DATA_ID1 -- user; -1 -- not sure, default
			}
			return this.config.role;
		};

		Device.prototype.getFunctionSupport = function() {
			var device = this;
			if (this.config.functionSupport === undefined) {
				this.service.ajax.request({
					proxy: "getFuncSupportProxy",
					method: "read",
					ajax: {
						async: false
					},
					success: function(data) {
						device.config.functionSupport = data;
					},
					fail: function() {
						device.config.functionSupport = null;
					}
				});
			}
			return this.config.functionSupport;
		};
		Device.prototype.getRSAParams = function() {
			var device = this;
			if (this.config.gdprSupport && $.su.encryptor) {
				device.config.RSAParams = $.su.encryptor.getRSAParams();
			} else {
				this.service.ajax.request({
					proxy: "gdprProxy",
					method: "getParams",
					preventFailEvent: true,
					preventErrorEvent: true,
					ajax: {
						async: false
					},
					success: function(data) {
						device.config.RSAParams = data;
					},
					fail: function() {
						device.config.RSAParams = null;
					}
				});
			}
			return device.config.RSAParams;
		};
		return Device;
	})();
})();
