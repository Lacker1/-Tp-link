// 设备制造商类型，默认0，表示TP系列
var TPLINK_FACTURER                          =          0; // TP机型
var MERCUSYS_FACTURER                        =          1; // 水星机型

// 系统模式，路由模式、Repeater模式等
var SYSTEM_MODE_BEGIN                        =          0; // 起始值，仅做边界检测
var SYSTEM_MODE_ROUTER                       =          1; // Router工作模式
var SYSTEM_MODE_AP                           =          2; // AP工作模式
var SYSTEM_MODE_RE                           =          3; // Repeater工作模式
var SYSTEM_MODE_WISP                         =          4; // WISP工作模式
var SYSTEM_MODE_END                          =          5; // 结束值，仅做边界检测

// WAN MAC的设置方式:default、pc、user set
var DEFAULT_MAC                              =          0; // 默认mac地址
var PC_MAC                                   =          1; // 使用PC的MAC地址
var USER_SET_MAC                             =          2; // 使用用户设置的MAC地址

// 当前log信息的等级
var LEVEL_EXCEPT                             =          0; // exception异常
var LEVEL_ERROR                              =          1; // 错误
var LEVEL_WARNING                            =          2; // 警告
var LEVEL_INFO                               =          3; // 提示
var LEVEL_DEBUG                              =          4; // 仅Debug

// router/wisp模式，用于处理lan wan冲突下是否允许自动修改IP，手动模式时不会自动改IP；不要和SMARTIP混淆
var LAN_MODE_AUTO                            =          0; // 允许系统在LAN WAN冲突时自动修改IP
var LAN_MODE_MANUAL                          =          1; // 不允许自动修改IP

// ap/re模式，自动模式(值为0)下无法手动更改IP，自动获取ip
var LAN_MODE_SMARTIP_AUTO                    =          0; // SMART IP模式，自动获取IP
var LAN_MODE_SMARTIP_MANUAL                  =          1; // 手动设置IP模式

// 远程主机访问控制规则，0：禁用所有，1：允许所有，2：允许指定主机
var HTTP_REMOTE_DISABLE_ALL                  =          0; // 禁止远程访问
var HTTP_REMOTE_ENABLE_ALL                   =          1; // 允许所有远程访问
var HTTP_REMOTE_ENABLE_SPECIFY               =          2; // 允许个别访问

// 主机所在网络类型（有线/无线/访客）
var STATION_WIRE                             =          0; // 有线
var STATION_WIRELESS_2G                      =          1; // 2G主网络
var STATION_GUESTNETWORK_2G                  =          2; // 2G访客网络
var STATION_WIRELESS_5G                      =          3; // 5G主网络
var STATION_GUESTNETWORK_5G                  =          4; // 5G访客网络

// 虚拟服务器映射条目传输层协议类型
var PROTOCOL_TYPE_ALL                        =          0; // 同时支持TCP和UDP
var PROTOCOL_TYPE_TCP                        =          1; // 支持TCP
var PROTOCOL_TYPE_UDP                        =          2; // 支持UDP

// WAN口接入类型
var LINK_TYPE_DHCP                           =          0; // DHCP
var LINK_TYPE_STATIC_IP                      =          1; // 静态IP
var LINK_TYPE_PPPOE                          =          2; // PPPOE
var LINK_TYPE_L2TP                           =          3; // L2TP
var LINK_TYPE_PPTP                           =          4; // PPTP
var LINK_TYPE_8021X                          =          5; // 802.1X
var LINK_TYPE_BPA                            =          6; // BigPon Cable
var LINK_TYPE_END                            =          7; // 边界检测

// WAN连接状态
var LINK_DOWN                                =          0; // 连接已断开
var LINK_UP                                  =          1; // 已经连接上
var LINKING_UP                               =          2; // 正在连接
var LINKING_DOWN                             =          3; // 正在断开

// WAN错误码，用于指示连接失败的原因
var LINK_CODE_NORMAL                         =          0; // WAN口正常
var LINK_CODE_MANUAL                         =          1; // 手动断开连接
var LINK_CODE_UNKNOWN                        =          2; // 未知错误
var LINK_CODE_DENY                           =          3; // 服务器拒绝。
var LINK_CODE_PHYDOWN                        =          4; // WAN口物理链路断开，即WAN口未插线
var LINK_CODE_NOECHO                         =          5; // 服务器无响应。
var LINK_CODE_SRVDOWN                        =          6; // 服务器主动断开连接。与DENY的区别在于这个是连接成功后断开？
var LINK_CODE_OPT_UNSUPPORT                  =          7; // 选项不支持导致拨号失败。
var LINK_CODE_AUTH_ERR                       =          8; // 用户名密码错误导致认证失败。
var LINK_CODE_AUTH_UNSUPPORT                 =          9; // 认证方式不支持。
var LINK_CODE_IP_CONFLICT                    =         10; // WAN口获得的IP与LAN口IP冲突
var LINK_CODE_NO_IPV4                        =         11; // WAN口未获取到IPv4地址
var LINK_CODE_RA_CHANGED                     =         12; // RA发生变化
var LINK_CODE_POOR_NETWOOK                   =         13; // 连接不到Internet

// 连接模式（按需/自动/手动）
var PPPOE_DEMAND                             =          0; // 按需拨号
var PPPOE_AUTO                               =          1; // 自动拨号
var PPPOE_TIMEING                            =          2; // 定时连接
var PPPOE_MANUAL                             =          3; // 手动拨号
var PPPOE_LINK_TYPE_MAX                      =          4; // 边界值

// 拨号模式（自动选择/正常/特殊拨号n）
var PPPOE_MODE_NORMAL                        =          0; // 正常拨号模式
var PPPOE_MODE_END                           =          1; // 这是什么？？？
var PPPOE_MODE_AUTOSELECT                    =        100; // 自动选择拨号模式

// 第二连接类型，0为禁用第二连接，1为DHCP，2为静态IP
var PPPOE_SNDCONN_NONE                       =          0; // 无第二连接
var PPPOE_SNDCONN_DYNAMIC                    =          1; // 第二连接为自动获取
var PPPOE_SNDCONN_STATIC                     =          2; // 第二连接为静态IP

// 三种时间来源：0:NTP、1:从PC获取、2:手动
var TIME_TYPE_NTP                            =          0; // 从NTP获取
var TIME_TYPE_PC                             =          1; // 从PC获取
var TIME_TYPE_MANUAL                         =          2; // 手工填入

// 目标访问条目类型，0-URL、1-IP、255-任意目标
var ACCESS_ANY_TARGET                        =        255; // 允许所有任意目标
var ACCESS_ANY_TIME                          =   16777215; // 允许所有任意目标

// 无线频段，2G、5G等
var WLAN_CHIP_2G                             =          0; // 2.4G
var WLAN_CHIP_5G                             =          1; // 5G
var WLAN_CHIP_5G_1                           =          2; // 5G芯片2，用于三频机型

// DUT工作模式，可以有Client，WDS Repeater等模式，默认为0，AP模式
var WLAN_AP_MODE_AP                          =          0; // AP模式，PC/PHONE<->LAN/WLAN<->DUT(AP)<->LAN<->Router
var WLAN_AP_MODE_CLIENT                      =          1; // Client模式，用于PC<->LAN<->DUT(Client)<->WLAN<->AP，此时DUT相当于网卡
var WLAN_AP_MODE_WDSRPT                      =          2; // WDS Repeater, PC/PHONE<->LAN/WLAN<->DUT(WDSRPT)<->WLAN<->Router
var WLAN_AP_MODE_UNIRPT                      =          3; // UNI Repeater, ???
var WLAN_AP_MODE_PPT                         =          4; // PPT???
var WLAN_AP_MODE_MPT                         =          5; // MPT???
var WLAN_AP_MODE_MAX                         =          6; // 边界检查

// 无线设备所在的区域管理标准，默认为0，即FCC标准
var DOMAIN_FCC                               =          0; // FCC认证
var DOMAIN_IC                                =          1; // IC认证
var DOMAIN_ETSI                              =          2; // CE认证，EU
var DOMAIN_SPAIN                             =          3; // 西班牙特殊认证
var DOMAIN_FRANCE                            =          4; // 法国特殊认证
var DOMAIN_MKK                               =          5; // 日本 MKK
var DOMAIN_ISRAEL                            =          6; // 以色列特殊认证
var DOMAIN_MKK1                              =          7; // MKK1认证
var DOMAIN_MKK2                              =          8; // MKK2认证
var DOMAIN_MKK3                              =          9; // MKK3认证
var DOMAIN_FCC_BR                            =         10; // FCC_BR认证
var DOMAIN_ETSI_RU                           =         11; // RU地区认证
var DOMAIN_2G_1_11_5G_1_4_TGT                =         12; // 2.4G:1-11 放开功率;5G:band1&band4 放开功率
var DOMAIN_2G_1_13_5G_1_4_TGT                =         13; // 2.4G:1-13 放开功率;5G:band1&band4 放开功率
var DOMAIN_2G_1_13_5G_1_4_CE                 =         14; // 2.4G:1-13 CE;5G:band1&band4,band1 CE,band4 放开功率
var DOMAIN_2G_1_11_5G_1_4_TGT1               =         15; // 2.4G:1-11 放开功率; 5G:band1&band4 放开功率(共版软件,后缀数字以区分)
var DOMAIN_MAX                               =         16; // 边界检测

// 选择的信道，为0表示自动选择
var WLAN_AUTO_CHANNEL                        =          0; // 自动信道

// 无线模式，例如11b，11g，11n等，默认为5，即11bgn混合模式
var WLAN_MODE_SELECT_MIN                     =          0; // 2G边界检查
var WLAN_MODE_11B_ONLY                       =          1; // 11b
var WLAN_MODE_11G_ONLY                       =          2; // 11g
var WLAN_MODE_11BG_MIXED                     =          3; // 11bg
var WLAN_MODE_11N_ONLY                       =          4; // 11n
var WLAN_MODE_11BGN_MIXED                    =          5; // 11gbn
var WLAN_MODE_11GN_MIXED                     =          6; // 11gn
var WLAN_MODE_SELECT_MAX                     =          7; // 2G边界
var WLAN_MODE_5G_SELECT_MIN                  =        100; // 5G边界
var WLAN_MODE_11A_ONLY                       =        101; // 5g 11a
var WLAN_MODE_11N_5G_ONLY                    =        102; // 5g 11n
var WLAN_MODE_11A_11N_MIXED                  =        103; // 5g 11an
var WLAN_MODE_11A_11N_11AC_MIXED             =        104; // 5g 11anac
var WLAN_MODE_11N_11AC_MIXED                 =        105; // 5g 11nac
var WLAN_MODE_5G_SELECT_MAX                  =        106; // 5G边界检测

// 频段带宽，1代表20MHz、2代表自动、3代表40MHz
var WLAN_CHAN_WIDTH_AUTO                     =          0; // 带宽自动
var WLAN_CHAN_WIDTH_20M                      =          1; // 20M带宽
var WLAN_CHAN_WIDTH_40M                      =          2; // 40M带宽
var WLAN_CHAN_WIDTH_80M                      =          3; // 80M带宽
var WLAN_CHAN_WIDTH_80M_ADD_80M              =          4; // 80+80M带宽

// RTS阈值，取值1-2346。默认2346
var WLAN_RTS_MAX                             =       2346; // 最大值
var WLAN_RTS_MIN                             =          1; // 最小值
var WLAN_RTS_DEF                             =       2346; // 默认值

// 分片阈值，取值256-2346。默认2346
var WLAN_FRAG_THRESHOLD_MAX                  =       2346; // 最大值
var WLAN_FRAG_THRESHOLD_MIN                  =        256; // 最小值
var WLAN_FRAG_THRESHOLD_DEF                  =       2346; // 默认值

// 发送Beacon的时间间隔，取值40-1000。默认100ms
var WLAN_BINTVAL_MAX                         =       1000; // 最大值
var WLAN_BINTVAL_MIN                         =         40; // 最小值
var WLAN_BINTVAL_DEF                         =        100; // 默认值

// 传输功率，1为高，2为中，3为低
var WLAN_ADV_TX_POWER_MIN                    =          0; // 边界检测
var WLAN_ADV_TX_POWER_HIGH                   =          1; // 高功率
var WLAN_ADV_TX_POWER_MEDIUM                 =          2; // 中功率
var WLAN_ADV_TX_POWER_LOW                    =          3; // 低功率
var WLAN_ADV_TX_POWER_MAX                    =          4; // 边界检测

// DTIM时间间隔，取值1-255。默认为1
var WLAN_DTIM_MAX                            =        255; // 最大值
var WLAN_DTIM_MIN                            =          1; // 最小值
var WLAN_DTIM_DEF                            =          1; // 默认值

// wds认证加密类型，范围1-7，为1为不加密
var WLAN_WDS_AUTH_MIN                        =          0; // 边界检测
var WLAN_WDS_AUTH_NONE                       =          1; // 无加密
var WLAN_WDS_AUTH_WEP_ASCII                  =          2; // WEP，ASCII模式
var WLAN_WDS_AUTH_WEP_HEX                    =          3; // WEP，HEX模式
var WLAN_WDS_AUTH_PSK2_AES                   =          4; // WPA2-PSK+AES
var WLAN_WDS_AUTH_PSK_AES                    =          5; // WPA-PSK+AES
var WLAN_WDS_AUTH_PSK2_TKIP                  =          6; // WPA-PSK2+TKIP
var WLAN_WDS_AUTH_PSK_TKIP                   =          7; // WPA-PSK+TKIP
var WLAN_WDS_AUTH_MAX                        =          8; // 边界检测

// 无线地址格式，1为自动探测，2为三地址，3为四地址
var WLAN_ADV_DETECT_AUTO                     =          0; // 自动侦测
var WLAN_ADV_DETECT_3ADDR                    =          1; // 3地址
var WLAN_ADV_DETECT_4ADDR                    =          2; // 4地址

// 该无线接口的在驱动中的接口号
var UNIT_MAIN                                =          0; // 主接口
var UNIT_GUESTNETWORK                        =          1; // 客户网络接口
var UNIT_APC                                 =          2; // APC接口
var UNIT_MAX                                 =          3; // 边界检测

// Radius服务器端口号，默认1812
var WLAN_RADIUS_PORT_DEFAULT                 =       1812; // 默认端口

// WEP密钥的格式
var WLAN_WEP_HEX                             =          0; // HEX
var WLAN_WEP_ASCII                           =          1; // ASCII

// WLAN加密与认证协议，例如WPA(2)-PSK,WPA(2),WEP等
var WLAN_PRIVACY_MODE_MIN                    =          0; // 边界检测
var WLAN_PRIVACY_MODE_WEP                    =          1; // WEP
var WLAN_PRIVACY_MODE_WPA_WPA2               =          2; // WPA  wpa/wpa2-enterprise
var WLAN_PRIVACY_MODE_PSK_PSK2               =          3; // PSK认证，属于WPA的一种，另外一种是RADIUS wpa/wpa2-personal
var WLAN_PRIVACY_MODE_WPA3                   =          4; //WPA3 for RADIUS wpa3-enterprise
var WLAN_PRIVACY_MODE_PSK2_PSK3              =          5;         //PSK2 PSK3 mixd认证  wpa2/wpa3-personal
var WLAN_PRIVACY_MODE_MAX                    =          6; // 边界检测

// WEP认证类型，目前支持开放系统和共享密钥
var WLAN_SECURITY_OPTION_WEP_MIN             =          0; // 按需拨号
var WLAN_SECURITY_OPTION_WEP_OPEN            =          1; // OPEN方式认证
var WLAN_SECURITY_OPTION_WEP_SHARE           =          2; // SHARE方式认证
var WLAN_SECURITY_OPTION_WEP_AUTO            =          3; // AUTO方式认证
var WLAN_SECURITY_OPTION_WEP_MAX             =          4; // 边界检测

// Radius认证类型，目前支持WPA，WPA2，自动
var WLAN_SECURITY_OPTION_MIN                 =          0; // 按需拨号
var WLAN_SECURITY_OPTION_WPA                 =          1; // OPEN方式认证
var WLAN_SECURITY_OPTION_WPA2                =          2; // SHARE方式认证
var WLAN_SECURITY_OPTION_AUTO                =          3; // AUTO方式认证
var WLAN_SECURITY_OPTION_WPA3                =          4; // WPA3 SHARE方式认证
var WLAN_SECURITY_OPTION_MAX                 =          5; // 边界检测

// PSK加密类型，范围1-3，默认为3，AES加密
var WLAN_ENCRYPT_TYPE_MIN                    =          0; // 边界检测
var WLAN_ENCRYPT_TYPE_AUTO                   =          1; // 自动选择
var WLAN_ENCRYPT_TYPE_TKIP                   =          2; // TKIP加密
var WLAN_ENCRYPT_TYPE_AES                    =          3; // AES加密
var WLAN_ENCRYPT_TYPE_MAX                    =          4; // 边界检测

var WLAN_SECURITY_OPTION_OPEN                =          1;
var WLAN_SECURITY_OPTION_PSK                 =          1;
var WLAN_SECURITY_OPTION_SHARE               =          2;
var WLAN_SECURITY_OPTION_PSK2                =          2;


// IPTV工作模式，取值为Disabled、Bridge和802.1Q VLAN
var IPTV_MODE_DISABLED                       =          0; // 禁用IPTV
var IPTV_MODE_BRIDGE                         =          1; // 桥接模式
var IPTV_MODE_8021Q                          =          2; // 802.1Q VLAN模式
var IPTV_MODE_RU                             =          3; // 俄罗斯地区模式
var IPTV_MODE_SG_SINGTEL                     =          4; // 新加坡电信模式
var IPTV_MODE_MY_UNIFI                       =          5; // 马来西亚UNIFI模式
var IPTV_MODE_MY_MAXIS1                      =          6; // 马来西亚MAXIS模式1
var IPTV_MODE_MY_MAXIS2                      =          7; // 马来西亚MAXIS模式2
var IPTV_MODE_VN_VIETTEL                     =          8; // 越南VIERREL模式
var IPTV_MODE_PT_MEO                         =          9; // 葡萄牙MEO模式
var IPTV_MODE_PT_VODAFONE                    =         10; // 葡萄牙沃达丰模式
var IPTV_MODE_AU_NBN                         =         11; // 澳大利亚NBN模式
var IPTV_MODE_NZ_UFB                         =         12; // 新西兰UFB模式
var IPTV_MODE_CUSTOM                         =         13; // 手动设置
var IPTV_MODE_MY_CELCOM                      =         14; // 马来西亚CELCOM模式
var IPTV_MODE_TH_AIS                         =         15; // 泰国AIS模式
var IPTV_MODE_DE_DT_DEFAULT                  =         16; // 德国电信默认模式
var IPTV_MODE_DE_DT_VLAN8                    =         17; // 德国电信IPTV选择VLAN8模式
var IPTV_MODE_US_CENTURYLINK                 =         18; // 美国CenturyLink模式
var IPTV_MODE_END                            =         19; // 边界检测

// 类型，取值为Internet、IPTV、VOIP和Multicast Tag，类型设置为整型，以使地址按4倍数偏移
var IPTV_SERVICE_INTERNET                    =          0; // internet服务
var IPTV_SERVICE_IPTV                        =          1; // iptv服务
var IPTV_SERVICE_VOIP                        =          2; // voip服务
var IPTV_SERVICE_MULTICAST                   =          3; // multicast服务
var IPTV_SERVICE_BRIDGE                      =          4; // bridge服务

// 连接方式（自动 手动 按需）
var PPTP_DEMAND                              =          0; // 按需拨号
var PPTP_AUTO                                =          1; // 自动拨号
var PPTP_TIMEING                             =          2; // 定时连接
var PPTP_MANUAL                              =          3; // 手动拨号
var PPTP_LINK_TYPE_MAX                       =          4; // 边界检测

// 连接方式（自动 手动 按需）
var L2TP_DEMAND                              =          0; // 按需拨号
var L2TP_AUTO                                =          1; // 自动拨号
var L2TP_TIMING                              =          2; // 定时连接
var L2TP_MANUAL                              =          3; // 手动拨号
var L2TP_LINK_TYPE_NUM                       =          4; // 边界检测

// 最近一次update后的状态
var DDNS_STATE_NOT_LAUNCH                    =          0; // 尚未加载
var DDNS_STATE_START                         =          1; // 开始
var DDNS_STATE_SEND_DNS_QUERY                =          2; // 发送DNS查询
var DDNS_STATE_READ_DNS_RESPONSE             =          3; // 读取DNS回包
var DDNS_STATE_TCP_CONNECTION                =          4; // TCP连接
var DDNS_STATE_SEND_HTTP_REQUEST             =          5; // 发送http查询
var DDNS_STATE_READ_HTTP_REPLY               =          6; // 读取http返回值
var DDNS_STATE_SUCCESS_GOOD                  =          7; // 成功
var DDNS_STATE_SUCCESS_NOCHG                 =          8; // 成功
var DDNS_STATE_FAIL_NOHOST                   =          9; // 无该host
var DDNS_STATE_FAIL_BADAUTH                  =         10; // 错误认证
var DDNS_STATE_FAIL_BADAGENT                 =         11; // 错误代理
var DDNS_STATE_FAIL_NOT_DONATOR              =         12; // ？？？
var DDNS_STATE_FAIL_ABUSE                    =         13; // 失败
var DDNS_STATE_FAIL_911                      =         14; // 911失败
var DDNS_STATE_FAIL_NOTFQDN                  =         15; // ？？？
var DDNS_STATE_FAIL_NUMHOST                  =         16; // ？？？
var DDNS_STATE_FAIL_DNSERR                   =         17; // DNS查询失败
var DDNS_STATE_FAIL_CONNECT_ERROR            =         18; // 连接失败
var DDNS_STATE_FAIL_UNKNOWN                  =         19; // 未知失败

// IPv6模式，0为Disable，1为Router，2为Passthrough。
var IPV6_MODE_DISABLE                        =          0; // 关闭IPv6
var IPV6_MODE_ROUTER                         =          1; // 路由模式
var IPV6_MODE_PASSTHROUGH                    =          2; // 桥接模式

// 重复模式：每天：0，每周：1，每月：2
var REBOOT_SCHE_EVERYDAY                     =          0; // 每天生效
var REBOOT_SCHE_EVERYWEEK                    =          1; // 每周
var REBOOT_SCHE_EVERYMONTH                   =          2; // 每月

// 物理接口的上层抽象使用时的名称编号
var PHY_INDEX_LAN1                           =          0; // LAN1口
var PHY_INDEX_LAN2                           =          1; // LAN2口
var PHY_INDEX_LAN3                           =          2; // LAN3口
var PHY_INDEX_LAN4                           =          3; // LAN4口
var PHY_INDEX_WAN                            =          4; // WAN口
var PHY_INDEX_CPU                            =          5; // CPU口
var PHY_INDEX_INVALID                        =          6; // 无效口

// 物理接口工作模式（数量和单双工）
var LINK_MODE_AUTO                           =          0; // 自动协商
var LINK_MODE_10MF                           =          1; // 10M全双工
var LINK_MODE_10MH                           =          2; // 10M半双工
var LINK_MODE_100MF                          =          3; // 100M全双工
var LINK_MODE_100MH                          =          4; // 100M半双工
var LINK_MODE_1000MF                         =          5; // 1000M全双工
var LINK_MODE_1000MH                         =          6; // 1000M半双工
var LINK_MODE_END                            =          7; // 结束值，仅做边界检测

// 错误码的枚举值
var ENONE                                    =          0; // 没有错误 
var ENOMEMORY                                =          1; // 内存不足 
var EINVARG                                  =          2; // 参数错误 
var EINVFMT                                  =          3; // 格式错误 
var EINVEVT                                  =          4; // 不支持的事件 
var EINVCODE                                 =          5; //  
var EFORBID                                  =          6; // 禁止的操作。 
var EUNAUTH                                  =          7; // 认证失败。 
var EOVERFLOW                                =          8; //  
var EINVINSTRUCT                             =          9; // 不支持的指令 
var EMD5                                     =         10; // MD5校验失败 
var EDESENCODE                               =         11; // DES加密失败 
var EDESDECODE                               =         12; // DES解密失败 
var ECHIPID                                  =         13; // 不支持的芯片类型； 
var EFLASHID                                 =         14; // 不支持的FLASH类型； 
var EPRODID                                  =         15; // 不支持的产品型号； 
var ELANGID                                  =         16; // 不支持的语言； 
var ESUBVER                                  =         17; // 不支持子版本号； 
var EOEMID                                   =         18; // 不支持的OEM类型； 
var ECOUNTRYID                               =         19; // 不支持的国家； 
var ECODE                                    =         20; // 不支持的操作类型； 
var EWANTYPE                                 =         21; // 不支持的WAN口接入类型； 
var ETOOLONG                                 =         22; // 数据过长。 
var ESYSTEM                                  =         23; // 系统错误。 
var ENOECHO                                  =         24; // 超时无响应。 
var ENODEVICE                                =         25; // 找不到设备。 
var EINVIP                                   =         26; // IP地址不正确。 
var EINVMASK                                 =         27; // 掩码不正确。 
var EINVGTW                                  =         28; // 网关不正确。 
var EINVIPMASKPAIR                           =         29; // IP和掩码不匹配。 
var EGTWUNREACH                              =         30; // 网关不可达。 
var EINVMTU                                  =         31; // MTU错误 
var EINVMACFMT                               =         32; // MAC地址格式不正确。 
var EENTRYEXIST                              =         33; // 条目已存在。 
var EENTRYNOTEXIST                           =         34; // 条目不存在。 
var EENTRYCONFLIC                            =         35; // 条目冲突。 
var ETABLEFULL                               =         36; // 表满。 
var ETABLEEMPTY                              =         37; // 表空 
var EINVPORT                                 =         38; // 超出端口范围
var EPORTRESERVED                            =         39; // 端口冲突
var EINVPTC                                  =         40; // 不支持的协议类型。 
var ECOMFLICTNET                             =         41; // 网段冲突
var EINVNET                                  =         42; // 非法的网段 
var EINVTYPE                                 =         43; // 非法的类型。 
var EINVMODE                                 =         44; // 非法的模式。 
var EINVTIME                                 =         45; // 
var EINVFDNSVR                               =         46; // 非法的首选DNS 
var EINVSDNSVR                               =         47; // 非法的备选DNS 
var EINVDATA                                 =         48; // 数据合法性验证失败 
var EINVLEASETIME                            =         49; // 非法的地址租期。 
var EINVADDRPOOL                             =         50; // 非法的地址池。 
var EINVDATE                                 =         51; // 非法的日期 
var EINVTIMEZONE                             =         52; // 非法的时区 
var ENOLINK                                  =         53; // WAN口未链接 
var ESYSBUSY                                 =         54; // 系统繁忙。 
var EINVNUM                                  =         55; // 
var EINVSIZE                                 =         56; // 
var EINVTIMEOUT                              =         57; // 
var EINVMETRIC                               =         58; // 
var EINVINTERVAL                             =         59; // 时间间隔输入错误 
var EINVBOOL                                 =         69; // 布尔类型的取值只能是0或者1 
var EINVSSIDLEN                              =         70; // 无线SSID长度不合法 
var EINVSECAUTH                              =         71; // 无线安全设置的认证类型错误 
var EINVWEPAUTH                              =         72; // WEP认证类型错误 
var EINVRADIUSAUTH                           =         73; // RADIUS认证类型错误 
var EINVPSKAUTH                              =         74; // PSK认证类型错误 
var EINVCIPHER                               =         75; // 加密算法错误 
var EINVRADIUSLEN                            =         76; // radius密钥短语长度错误 
var EINVPSKLEN                               =         77; // psk密钥短语错误 
var EINVGKUPINTVAL                           =         78; // 组密钥更新周期错误 
var EINVWEPKEYTYPE                           =         79; // WEP密钥类型错误 
var EINVWEPKEYIDX                            =         80; // 默认WEP密钥索引错误, 80 
var EINVWEPKEYLEN                            =         81; // WEP密钥长度错误 
var EINVACLDESCLEN                           =         82; // MAC地址过滤条目描述信息长度错误 
var EINVWPSPINLEN                            =         83; // WPS PIN码长度错误 
var EINVAPMODE                               =         84; // 无线设备工作模式错误 
var EINVWLSMODE                              =         85; // 无线速率模式(bgn)错误 
var EINVREGIONIDX                            =         86; // 无线国家码错误 
var EINVCHANWIDTH                            =         87; // 频段带宽错误 
var EINVRTSTHRSHLD                           =         88; // 无线RTS阈值错误 
var EINVFRAGTHRSHLD                          =         89; // 无线分片阈值错误 
var EINVBCNINTVL                             =         90; // 无线beacon间隔错误, 90 
var EINVTXPWR                                =         91; // 无线Tx功率错误 
var EINVDTIMINTVL                            =         92; // 无线DTIM周期错误 
var EINVWDSAUTH                              =         93; // 无线WDS认证类型错误 
var EINVA34DETECT                            =         94; // 3/4地址格式配置错误 
var EINVWLANPWD                              =         95; // 无线密钥包含非法字符 
var EINVHOSTNAMELEN                          =         96; // 非法的主机名长度 
var EINVGETIMEOUT                            =         97; // 非法的访客网络超时时间 
var EINVGETIMEMODE                           =         98; // 非法的访客网络定时模式 
var EINVMACGROUP                             =         99; // MAC地址为组播地址 
var ENAMEBLANK                               =        100; // 用户名输入为空 
var EPWDBLANK                                =        101; // 密码输入为空 
var EINVMACZERO                              =        102; // MAC地址为全0 
var EINVMACBROAD                             =        103; // 广播MAC地址 
var EHOSTNAMEEMP                             =        104; // 受控主机名为空 
var EOBJNAMEEMP                              =        105; // 访问目标名为空 
var EPLANNAMEEMP                             =        106; // 日程计划名为空 
var EOBJDOMAINALLEMP                         =        107; // 访问目标域名全为空 
var EREFERED                                 =        108; // 条目被关联了 
var EDELPARTIAL                              =        109; // 只删除了部分条目 
var EDELNOTHING                              =        110; // 一个条目都没有删除 
var ERSACHECK                                =        111; // RSA校验错误 
var EINVLGPWDLEN                             =        112; // 登录密码长度不合法 
var EINLGVALCHAR                             =        113; // 登录密码含有非法字符 
var EINLGVALOLDSAME                          =        114; // 新登录密码和旧登录密码一样 
var EINVNETID                                =        115; // 网络号全0或者1 
var EINVHOSTID                               =        116; // 超出范围 
var EOUTOFRANGE                              =        117; // RSA校验错误 
var EINDOMAIN                                =        118; // 非法的域名 
var ELACKCFGINFO                             =        119; // 缺少必要的配置信息 
var EINVKEY                                  =        120; // 旧的登录密码错误
var EINVRMTPORT                              =        121; // 远程管理端口超出范围
var EILLEGALPORT                             =        122; // 端口值非法 
var EINVNAMELEN                              =        123; // 用户名长度超出范围 
var EINVPWDLEN                               =        124; // 密码长度超出范围 
var EINVNAME                                 =        125; // 用户名非法 
var ENOTLANSUBNET                            =        126; // 不是LAN网段IP 
var EHOSTALLEMPTY                            =        127; // 受控主机IP全为空 
var EOBJALLEMPTY                             =        128; // 访问目标IP和端口全为空 
var EINVGROUPIP                              =        129; // 组播的IP地址 
var EINVLOOPIP                               =        130; // 回环的IP地址 
var EINVIPFMT                                =        131; // IP地址格式错误 
var ENOTLANWANNET                            =        132; // 网段不是LAN或WAN 
var ELANSUBNET                               =        133; // LAN网段IP 
var EINVPWD                                  =        134; // 密码非法 
var EIPRESERVED                              =        135; // IP地址被占用 
var EINVPORTFMT                              =        136; // 端口格式错误 
var EADDRPOOLNOTLANSUBNET                    =        137; // 地址池不在LAN网段 
var ERULECONFLICT                            =        138; // 受控规则冲突 
var EINVTIMETYPE                             =        139; // 非法的时间设置方式 
var EINDATE                                  =        140; // 非法日期 
var EIPMACCONFLIC                            =        141; // 添加的条目与IP&MAC绑定冲突 
var EDHCPRESERVECONFLIC                      =        142; // 添加的条目与DHCP RESERVE冲突 
var EIPDNSCONFLICT                           =        143; // lan ip与wan dns server冲突 
// DDNS数据节点常量
var CLOUD_DDNS_DEFUALT = 0;
var CLOUD_DDNS_QUERY_ING = 1;
var CLOUD_DDNS_QUERY_SUCC = 2;
var CLOUD_DDNS_REG_ING = 3;
var CLOUD_DDNS_REG_SUCC = 4;
var CLOUD_DDNS_BIND_ING = 5;
var CLOUD_DDNS_BIND_SUCC = 6;
var CLOUD_DDNS_UNBIND_ING = 7;
var CLOUD_DDNS_UNBIND_SUCC = 8;
var CLOUD_DDNS_DEL_ING = 9;
var CLOUD_DDNS_DEL_SUCC = 10;
var CLOUD_DDNS_PARAM_FAILED = 20000; /* invalid param; such as domain names is not valid */
var CLOUD_DDNS_REGISTERED_FAILED = 20001; /* domain name has been registered. */
var CLOUD_DDNS_TIMEOUT = 20002; /* a single device binds too many domain names. */
var CLOUD_DDNS_BIND_TOO_MANY_FAILED = 20003; /* a single device binds too many domain names. */
var CLOUD_DDNS_BOUND_FAILED = 20004; /* the domain has been bound to another device. */
var CLOUD_DDNS_SYS_FAILED = 20005; /* system error; such as db operation failed. */
var CLOUD_DDNS_FORBIDDED_FAILED = 20006; /* domain names contain fobidden words. */
var CLOUD_DDNS_NOT_EXIST_FAILED = 20007; /* domain names is not existed. */
var CLOUD_DDNS_REG_TOO_MANY_FAILED = 20008; /* a single device registers too many domain names. */

// wds连接状态枚举
var STA_STATE_DOWN                           =          0; // 未连接状态 
var STA_STATE_IDLE                           =          1; // 这个状态好像没有用到20190904 
var STA_STATE_SCAN                           =          2; // 扫描状态 
var STA_STATE_AUTH                           =          3; // 认证连接中 
var STA_STATE_ASSOC                          =          4; // 关联中 
var STA_STATE_RUN                            =          5; // 连接完成，aplic接口正在运行 

// 时间显示的格式类型
var YEAR_FIRST_TYPE                          =          0; // 默认值，以YY/MM/DD来显示时间
var DAY_FIRST_TYPE                           =          1; // 以DD/MM/YY来显示时间
// cwmp本地http服务器监听的设备
var CWMP_BIND_IFACE_WAN                      =          0; // 本地http服务器绑定wan口IP
var CWMP_BIND_IFACE_LAN                      =          1; // 本地http服务器绑定lan侧网关IP
var CWMP_BIND_IFACE_END                      =          2; // 最大限制

// cwmp本地http服务器的认证方式
var CWMP_LOCAL_NO_AUTH                       =          0; // 无认证
var CWMP_LOCAL_BASIC_AUTH                    =          1; // basic认证
var CWMP_LOCAL_DIGEST_AUTH                   =          2; // digest认证

// 用户指定的数据模型规范，如TR098,TR181
var CWMP_DATA_MODEL_START                    =          0; // 起始边界检查
var CWMP_DATA_MODEL_TR098                    =          1; // TR098数据模型:TR-069 InternetGatewayDevice:1.x Root Object definition
var CWMP_DATA_MODEL_TR181                    =          2; // TR181数据模型:TR-069 Device:2.x Root Object definition
var CWMP_DATA_MODEL_END                      =          3; // 结束边界检查

var DEVICE_DATA_ID                           =    0; // 
var SYSTEM_DATA_ID                           =    1; // 
var SYSTEM_LOG_DATA_ID                       =    2; // 
var EXCEPT_LOG_DATA_ID                       =    3; // 
var LAN_DATA_ID                              =    4; // 
var LCLPORT_DATA_ID                          =    5; // 
var LCLHOST_DATA_ID                          =    6; // 
var RMTHOST_DATA_ID                          =    7; // 
var DHCPS_DATA_ID                            =    8; // 
var DHCPS_LEASE_DATA_ID                      =    9; // 
var TPDOMAIN_DATA_ID                         =   10; // 
var FACTORY_DATA_ID                          =   11; // 
var STACTRLTBL_DATA_ID                       =   12; // 
var STARTTABLE_DATA_ID                       =   13; // 
var STATIC_ROUTE_DATA_ID                     =   14; // 
var DYNAMIC_ROUTE_DATA_ID                    =   15; // 
var SYSTEM_ROUTE_DATA_ID                     =   16; // 
var NAPT_ALG_DATA_ID                         =   17; // 
var NAPT_DMZ_DATA_ID                         =   18; // 
var NAPT_IGD_DATA_ID                         =   19; // 
var NAPT_IGD_MAPPING_DATA_ID                 =   20; // 
var NAPT_VSERVER_DATA_ID                     =   21; // 
var LINK_DATA_ID                             =   22; // WAN拨号设置
var LINK_STATUS_DATA_ID                      =   23; // router/wisp模式使用，ap/re模式smart ip时，也使用前面部分
var STATIC_IP_DATA_ID                        =   24; // 静态IP拨号设置
var DHCPC_DATA_ID                            =   25; // 动态IP拨号设置
var PPPOE_DATA_ID                            =   26; // PPPOE拨号设置
var PPPOE_LASTDIAL_DATA_ID                   =   27; // 
var SNTPC_CONFIG_DATA_ID                     =   28; // 
var SNTPC_TIME_DATA_ID                       =   29; // 由runtime模式改为immediately模式，用于存储时间
var PARENT_CTL_DATA_ID                       =   30; // 家长控制模块，水星机型版本
var BEHAVMANG_CONFIG_DATA_ID                 =   31; // 行为管理模块，水星版本，AccessControl
var WLAN_BASIC_DATA_ID                       =   32; // 无线基础配置，如信道、带宽等
var MBSSID_MAIN_DATA_ID                      =   33; // 无线VAP设置，如主网络、访客网络
var WLAN_AP_LIST_DATA_ID                     =   34; // 扫描得到的AP列表
var IPTV_DATA_ID                             =   35; // IPTV配置
var PPTP_DATA_ID                             =   36; // PPTP拨号配置
var L2TP_DATA_ID                             =   37; // L2TP拨号配置
var DDNS_DATA_ID                             =   38; // 
var DDNS_STATUS_DATA_ID                      =   39; // 
var IPV6_MODE_DATA_ID                        =   40; // 
var IPV6_WAN_INTERFACE_DATA_ID               =   41; // 
var IPV6_WAN_ADDR_DATA_ID                    =   42; // 
var IPV6_WAN_DNS_DATA_ID                     =   43; // 
var IPV6_PPPOE_DATA_ID                       =   44; // 
var IPV6_WAN_STATUS_DATA_ID                  =   45; // 
var IPV6_PREFIX_DELEGATION_DATA_ID           =   46; // 
var IPV6_LAN_PREFIX_DATA_ID                  =   47; // 
var IPV6_LAN_STATUS_DATA_ID                  =   48; // 
var MANUFACTURE_MODE_DATA_ID                 =   49; // 
var LANGUAGE_DATA_ID                         =   50; // 
var REBOOT_SCHE_DATA_ID                      =   51; // 定时重启模块配置
var LED_SCHE_DATA_ID                         =   52; // LED定时配置
var WLAN_SCHEDULE_DATA_ID                    =   53; // host wireless schedule
var SMART_CONNECT_DATA_ID                    =   54; // 无线双频合一功能，配置默认来源于2.4G，操作的配置由2.4G存储
var PARENT_CTL_V2_DATA_ID                    =   55; // 家长控制模块，用于SPF页面，水星页面不用
var QOS_DATA_ID                              =   56; // QOS模块，用于SPF页面
var HW_NAT_DATA_ID                           =   57; // 硬件NAT开关
var ACCESS_CONTROL_SWITCH_DATA_ID            =   58; // spfUI Access Control switch data model
var PORT_TRIGGER_DATA_ID                     =   59; // port trigger数据节点
var ETHERNET_INFO_DATA_ID                    =   60; // 每个物理接口的状态信息
var MCB_POOL_DESC_DATA_ID                    =   61; // mcb内存池描述
var PING_RESPONSE_DATA_ID                    =   62; // response ping from LAN/WAN
var SPI_FIREWALL_DATA_ID                     =   63; // spi firewall开关，默认开启
var LED_CTR_DATA_ID                          =   64; // LED控制
var CLOUD_BASIC_DATA_ID                      =   65; // 云基础结构
var CLOUD_FW_UPGRADE_DATA_ID                 =   66; // 云升级结构
var CLOUD_OWNER_DATA_ID                      =   67; // 云账户-OWNER
var CLOUD_CURRENT_USER_CFG_DATA_ID           =   68; // 云账户-CurrUser
var CLOUD_DDNS_DATA_ID                       =   69; // TP-LINK DDNS
var CLOUD_CURRENT_USER_DATA_ID               =   70; // 用来保存当前用户名，密码
var CLOUD_SVR_CONFIG_DATA_ID                 =   71; // 保存cloud_brd的配置
var ACCESS_CONTROL_WHITE_LIST_DATA_ID        =   72; // spfUI access control white list data model
var ACCESS_CONTROL_BlACK_LIST_DATA_ID        =   73; // spfUI access control black list data model
var COMMONERR_DATA_ID                        =   74; // 设备端错误码
var WDS_STATUS_DATA_ID                       =   75; // wds连接状态
var WEB_COMMAND_DATA_ID                      =   76; // web及时命令，我们notify中响应
var MODE_COMMON_DATA_ID                      =   77; // 各个模式之间一些公共的数据，不写入flash，不属于用户配置
var WEB_SWITCH_DATA_ID                       =   85; // 用来控制web页面上部分开关的显示，后续有关web页面上开关显示的数据都可以放在这
var ISPPRESET_DATA_ID                        =   86; // 保存ISP配置
var ISP_RUNTIMEDATA_DATA_ID                  =   87; // 保存ISP运行时数据
var YANG_DEX_DNS_DATA_ID                     =   88; // 仅存在于俄语ru下
var MULTI_COUNTRY_CODE_DATA_ID               =   89; // 多国家码功能结构
var IGMP_SNOOPING_DATA_ID                    =   90; // 
var CWMP_CONFIG_DATA_ID                      =   91; // cwmp的基础配置，web和acs都可以读写
var CLOUD_LOGIN_CHECK_ID                     =   97;

var WEB_SWITCH_ON                            =   1; //WEB显示开启
var WEB_SWITCH_OFF                           =   0; //WEB显示关闭
function DataBlock ()
{
    this.DEVICE_1_0_0 =
    {
        id: DEVICE_DATA_ID,             //
        layers: [1, 0, 0],              //layer描述
        fullName: "",                   //设备描述，TP-LINK Wireless N Router，描述设备的规格，一般不带型号
        facturer: "",                   //设备制造商，TP-LINK
        modelName: "",                  //设备型号，TL-WR842N，不要带上版本号！
        modelVer: "",                   //型号版本，4.0，x.x的形式
        softVer: "",                    //软件发布版本，2.0.0 Build 140321 Rel.55769n，自动生成，无需指定
        hardVer: "",                    //硬件版本，TL-WR842N 4.0
        prodId: "",                     //产品ID，内部使用，软件升级、配置载入时检查
        specialId: "",                  //special id, 如US为45 53 00 00, 用于无线认证和机型后缀
        countryCode: "",                //国家编码，如US为45 53，用于软件功能和共版软件
        mainVer: "",                    //主版本号，高、中、低三位，如2.0.0
        minorVer: "",                   //子版本号，只能从低版本号往高版本号更新
        oemId: "",                      //OEM厂商ID，0为TP-LINK，1为水星，2为迅捷，在升级软件签名计算时选择不同的公钥
        deviceId: "",                   //设备身份标识，用于云
        hardwareId: "",                 //硬件身份标识，用于云
        firmwareId: "",                 //固件身份标识，目前是固件的MD5，保存在FLASH中，也用于双uboot检测固件完整性
        oem_id: "",                     //软件类别标识，用于云，和oemId不同
        facturerType: ""                //设备制造商类型，默认0，表示TP系列
                                        //取值范围:
                                        //TPLINK_FACTURER                         TP机型
                                        //MERCUSYS_FACTURER                       水星机型

    };

    this.SYSTEM_1_0_0 =
    {
        id: SYSTEM_DATA_ID,             //
        layers: [1, 0, 0],              //layer描述
        authKey: "",                    //登录密码，支持字母、数字
        reserved: "",                   //只为对齐
        setWzd: "",                     //是否设置过向导，否则登录时显示设置向导
        mode: "",                       //系统模式，路由模式、Repeater模式等
                                        //取值范围:
                                        //SYSTEM_MODE_BEGIN                       起始值，仅做边界检测
                                        //SYSTEM_MODE_ROUTER                      Router工作模式
                                        //SYSTEM_MODE_AP                          AP工作模式
                                        //SYSTEM_MODE_RE                          Repeater工作模式
                                        //SYSTEM_MODE_WISP                        WISP工作模式
                                        //SYSTEM_MODE_END                         结束值，仅做边界检测
        logLevel: "",                   //Log等级，分为DEBUG、INFO、WARN、ERROR、EXCEPT
        fastpath: "",                   //是否开启快速转发，默认应开启
        mac: [],                        //系统MAC地址，默认LAN MAC为：001966ca8b07
        wanMacType: ""                  //WAN MAC的设置方式:default、pc、user set
                                        //取值范围:
                                        //DEFAULT_MAC                             默认mac地址
                                        //PC_MAC                                  使用PC的MAC地址
                                        //USER_SET_MAC                            使用用户设置的MAC地址

    };

    this.SYSTEM_LOG_1_0_0 =
    {
        id: SYSTEM_LOG_DATA_ID,         //
        layers: [1, 0, 0],              //layer描述
        num: "",                        //当前记录的系统日志数量
        list:                           //
        [{                              //长度为400
            level: "",                  //当前log信息的等级
                                        //取值范围:
                                        //LEVEL_EXCEPT                            exception异常
                                        //LEVEL_ERROR                             错误
                                        //LEVEL_WARNING                           警告
                                        //LEVEL_INFO                              提示
                                        //LEVEL_DEBUG                             仅Debug
            days: "",                   //log产生日期
            hours: "",                  //log产生时间(小时)
            mins: "",                   //log产生时间(分)
            secs: "",                   //log产生时间(秒)
            msecs: "",                  //log产生时间(毫秒)
            msg: ""                     //log信息
        }]

    };

    this.EXCEPT_LOG_1_0_0 =
    {
        id: EXCEPT_LOG_DATA_ID,         //
        layers: [1, 0, 0],              //layer描述
        num: "",                        //当前记录的异常log的数量
        list:                           //
        [{                              //长度为8
            msg: ""                     //异常log信息，最多可记录10条
        }]

    };

    this.LAN_1_0_0 =
    {
        id: LAN_DATA_ID,                //
        layers: [1, 0, 0],              //layer描述
        ip: "",                         //LAN口IP，水星品牌IP为192.168.1.1, tp品牌ip为192.168.0.1
        mask: "",                       //LAN掩码
        mode: "",                       //router/wisp模式，用于处理lan wan冲突下是否允许自动修改IP，手动模式时不会自动改IP；不要和SMARTIP混淆
                                        //取值范围:
                                        //LAN_MODE_AUTO                           允许系统在LAN WAN冲突时自动修改IP
                                        //LAN_MODE_MANUAL                         不允许自动修改IP
        smartIp: "",                    //ap/re模式，自动模式(值为0)下无法手动更改IP，自动获取ip
                                        //取值范围:
                                        //LAN_MODE_SMARTIP_AUTO                   SMART IP模式，自动获取IP
                                        //LAN_MODE_SMARTIP_MANUAL                 手动设置IP模式
        gateway: ""                     //ap/re模式的网关，在检测Internet status和请求ntp等功能时使用

    };

    this.LCLPORT_1_0_0 =
    {
        id: LCLPORT_DATA_ID,            //
        layers: [1, 0, 0],              //layer描述
        port: "",                       //局域网WEB管理端口
        reserved: ""                    //仅做对齐，保证整体按4对齐

    };

    this.LCLHOST_1_0_0 =
    {
        id: LCLHOST_DATA_ID,            //
        layers: [1, 0, 0],              //layer描述
        enableAll: "",                  //启用/禁用局域网主机筛选功能
        mac: [],                        //允许访问的局域网主机(MAC标识)
        list:                           //
        [{                              //长度为32
            desc: ""                    //管理设备的描述（可以是设备名称）
        }]

    };

    this.RMTHOST_1_0_0 =
    {
        id: RMTHOST_DATA_ID,            //
        layers: [1, 0, 0],              //layer描述
        port: "",                       //远程WEB管理端口，取值1024~65535之间
        rule: "",                       //远程主机访问控制规则，0：禁用所有，1：允许所有，2：允许指定主机
                                        //取值范围:
                                        //HTTP_REMOTE_DISABLE_ALL                 禁止远程访问
                                        //HTTP_REMOTE_ENABLE_ALL                  允许所有远程访问
                                        //HTTP_REMOTE_ENABLE_SPECIFY              允许个别访问
        addr: ""                        //允许访问的远程主机的IP地址，必须是合法的IP

    };

    this.DHCPS_1_0_0 =
    {
        id: DHCPS_DATA_ID,              //
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //启用/禁用DHCP服务器
        poolStart: "",                  //地址池起始地址
        poolEnd: "",                    //地址池结束地址
        leaseTime: "",                  //租期，默认2小时
        dns: [],                        //分配的DNS服务器地址，DHCPS分配DNS规则：用户配置>WAN口DNS地址>默认(LAN口IP)
        gateway: "",                    //分配的网关，用户配置>默认(LAN口IP)
        hostName: ""                    //主机名

    };

    this.DHCPS_LEASE_1_0_0 =
    {
        id: DHCPS_LEASE_DATA_ID,        //
        layers: [1, 0, 0],              //layer描述
        list:                           //
        [{                              //长度为253
            hostName: "",               //客户端主机名
            mac: "",                    //客户端MAC地址
            reserved: "",               //保留
            state: "",                  //客户端状态，是否已成功分配
            ip: "",                     //客户端获得的IP
            expires: ""                 //客户端剩余租期
        }]

    };

    this.TPDOMAIN_1_0_0 =
    {
        id: TPDOMAIN_DATA_ID,           //
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //开启/关闭域名登录功能，默认开启
        name: ""                        //域名

    };

    this.FACTORY_1_0_0 =
    {
        id: FACTORY_DATA_ID,            //
        layers: [1, 0, 0],              //layer描述
        lanIp: "",                      //出厂的LAN IP，恢复出厂设置时可用此IP跳转
        lanMask: "",                    //出厂的LAN口掩码
        authKey: "",                    //出厂的认证密钥，用于判断用户有无修改默认密码
        reserved: ""                    //只为对齐

    };

    this.STACTRLTBL_1_0_0 =
    {
        id: STACTRLTBL_DATA_ID,         //
        layers: [1, 0, 0],              //layer描述
        list:                           //
        [{                              //长度为64
            ip: "",                     //主机IP，只有为IP-MAC绑定条目时才生效
            mac: "",                    //主机MAC地址
            reserved: "",               //保留
            bindEntry: "",              //主机为IP-MAC绑定条目（静态ARP）
            staMgtEntry: "",            //主机为站点统计条目
            name: "",                   //主机名
            reserved_name: "",          //补齐name
            blocked: "",                //主机被禁止访问
            upLimit: "",                //限制上传速度（字节）
            downLimit: "",              //限制下载速度（字节）
            qosEntry: "",               //主机为QOS优先条目
            priTime: "",                //高优先级时长，单位为秒，0代表为一直保持高优先级(always)
            dhcpsEntry: "",             //主机为DHCPS Reservation绑定条目
            dhcpsEnable: ""             //DHCPS Reservation绑定条目生效
        }],
        disable: ""                     //for spfUI新增成员，启用/禁用IP&MAC Binding功能,默认值为0，开启功能

    };

    this.STARTTABLE_1_0_0 =
    {
        id: STARTTABLE_DATA_ID,         //
        layers: [1, 0, 0],              //layer描述
        list:                           //
        [{                              //长度为96
            ip: "",                     //主机IP
            mac: "",                    //主机MAC地址
            reserved: "",               //保留
            bindEntry: "",              //主机为IP-MAC绑定条目（静态ARP+DHCPS固定IP）
            staMgtEntry: "",            //主机为站点统计条目
            type: "",                   //主机所在网络类型（有线/无线/访客）
                                        //取值范围:
                                        //STATION_WIRE                            有线
                                        //STATION_WIRELESS_2G                     2G主网络
                                        //STATION_GUESTNETWORK_2G                 2G访客网络
                                        //STATION_WIRELESS_5G                     5G主网络
                                        //STATION_GUESTNETWORK_5G                 5G访客网络
            online: "",                 //主机在线/离线
            blocked: "",                //主机被禁止访问
            up: "",                     //上传速度（字节）
            down: "",                   //下载速度（字节）
            upLimit: "",                //限制上传速度（字节）
            downLimit: "",              //限制下载速度（字节）
            name: "",                   //主机名
            reserved_name: "",          //补齐name
            qosPrior: "",               //主机被设置为高优先级
            priTime: "",                //高优先级时长，单位为秒，0代表为一直保持高优先级(always)
            leaseTime: "",              //剩余高优先级时长，单位为秒
            totalVal: "",               //总流量(上传加下载)
            totalUnit: "",              //总流量单位(0-Bytes；1-KB；2-MB；3-GB)
            dhcpsEntry: ""              //主机为DHCPS Reservation绑定条目
        }]

    };

    this.STATIC_ROUTE_1_0_0 =
    {
        id: STATIC_ROUTE_DATA_ID,       //
        layers: [1, 0, 0],              //layer描述
        list:                           //
        [{                              //长度为16
            enable: "",                 //静态路由条目是否生效
            net: "",                    //静态路由条目的目的网段
            mask: "",                   //静态路由条目目的网段的子网掩码
            gateway: "",                //静态路由条目的下一跳地址
            netif: "",                  //静态路由条目下一跳地址对应的发送接口
            desc: ""                    //静态路由条目描述
        }]

    };

    this.DYNAMIC_ROUTE_1_0_0 =
    {
        id: DYNAMIC_ROUTE_DATA_ID,      //
        layers: [1, 0, 0],              //layer描述
        list:                           //
        [{                              //长度为32
            net: "",                    //动态路由条目的目的网段
            mask: "",                   //动态路由条目的网段的子网掩码
            gateway: ""                 //动态路由条目的下一跳地址
        }]

    };

    this.SYSTEM_ROUTE_1_0_0 =
    {
        id: SYSTEM_ROUTE_DATA_ID,       //
        layers: [1, 0, 0],              //layer描述
        list:                           //
        [{                              //长度为64
            net: "",                    //系统路由条目的目的网段
            gateway: "",                //系统路由条目的下一跳地址
            mask: "",                   //系统路由条目目的网段的子网掩码
            netif: ""                   //系统路由条目下一跳地址对应的发送接口
        }]

    };

    this.NAPT_ALG_1_0_0 =
    {
        id: NAPT_ALG_DATA_ID,           //
        layers: [1, 0, 0],              //layer描述
        ftpAlgEnable: "",               //启用/禁用FTP ALG，默认开启
        pptpAlgEnable: "",              //启用/禁用PPTP ALG，默认开启
        rtspAlgEnable: "",              //启用/禁用RTSP ALG，默认开启
        sipAlgEnable: "",               //启用/禁用SIP ALG，默认开启
        ipsecAlgEnable: "",             //启用/禁用IPSEC ALG，默认开启
        h323AlgEnable: "",              //启用/禁用H323 ALG，默认开启
        natEnable: "",                  //启用/禁用NAT，默认开启
        tftpAlgEnable: "",              //启用/禁用L2TP ALG，默认开启
        l2tpAlgEnable: ""               //启用/禁用L2TP ALG，默认开启

    };

    this.NAPT_DMZ_1_0_0 =
    {
        id: NAPT_DMZ_DATA_ID,           //
        layers: [1, 0, 0],              //layer描述
        dmzEnable: "",                  //启用/禁用DMZ功能，默认禁用
        dmzClient: "",                   //DMZ主机IP地址
        state: "",
        macAddr: ""
    };

    this.NAPT_IGD_1_0_0 =
    {
        id: NAPT_IGD_DATA_ID,           //
        layers: [1, 0, 0],              //layer描述
        igdEnable: ""                   //启用/禁用IGD功能，默认开启

    };

    this.NAPT_IGD_MAPPING_1_0_0 =
    {
        id: NAPT_IGD_MAPPING_DATA_ID,   //
        layers: [1, 0, 0],              //layer描述
        num: "",                        //端口映射条目数
        list:                           //
        [{                              //长度为64
            extPort: "",                //端口映射条目WAN口端口
            intPort: "",                //端口映射条目内部端口
            ptc: "",                    //端口映射条目传输层协议类型
            enabled: "",                //端口映射条目是否处于有效激活状态
            leaseDuration: "",          //端口映射条目总有效存活时间
            leaseTimer: "",             //端口映射条目还能有效的时间
            rmtHost: "",                //端口映射条目外网主机IP地址
            client: "",                 //端口映射条目内网主机IP地址
            desc: ""                    //端口映射条目描述信息
        }]

    };

    this.NAPT_VSERVER_1_0_0 =
    {
        id: NAPT_VSERVER_DATA_ID,       //
        layers: [1, 0, 0],              //layer描述
        list:                           //
        [{                              //长度为16
            vsEntryEnable: "",          //虚拟服务器映射条目是否处于有效状态
            vsLclIp: "",                //虚拟服务器映射条目内部IP地址
            vsRmtIp: "",                //虚拟服务器映射条目外部IP地址
            vsLclPort: "",              //虚拟服务器映射条目内部主机端口
            vsRmtPort: "",              //虚拟服务器映射条目外部主机端口
            vsOpenPortS: "",            //虚拟服务器映射条目WAN口开始端口
            vsOpenPortE: "",            //虚拟服务器映射条目WAN口结束端口
            vsPtc: "",                  //虚拟服务器映射条目传输层协议类型
                                        //取值范围:
                                        //PROTOCOL_TYPE_ALL                       同时支持TCP和UDP
                                        //PROTOCOL_TYPE_TCP                       支持TCP
                                        //PROTOCOL_TYPE_UDP                       支持UDP
            vsServerName: ""            //虚拟服务器名
        }]

    };

    this.LINK_1_0_0 =
    {
        id: LINK_DATA_ID,               //WAN拨号设置
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //WAN口是否开启
        wirelessWanNoUsed: "",          //WAN口是否为无线接口，现在无用
        linkMode: "",                   //WAN口速率模式
        linkType: ""                    //WAN口接入类型
                                        //取值范围:
                                        //LINK_TYPE_DHCP                          DHCP
                                        //LINK_TYPE_STATIC_IP                     静态IP
                                        //LINK_TYPE_PPPOE                         PPPOE
                                        //LINK_TYPE_L2TP                          L2TP
                                        //LINK_TYPE_PPTP                          PPTP
                                        //LINK_TYPE_8021X                         802.1X
                                        //LINK_TYPE_BPA                           BigPon Cable
                                        //LINK_TYPE_END                           边界检测

    };

    this.LINK_STATUS_1_0_0 =
    {
        id: LINK_STATUS_DATA_ID,        //router/wisp模式使用，ap/re模式smart ip时，也使用前面部分
        layers: [1, 0, 0],              //layer描述
        ip: "",                         //WAN口IP
        mask: "",                       //WAN口子网掩码
        gateway: "",                    //WAN口网关
        dns: [],                        //WAN口DNS服务器
        status: "",                     //WAN连接状态
                                        //取值范围:
                                        //LINK_DOWN                               连接已断开
                                        //LINK_UP                                 已经连接上
                                        //LINKING_UP                              正在连接
                                        //LINKING_DOWN                            正在断开
        code: "",                       //WAN错误码，用于指示连接失败的原因
                                        //取值范围:
                                        //LINK_CODE_NORMAL                        WAN口正常
                                        //LINK_CODE_MANUAL                        手动断开连接
                                        //LINK_CODE_UNKNOWN                       未知错误
                                        //LINK_CODE_DENY                          服务器拒绝。
                                        //LINK_CODE_PHYDOWN                       WAN口物理链路断开，即WAN口未插线
                                        //LINK_CODE_NOECHO                        服务器无响应。
                                        //LINK_CODE_SRVDOWN                       服务器主动断开连接。与DENY的区别在于这个是连接成功后断开？
                                        //LINK_CODE_OPT_UNSUPPORT                 选项不支持导致拨号失败。
                                        //LINK_CODE_AUTH_ERR                      用户名密码错误导致认证失败。
                                        //LINK_CODE_AUTH_UNSUPPORT                认证方式不支持。
                                        //LINK_CODE_IP_CONFLICT                   WAN口获得的IP与LAN口IP冲突
                                        //LINK_CODE_NO_IPV4                       WAN口未获取到IPv4地址
                                        //LINK_CODE_RA_CHANGED                    RA发生变化
                                        //LINK_CODE_POOR_NETWOOK                  连接不到Internet
        upTime: "",                     //WAN连接时长（tick）
        inPkts: "",                     //WAN接收数据包个数
        inOctets: "",                   //WAN接收字节
        outPkts: "",                    //WAN发送数据包个数
        outOctets: "",                  //WAN发送字节
        inRates: "",                    //WAN接受速率
        outRates: "",                   //WAN发送速率
        dualMode: "",                   //
        dualIp: "",                     //
        dualMask: "",                   //
        dualGateway: "",                //
        dualDns: [],                    //
        dualCode: "",                   //
        dualStatus: "",                 //WAN发送速率
        internetDnsDetect: ""           //因特网连接检测

    };

    this.STATIC_IP_1_0_0 =
    {
        id: STATIC_IP_DATA_ID,          //静态IP拨号设置
        layers: [1, 0, 0],              //layer描述
        ip: "",                         //IP地址
        mask: "",                       //子网掩码
        gateway: "",                    //网关
        dns: [],                        //DNS服务器
        mtu: ""                         //数据包MTU（字节）

    };

    this.DHCPC_1_0_0 =
    {
        id: DHCPC_DATA_ID,              //动态IP拨号设置
        layers: [1, 0, 0],              //layer描述
        name: "",                       //主机名
        dns: [],                        //DNS服务器
        mtu: "",                        //数据包MTU（字节）
        ucast: "",                      //单播/广播方式获取IP
        manualDns: "",                  //手动设置DNS服务器（TRUE生效）
        lastIp: ""                      //最近一次获取到的IP

    };

    this.PPPOE_1_0_0 =
    {
        id: PPPOE_DATA_ID,              //PPPOE拨号设置
        layers: [1, 0, 0],              //layer描述
        svName: "",                     //服务名
        acName: "",                     //服务器名，用于连接到指定的服务器
        name: "",                       //宽带帐号
        paswd: "",                      //宽带密码
        fixipEnb: "",                   //使用运营商指定的IP地址（TRUE生效）
        fixip: "",                      //运营商指定的IP地址
        manualDns: "",                  //手动设置DNS服务器（TRUE生效）
        dns: [],                        //DNS服务器
        lcpMru: "",                     //数据包MTU（字节）
        linkType: "",                   //连接模式（按需/自动/手动）
                                        //取值范围:
                                        //PPPOE_DEMAND                            按需拨号
                                        //PPPOE_AUTO                              自动拨号
                                        //PPPOE_TIMEING                           定时连接
                                        //PPPOE_MANUAL                            手动拨号
                                        //PPPOE_LINK_TYPE_MAX                     边界值
        dialMode: "",                   //拨号模式（自动选择/正常/特殊拨号n）
                                        //取值范围:
                                        //PPPOE_MODE_NORMAL                       正常拨号模式
                                        //PPPOE_MODE_END                          这是什么？？？
                                        //PPPOE_MODE_AUTOSELECT                   自动选择拨号模式
        maxIdleTime: "",                //自动断线等待时间（分钟）
        sndConnType: "",                //第二连接类型，0为禁用第二连接，1为DHCP，2为静态IP
                                        //取值范围:
                                        //PPPOE_SNDCONN_NONE                      无第二连接
                                        //PPPOE_SNDCONN_DYNAMIC                   第二连接为自动获取
                                        //PPPOE_SNDCONN_STATIC                    第二连接为静态IP
        staticSndIp: "",                //第二连接为静态IP时的IP地址
        staticSndMask: "",              //第二连接为静态IP时的子网掩码
        start_hour: "",                 //设置开启pppoe的小时
        start_minute: "",               //设置开启pppoe的分钟
        end_hour: "",                   //设置关闭pppoe的小时
        end_minute: "",                 //设置关闭pppoe的分钟
        detectOnlineTime: ""            //检测在线的间隔时长（秒）

    };

    this.PPPOE_LASTDIAL_1_0_0 =
    {
        id: PPPOE_LASTDIAL_DATA_ID,     //
        layers: [1, 0, 0],              //layer描述
        acMac: "",                      //上次成功拨号的服务器MAC地址
        reserved: "",                   //预留
        sessionid: "",                  //上次成功拨号的会话id
        dialMode: "",                   //上次成功拨号的拨号模式（正常/特殊拨号n）
        ncTimes: ""                     //拨号认证时间（南昌特殊拨号使用）

    };

    this.SNTPC_CONFIG_1_0_0 =
    {
        id: SNTPC_CONFIG_DATA_ID,       //
        layers: [1, 0, 0],              //layer描述
        timeZoneIndex: "",
        timeZone: "",                   //用户选择的时区，目前内销产品的时区是GTM+8，即北京时间
        timeType: "",                   //三种时间来源：0:NTP、1:从PC获取、2:手动
                                        //取值范围:
                                        //TIME_TYPE_NTP                           从NTP获取
                                        //TIME_TYPE_PC                            从PC获取
                                        //TIME_TYPE_MANUAL                        手工填入
        timedisplay: "",                //时间显示方式：0:24小时、1:ampm
        ntpaddr1: "",                   //用户可配置的第一个ntp地址
        ntpaddr2: "",                   //用户可配置的第二个ntp地址
        timeDST: "",                    //夏令时开关
        startMonth: "",                 //开始月份
        startNumWeek: "",               //第几周开始
        startWeekDay: "",               //周几开始
        startHour: "",                  //开始整点时刻
        endMonth: "",                   //结束月份
        endNumWeek: "",                 //第几周结束
        endWeekDay: "",                 //周几结束
        endHour: "",                    //结束整点时刻
        rangeDST: ""                    //当前时间是否在夏令时范围

    };

    this.SNTPC_TIME_1_0_0 =
    {
        id: SNTPC_TIME_DATA_ID,         //由runtime模式改为immediately模式，用于存储时间
        layers: [1, 0, 0],              //layer描述
        year: "",                       //当前的年月日
        month: "",                      //
        day: "",                        //
        hour: "",                       //当前的时分秒
        minute: "",                     //
        second: "",                     //
        sntpcSuccess: ""                //是否从SNTP服务器成功获取到时间

    };

    this.PARENT_CTL_1_0_0 =
    {
        id: PARENT_CTL_DATA_ID,         //家长控制模块，水星机型版本
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //启用/禁用家长控制功能，默认禁用
        mon: "",                        //禁止小孩周一上网时间掩码，每个小时对应一个bit位
        tue: "",                        //禁止小孩周二上网时间掩码，每个小时对应一个bit位
        wed: "",                        //禁止小孩周三上网时间掩码，每个小时对应一个bit位
        thu: "",                        //禁止小孩周四上网时间掩码，每个小时对应一个bit位
        fri: "",                        //禁止小孩周五上网时间掩码，每个小时对应一个bit位
        sat: "",                        //禁止小孩周六上网时间掩码，每个小时对应一个bit位
        sun: "",                        //禁止小孩周日上网时间掩码，每个小时对应一个bit位
        list:                           //家长控制模块，水星机型版本
        [{                              //长度为8
            mac: "",                    //家长MAC地址
            reserved: ""                //保留，暂时不用
        }]

    };

    this.BEHAVMANG_CONFIG_1_0_0 =
    {
        id: BEHAVMANG_CONFIG_DATA_ID,   //行为管理模块，水星版本，AccessControl
        layers: [1, 0, 0],              //layer描述
        bhavEnable: "",                 //启用/禁用行为管理功能，默认禁用
        bhavRule: "",                   //允许/禁止规则列表中的行为，默认禁止
        rList:                          //行为管理模块，水星版本，AccessControl
        [{                              //长度为32
            rName: "",                  //规则条目的名称
            rActive: "",                //规则条目的状态，由嵌入式端动态确定，不可配
            rHost: "",                  //规则条目主机在主机列表中的序号
            rTarget: "",                //规则条目访问目标在目标列表中的序号
            rSchedule: "",              //规则条目日程时间在日程表中的序号
            rReserved: ""               //保留，暂时不用
        }],
        hList:                          //行为管理模块，水星版本，AccessControl
        [{                              //长度为16
            hIsIp: "",                  //主机条目是使用IP地址还是MAC地址
            hName: "",                  //主机条目的名称
            hIpStart: "",               //主机条目起始IP地址
            hIpEnd: "",                 //主机条目结束IP地址
            hMac: "",                   //主机条目的MAC地址
            hReserved: ""               //保留，暂时不用
        }],
        tList:                          //行为管理模块，水星版本，AccessControl
        [{                              //长度为16
            tType: "",                  //目标访问条目类型，0-URL、1-IP、255-任意目标
                                        //取值范围:
                                        //ACCESS_ANY_TARGET                       允许所有任意目标
                                        //ACCESS_ANY_TIME                         允许所有任意目标
            tName: "",                  //目标访问条目的名称
            tIpStart: "",               //目标访问条目起始IP地址
            tIpEnd: "",                 //目标访问条目结束IP地址
            tPortStart: "",             //目标访问条目起始端口
            tPortEnd: "",               //目标访问条目结束端口
            tProto: "",                 //目标访问条目传输层协议类型
            tUrl0: "",                  //目标访问条目第一个URL
            tUrl1: "",                  //目标访问条目第二个URL
            tUrl2: "",                  //目标访问条目第三个URL
            tUrl3: ""                   //目标访问条目第四个URL
        }],
        sList:                          //行为管理模块，水星版本，AccessControl
        [{                              //长度为16
            sName: "",                  //日程计划条目名称
            sActive: "",                //日程计划条目状态，即当前是否处于时间激活状态
            sMon: "",                   //日程计划条目周一处于激活时间掩码
            sTue: "",                   //日程计划条目周二处于激活时间掩码
            sWed: "",                   //日程计划条目周三处于激活时间掩码
            sThu: "",                   //日程计划条目周四处于激活时间掩码
            sFri: "",                   //日程计划条目周五处于激活时间掩码
            sSat: "",                   //日程计划条目周六处于激活时间掩码
            sSun: ""                    //日程计划条目周日处于激活时间掩码
        }]

    };

    this.WLAN_BASIC_1_0_0 =
    {
        id: WLAN_BASIC_DATA_ID,         //无线基础配置，如信道、带宽等
        layers: [1, 0, 0],              //layer描述
        uBand: "",                      //无线频段，2G、5G等
                                        //取值范围:
                                        //WLAN_CHIP_2G                            2.4G
                                        //WLAN_CHIP_5G                            5G
                                        //WLAN_CHIP_5G_1                          5G芯片2，用于三频机型
        bEnabled: "",                   //开启/关闭无线频段中ap模式的所有vap
        uApMode: "",                    //DUT工作模式，可以有Client，WDS Repeater等模式，默认为0，AP模式
                                        //取值范围:
                                        //WLAN_AP_MODE_AP                         AP模式，PC/PHONE<->LAN/WLAN<->DUT(AP)<->LAN<->Router
                                        //WLAN_AP_MODE_CLIENT                     Client模式，用于PC<->LAN<->DUT(Client)<->WLAN<->AP，此时DUT相当于网卡
                                        //WLAN_AP_MODE_WDSRPT                     WDS Repeater, PC/PHONE<->LAN/WLAN<->DUT(WDSRPT)<->WLAN<->Router
                                        //WLAN_AP_MODE_UNIRPT                     UNI Repeater, ???
                                        //WLAN_AP_MODE_PPT                        PPT???
                                        //WLAN_AP_MODE_MPT                        MPT???
                                        //WLAN_AP_MODE_MAX                        边界检查
        uRegionIndex: "",               //无线设备所在的区域管理标准，默认为0，即FCC标准
                                        //取值范围:
                                        //DOMAIN_FCC                              FCC认证
                                        //DOMAIN_IC                               IC认证
                                        //DOMAIN_ETSI                             CE认证，EU
                                        //DOMAIN_SPAIN                            西班牙特殊认证
                                        //DOMAIN_FRANCE                           法国特殊认证
                                        //DOMAIN_MKK                              日本 MKK
                                        //DOMAIN_ISRAEL                           以色列特殊认证
                                        //DOMAIN_MKK1                             MKK1认证
                                        //DOMAIN_MKK2                             MKK2认证
                                        //DOMAIN_MKK3                             MKK3认证
                                        //DOMAIN_FCC_BR                           FCC_BR认证
                                        //DOMAIN_ETSI_RU                          RU地区认证
                                        //DOMAIN_MAX                              边界检测
        uChannel: "",                   //选择的信道，为0表示自动选择
                                        //取值范围:
                                        //WLAN_AUTO_CHANNEL                       自动信道
        uBgnMode: "",                   //无线模式，例如11b，11g，11n等，默认为5，即11bgn混合模式
                                        //取值范围:
                                        //WLAN_MODE_SELECT_MIN                    2G边界检查
                                        //WLAN_MODE_11B_ONLY                      11b
                                        //WLAN_MODE_11G_ONLY                      11g
                                        //WLAN_MODE_11BG_MIXED                    11bg
                                        //WLAN_MODE_11N_ONLY                      11n
                                        //WLAN_MODE_11BGN_MIXED                   11gbn
                                        //WLAN_MODE_11GN_MIXED                    11gn
                                        //WLAN_MODE_SELECT_MAX                    2G边界
                                        //WLAN_MODE_5G_SELECT_MIN                 5G边界
                                        //WLAN_MODE_11A_ONLY                      5g 11a
                                        //WLAN_MODE_11N_5G_ONLY                   5g 11n
                                        //WLAN_MODE_11A_11N_MIXED                 5g 11an
                                        //WLAN_MODE_11A_11N_11AC_MIXED            5g 11anac
                                        //WLAN_MODE_11N_11AC_MIXED                5g 11nac
                                        //WLAN_MODE_5G_SELECT_MAX                 5G边界检测
        uChannelWidth: "",              //频段带宽，1代表20MHz、2代表自动、3代表40MHz
                                        //取值范围:
                                        //WLAN_CHAN_WIDTH_AUTO                    带宽自动
                                        //WLAN_CHAN_WIDTH_20M                     20M带宽
                                        //WLAN_CHAN_WIDTH_40M                     40M带宽
                                        //WLAN_CHAN_WIDTH_80M                     80M带宽
                                        //WLAN_CHAN_WIDTH_80M_ADD_80M             80+80M带宽
        adv:                            //无线基础配置，如信道、带宽等
        {                               
            uRTSThreshold: "",          //RTS阈值，取值1-2346。默认2346
                                        //取值范围:
                                        //WLAN_RTS_MAX                            最大值
                                        //WLAN_RTS_MIN                            最小值
                                        //WLAN_RTS_DEF                            默认值
            uFragThreashold: "",        //分片阈值，取值256-2346。默认2346
                                        //取值范围:
                                        //WLAN_FRAG_THRESHOLD_MAX                 最大值
                                        //WLAN_FRAG_THRESHOLD_MIN                 最小值
                                        //WLAN_FRAG_THRESHOLD_DEF                 默认值
            uBeaconInterval: "",        //发送Beacon的时间间隔，取值40-1000。默认100ms
                                        //取值范围:
                                        //WLAN_BINTVAL_MAX                        最大值
                                        //WLAN_BINTVAL_MIN                        最小值
                                        //WLAN_BINTVAL_DEF                        默认值
            uPower: "",                 //传输功率，1为高，2为中，3为低
                                        //取值范围:
                                        //WLAN_ADV_TX_POWER_MIN                   边界检测
                                        //WLAN_ADV_TX_POWER_HIGH                  高功率
                                        //WLAN_ADV_TX_POWER_MEDIUM                中功率
                                        //WLAN_ADV_TX_POWER_LOW                   低功率
                                        //WLAN_ADV_TX_POWER_MAX                   边界检测
            uDTIMInterval: "",          //DTIM时间间隔，取值1-255。默认为1
                                        //取值范围:
                                        //WLAN_DTIM_MAX                           最大值
                                        //WLAN_DTIM_MIN                           最小值
                                        //WLAN_DTIM_DEF                           默认值
            bWMEEnabled: "",            //是否开启WMM功能，默认开启
            bIsolationEnabled: "",      //是否开启AP隔离功能，默认关闭
            bShortPrmbleDisabled: "",   //是否短前导码不可用，默认FALSE，表示可用
            bShortGI: ""                //是否使用short GI，默认使用
        },
        apc:                            //无线基础配置，如信道、带宽等
        {                               
            bBridgeEnabled: "",         //是否开启WDS功能
            cBridgedSsid: "",           //桥接的RootAP设备的ssid
            cBridgedBssid: "",          //桥接的RootAP设备BSSID地址
            uWepIndex: "",              //WEP密钥的索引，WEP共提供4个密钥，取值范围是1-4
            uSecurityType: "",          //wds认证加密类型，范围1-7，为1为不加密
                                        //取值范围:
                                        //WLAN_WDS_AUTH_MIN                       边界检测
                                        //WLAN_WDS_AUTH_NONE                      无加密
                                        //WLAN_WDS_AUTH_WEP_ASCII                 WEP，ASCII模式
                                        //WLAN_WDS_AUTH_WEP_HEX                   WEP，HEX模式
                                        //WLAN_WDS_AUTH_PSK2_AES                  WPA2-PSK+AES
                                        //WLAN_WDS_AUTH_PSK_AES                   WPA-PSK+AES
                                        //WLAN_WDS_AUTH_PSK2_TKIP                 WPA-PSK2+TKIP
                                        //WLAN_WDS_AUTH_PSK_TKIP                  WPA-PSK+TKIP
                                        //WLAN_WDS_AUTH_MAX                       边界检测
            cPassWD: "",                //连接RootAp的密钥短语
            uDetect: "",                //无线地址格式，1为自动探测，2为三地址，3为四地址
                                        //取值范围:
                                        //WLAN_ADV_DETECT_AUTO                    自动侦测
                                        //WLAN_ADV_DETECT_3ADDR                   3地址
                                        //WLAN_ADV_DETECT_4ADDR                   4地址
            bLockToAp: ""               //是否绑定某个AP的BSSID，只能连接到这个BSSID上且SSID和cBridgedSsid一致
        },
        guest:                          //无线基础配置，如信道、带宽等
        {                               
            bLanAccess: "",             //是否允许访问内网资源，默认不允许
            bGuestIsolated: "",         //是否开启GuestAP隔离功能，默认开启
            uDuration: "",              //超时时间值，范围0-24小时
            bSetOpenTime: "",           //是否设置访客网络开放时间，默认不设置
            uMaxUploadSpeed: "",        //访客网络最大上传速度，默认为0，表示不限速,单位是KBps
            uMaxDownloadSpeed: "",      //访客网络最大下载速度，默认为0，表示不限速，单位是KBps
            uAllowTimeMode: "",         //访客网络开放时间模式，取值0-1,0表示超时模式，1表示周期性开放模式
            mon: "",                    //访客网络周一开放时间，每个小时对应一个bit位
            tue: "",                    //访客网络周二开放时间，每个小时对应一个bit位
            wed: "",                    //访客网络周三开放时间，每个小时对应一个bit位
            thu: "",                    //访客网络周四开放时间，每个小时对应一个bit位
            fri: "",                    //访客网络周五开放时间，每个小时对应一个bit位
            sat: "",                    //访客网络周六开放时间，每个小时对应一个bit位
            sun: ""                     //访客网络周日开放时间，每个小时对应一个bit位
        },
        bTurboOn: "",                   //是否按下turbo键，默认FALSE
        bMumimo: "",                    //开启/关闭MU-MIMO功能
        bAtf: "",                        //开启/关闭Airtim Fairness功能
        currentCountryName: ""          //当前国家名称(支持页面可选多国家码才会用到)

    };

    this.WLAN_BASIC_2_0_0 =
    {
        id: WLAN_BASIC_DATA_ID,         //无线基础配置，如信道、带宽等
        layers: [2, 0, 0],              //layer描述
        uBand: "",                      //无线频段，2G、5G等
                                        //取值范围:
                                        //WLAN_CHIP_2G                            2.4G
                                        //WLAN_CHIP_5G                            5G
                                        //WLAN_CHIP_5G_1                          5G芯片2，用于三频机型
        bEnabled: "",                   //开启/关闭无线频段中ap模式的所有vap
        uApMode: "",                    //DUT工作模式，可以有Client，WDS Repeater等模式，默认为0，AP模式
                                        //取值范围:
                                        //WLAN_AP_MODE_AP                         AP模式，PC/PHONE<->LAN/WLAN<->DUT(AP)<->LAN<->Router
                                        //WLAN_AP_MODE_CLIENT                     Client模式，用于PC<->LAN<->DUT(Client)<->WLAN<->AP，此时DUT相当于网卡
                                        //WLAN_AP_MODE_WDSRPT                     WDS Repeater, PC/PHONE<->LAN/WLAN<->DUT(WDSRPT)<->WLAN<->Router
                                        //WLAN_AP_MODE_UNIRPT                     UNI Repeater, ???
                                        //WLAN_AP_MODE_PPT                        PPT???
                                        //WLAN_AP_MODE_MPT                        MPT???
                                        //WLAN_AP_MODE_MAX                        边界检查
        uRegionIndex: "",               //无线设备所在的区域管理标准，默认为0，即FCC标准
                                        //取值范围:
                                        //DOMAIN_FCC                              FCC认证
                                        //DOMAIN_IC                               IC认证
                                        //DOMAIN_ETSI                             CE认证，EU
                                        //DOMAIN_SPAIN                            西班牙特殊认证
                                        //DOMAIN_FRANCE                           法国特殊认证
                                        //DOMAIN_MKK                              日本 MKK
                                        //DOMAIN_ISRAEL                           以色列特殊认证
                                        //DOMAIN_MKK1                             MKK1认证
                                        //DOMAIN_MKK2                             MKK2认证
                                        //DOMAIN_MKK3                             MKK3认证
                                        //DOMAIN_FCC_BR                           FCC_BR认证
                                        //DOMAIN_ETSI_RU                          RU地区认证
                                        //DOMAIN_MAX                              边界检测
        uChannel: "",                   //选择的信道，为0表示自动选择
                                        //取值范围:
                                        //WLAN_AUTO_CHANNEL                       自动信道
        uBgnMode: "",                   //无线模式，例如11b，11g，11n等，默认为5，即11bgn混合模式
                                        //取值范围:
                                        //WLAN_MODE_SELECT_MIN                    2G边界检查
                                        //WLAN_MODE_11B_ONLY                      11b
                                        //WLAN_MODE_11G_ONLY                      11g
                                        //WLAN_MODE_11BG_MIXED                    11bg
                                        //WLAN_MODE_11N_ONLY                      11n
                                        //WLAN_MODE_11BGN_MIXED                   11gbn
                                        //WLAN_MODE_11GN_MIXED                    11gn
                                        //WLAN_MODE_SELECT_MAX                    2G边界
                                        //WLAN_MODE_5G_SELECT_MIN                 5G边界
                                        //WLAN_MODE_11A_ONLY                      5g 11a
                                        //WLAN_MODE_11N_5G_ONLY                   5g 11n
                                        //WLAN_MODE_11A_11N_MIXED                 5g 11an
                                        //WLAN_MODE_11A_11N_11AC_MIXED            5g 11anac
                                        //WLAN_MODE_11N_11AC_MIXED                5g 11nac
                                        //WLAN_MODE_5G_SELECT_MAX                 5G边界检测
        uChannelWidth: "",              //频段带宽，1代表20MHz、2代表自动、3代表40MHz
                                        //取值范围:
                                        //WLAN_CHAN_WIDTH_AUTO                    带宽自动
                                        //WLAN_CHAN_WIDTH_20M                     20M带宽
                                        //WLAN_CHAN_WIDTH_40M                     40M带宽
                                        //WLAN_CHAN_WIDTH_80M                     80M带宽
                                        //WLAN_CHAN_WIDTH_80M_ADD_80M             80+80M带宽
        adv:                            //无线基础配置，如信道、带宽等
        {                               
            uRTSThreshold: "",          //RTS阈值，取值1-2346。默认2346
                                        //取值范围:
                                        //WLAN_RTS_MAX                            最大值
                                        //WLAN_RTS_MIN                            最小值
                                        //WLAN_RTS_DEF                            默认值
            uFragThreashold: "",        //分片阈值，取值256-2346。默认2346
                                        //取值范围:
                                        //WLAN_FRAG_THRESHOLD_MAX                 最大值
                                        //WLAN_FRAG_THRESHOLD_MIN                 最小值
                                        //WLAN_FRAG_THRESHOLD_DEF                 默认值
            uBeaconInterval: "",        //发送Beacon的时间间隔，取值40-1000。默认100ms
                                        //取值范围:
                                        //WLAN_BINTVAL_MAX                        最大值
                                        //WLAN_BINTVAL_MIN                        最小值
                                        //WLAN_BINTVAL_DEF                        默认值
            uPower: "",                 //传输功率，1为高，2为中，3为低
                                        //取值范围:
                                        //WLAN_ADV_TX_POWER_MIN                   边界检测
                                        //WLAN_ADV_TX_POWER_HIGH                  高功率
                                        //WLAN_ADV_TX_POWER_MEDIUM                中功率
                                        //WLAN_ADV_TX_POWER_LOW                   低功率
                                        //WLAN_ADV_TX_POWER_MAX                   边界检测
            uDTIMInterval: "",          //DTIM时间间隔，取值1-255。默认为1
                                        //取值范围:
                                        //WLAN_DTIM_MAX                           最大值
                                        //WLAN_DTIM_MIN                           最小值
                                        //WLAN_DTIM_DEF                           默认值
            bWMEEnabled: "",            //是否开启WMM功能，默认开启
            bIsolationEnabled: "",      //是否开启AP隔离功能，默认关闭
            bShortPrmbleDisabled: "",   //是否短前导码不可用，默认FALSE，表示可用
            bShortGI: ""                //是否使用short GI，默认使用
        },
        apc:                            //无线基础配置，如信道、带宽等
        {                               
            bBridgeEnabled: "",         //是否开启WDS功能
            cBridgedSsid: "",           //桥接的RootAP设备的ssid
            cBridgedBssid: "",          //桥接的RootAP设备BSSID地址
            uWepIndex: "",              //WEP密钥的索引，WEP共提供4个密钥，取值范围是1-4
            uSecurityType: "",          //wds认证加密类型，范围1-7，为1为不加密
                                        //取值范围:
                                        //WLAN_WDS_AUTH_MIN                       边界检测
                                        //WLAN_WDS_AUTH_NONE                      无加密
                                        //WLAN_WDS_AUTH_WEP_ASCII                 WEP，ASCII模式
                                        //WLAN_WDS_AUTH_WEP_HEX                   WEP，HEX模式
                                        //WLAN_WDS_AUTH_PSK2_AES                  WPA2-PSK+AES
                                        //WLAN_WDS_AUTH_PSK_AES                   WPA-PSK+AES
                                        //WLAN_WDS_AUTH_PSK2_TKIP                 WPA-PSK2+TKIP
                                        //WLAN_WDS_AUTH_PSK_TKIP                  WPA-PSK+TKIP
                                        //WLAN_WDS_AUTH_MAX                       边界检测
            cPassWD: "",                //连接RootAp的密钥短语
            uDetect: "",                //无线地址格式，1为自动探测，2为三地址，3为四地址
                                        //取值范围:
                                        //WLAN_ADV_DETECT_AUTO                    自动侦测
                                        //WLAN_ADV_DETECT_3ADDR                   3地址
                                        //WLAN_ADV_DETECT_4ADDR                   4地址
            bLockToAp: ""               //是否绑定某个AP的BSSID，只能连接到这个BSSID上且SSID和cBridgedSsid一致
        },
        guest:                          //无线基础配置，如信道、带宽等
        {                               
            bLanAccess: "",             //是否允许访问内网资源，默认不允许
            bGuestIsolated: "",         //是否开启GuestAP隔离功能，默认开启
            uDuration: "",              //超时时间值，范围0-24小时
            bSetOpenTime: "",           //是否设置访客网络开放时间，默认不设置
            uMaxUploadSpeed: "",        //访客网络最大上传速度，默认为0，表示不限速,单位是KBps
            uMaxDownloadSpeed: "",      //访客网络最大下载速度，默认为0，表示不限速，单位是KBps
            uAllowTimeMode: "",         //访客网络开放时间模式，取值0-1,0表示超时模式，1表示周期性开放模式
            mon: "",                    //访客网络周一开放时间，每个小时对应一个bit位
            tue: "",                    //访客网络周二开放时间，每个小时对应一个bit位
            wed: "",                    //访客网络周三开放时间，每个小时对应一个bit位
            thu: "",                    //访客网络周四开放时间，每个小时对应一个bit位
            fri: "",                    //访客网络周五开放时间，每个小时对应一个bit位
            sat: "",                    //访客网络周六开放时间，每个小时对应一个bit位
            sun: ""                     //访客网络周日开放时间，每个小时对应一个bit位
        },
        bTurboOn: "",                   //是否按下turbo键，默认FALSE
        bMumimo: "",                    //开启/关闭MU-MIMO功能
        bAtf: "",                        //开启/关闭Airtim Fairness功能
        currentCountryName: ""          //当前国家名称(支持页面可选多国家码才会用到)

    };

    this.MBSSID_MAIN_1_1_0 =
    {
        id: MBSSID_MAIN_DATA_ID,        //无线VAP设置，如主网络、访客网络
        layers: [1, 1, 0],              //layer描述
        uUnit: "",                      //该无线接口的在驱动中的接口号
                                        //取值范围:
                                        //UNIT_MAIN                               主接口
                                        //UNIT_GUESTNETWORK                       客户网络接口
                                        //UNIT_APC                                APC接口
                                        //UNIT_MAX                                边界检测
        cSsidPrefix: "",                //默认SSID的前缀，IPTV为iTV，访客网络为Guest
        uRadiusIp: "",                  //Radius服务器IP地址
        uRadiusGKUpdateIntvl: "",       //Radius组密钥更新周期，最小值30。为0表示不更新
        uPskGKUpdateIntvl: "",          //Psk组密钥更新周期，最小值30。为0表示不更新
        privacyRcd:                     //无线VAP设置，如主网络、访客网络
        [{                              //长度为4
            uKeyLength: "",             //WEP加密使用的密钥位数，5为64位，13为128位，16为152位
            cKeyVal: ""                 //WEP密钥值,最大需要存储32个hex
        }],
        uRadiusPort: "",                //Radius服务器端口号，默认1812
                                        //取值范围:
                                        //WLAN_RADIUS_PORT_DEFAULT                默认端口
        uKeyType: "",                   //WEP密钥的格式
                                        //取值范围:
                                        //WLAN_WEP_HEX                            HEX
                                        //WLAN_WEP_ASCII                          ASCII
        uDefaultKey: "",                //默认WEP密钥的索引。默认为1
        bEnable: "",                    //是否开启此网络，默认开启
        bBcastSsid: "",                 //是否开启SSID广播功能，默认开启
        cSsid: "",                      //网络的SSID
        bSecurityEnable: "",            //无线是否加密，默认不加密
        uAuthType: "",                  //WLAN加密与认证协议，例如WPA(2)-PSK,WPA(2),WEP等
                                        //取值范围:
                                        //WLAN_PRIVACY_MODE_MIN                   边界检测
                                        //WLAN_PRIVACY_MODE_WEP                   WEP
                                        //WLAN_PRIVACY_MODE_WPA_WPA2              WPA
                                        //WLAN_PRIVACY_MODE_PSK_PSK2              PSK认证，属于WPA的一种，另外一种是RADIUS
                                        //WLAN_PRIVACY_MODE_MAX                   边界检测
        uWEPSecOpt: "",                 //WEP认证类型，目前支持开放系统和共享密钥
                                        //取值范围:
                                        //WLAN_SECURITY_OPTION_WEP_MIN            按需拨号
                                        //WLAN_SECURITY_OPTION_WEP_OPEN           OPEN方式认证
                                        //WLAN_SECURITY_OPTION_WEP_SHARE          SHARE方式认证
                                        //WLAN_SECURITY_OPTION_WEP_AUTO           AUTO方式认证
                                        //WLAN_SECURITY_OPTION_WEP_MAX            边界检测
        uRadiusSecOpt: "",              //Radius认证类型，目前支持WPA，WPA2，自动
                                        //取值范围:
                                        //WLAN_SECURITY_OPTION_MIN                按需拨号
                                        //WLAN_SECURITY_OPTION_WPA                OPEN方式认证
                                        //WLAN_SECURITY_OPTION_WPA2               SHARE方式认证
                                        //WLAN_SECURITY_OPTION_AUTO               AUTO方式认证
                                        //WLAN_SECURITY_OPTION_MAX                边界检测
        uPSKSecOpt: "",                 //PSK认证类型，默认为8，自动
        uRadiusEncryptType: "",         //Radius加密类型，1为自动，2为TKIP，3为AES
        uPSKEncryptType: "",            //PSK加密类型，范围1-3，默认为3，AES加密
                                        //取值范围:
                                        //WLAN_ENCRYPT_TYPE_MIN                   边界检测
                                        //WLAN_ENCRYPT_TYPE_AUTO                  自动选择
                                        //WLAN_ENCRYPT_TYPE_TKIP                  TKIP加密
                                        //WLAN_ENCRYPT_TYPE_AES                   AES加密
                                        //WLAN_ENCRYPT_TYPE_MAX                   边界检测
        cRadiusSecret: "",              //Radius密码，也即Authenticator与Radius Server之间的密码
        cPskSecret: "",                 //PSK密码短语
        bSecCheck: "",                  //无线安全强度指示，TRUE表示弱，FALSE表示强
        wps:                            //无线VAP设置，如主网络、访客网络
        {                               
            bEnabled: "",               //wps功能是否开启
            cUsrPIN: "",                //当前使用的PIN码
            bConfigured: "",            //WPS是否被配置过
            bIsLocked: "",              //WPS是否被锁定
            bEnRtPIN: ""                //Router's PIN功能是否开启
        },
        bWifiBtnRecEnable: ""           //WiFi硬件开关关闭所有vaps时，记录的vaps的开启状态

    };

    this.MBSSID_MAIN_1_2_0 =
    {
        id: MBSSID_MAIN_DATA_ID,        //无线VAP设置，如主网络、访客网络
        layers: [1, 2, 0],              //layer描述
        uUnit: "",                      //该无线接口的在驱动中的接口号
                                        //取值范围:
                                        //UNIT_MAIN                               主接口
                                        //UNIT_GUESTNETWORK                       客户网络接口
                                        //UNIT_APC                                APC接口
                                        //UNIT_MAX                                边界检测
        cSsidPrefix: "",                //默认SSID的前缀，IPTV为iTV，访客网络为Guest
        uRadiusIp: "",                  //Radius服务器IP地址
        uRadiusGKUpdateIntvl: "",       //Radius组密钥更新周期，最小值30。为0表示不更新
        uPskGKUpdateIntvl: "",          //Psk组密钥更新周期，最小值30。为0表示不更新
        privacyRcd:                     //无线VAP设置，如主网络、访客网络
        [{                              //长度为4
            uKeyLength: "",             //WEP加密使用的密钥位数，5为64位，13为128位，16为152位
            cKeyVal: ""                 //WEP密钥值,最大需要存储32个hex
        }],
        uRadiusPort: "",                //Radius服务器端口号，默认1812
                                        //取值范围:
                                        //WLAN_RADIUS_PORT_DEFAULT                默认端口
        uKeyType: "",                   //WEP密钥的格式
                                        //取值范围:
                                        //WLAN_WEP_HEX                            HEX
                                        //WLAN_WEP_ASCII                          ASCII
        uDefaultKey: "",                //默认WEP密钥的索引。默认为1
        bEnable: "",                    //是否开启此网络，默认开启
        bBcastSsid: "",                 //是否开启SSID广播功能，默认开启
        cSsid: "",                      //网络的SSID
        bSecurityEnable: "",            //无线是否加密，默认不加密
        uAuthType: "",                  //WLAN加密与认证协议，例如WPA(2)-PSK,WPA(2),WEP等
                                        //取值范围:
                                        //WLAN_PRIVACY_MODE_MIN                   边界检测
                                        //WLAN_PRIVACY_MODE_WEP                   WEP
                                        //WLAN_PRIVACY_MODE_WPA_WPA2              WPA
                                        //WLAN_PRIVACY_MODE_PSK_PSK2              PSK认证，属于WPA的一种，另外一种是RADIUS
                                        //WLAN_PRIVACY_MODE_MAX                   边界检测
        uWEPSecOpt: "",                 //WEP认证类型，目前支持开放系统和共享密钥
                                        //取值范围:
                                        //WLAN_SECURITY_OPTION_WEP_MIN            按需拨号
                                        //WLAN_SECURITY_OPTION_WEP_OPEN           OPEN方式认证
                                        //WLAN_SECURITY_OPTION_WEP_SHARE          SHARE方式认证
                                        //WLAN_SECURITY_OPTION_WEP_AUTO           AUTO方式认证
                                        //WLAN_SECURITY_OPTION_WEP_MAX            边界检测
        uRadiusSecOpt: "",              //Radius认证类型，目前支持WPA，WPA2，自动
                                        //取值范围:
                                        //WLAN_SECURITY_OPTION_MIN                按需拨号
                                        //WLAN_SECURITY_OPTION_WPA                OPEN方式认证
                                        //WLAN_SECURITY_OPTION_WPA2               SHARE方式认证
                                        //WLAN_SECURITY_OPTION_AUTO               AUTO方式认证
                                        //WLAN_SECURITY_OPTION_MAX                边界检测
        uPSKSecOpt: "",                 //PSK认证类型，默认为8，自动
        uRadiusEncryptType: "",         //Radius加密类型，1为自动，2为TKIP，3为AES
        uPSKEncryptType: "",            //PSK加密类型，范围1-3，默认为3，AES加密
                                        //取值范围:
                                        //WLAN_ENCRYPT_TYPE_MIN                   边界检测
                                        //WLAN_ENCRYPT_TYPE_AUTO                  自动选择
                                        //WLAN_ENCRYPT_TYPE_TKIP                  TKIP加密
                                        //WLAN_ENCRYPT_TYPE_AES                   AES加密
                                        //WLAN_ENCRYPT_TYPE_MAX                   边界检测
        cRadiusSecret: "",              //Radius密码，也即Authenticator与Radius Server之间的密码
        cPskSecret: "",                 //PSK密码短语
        bSecCheck: "",                  //无线安全强度指示，TRUE表示弱，FALSE表示强
        wps:                            //无线VAP设置，如主网络、访客网络
        {                               
            bEnabled: "",               //wps功能是否开启
            cUsrPIN: "",                //当前使用的PIN码
            bConfigured: "",            //WPS是否被配置过
            bIsLocked: "",              //WPS是否被锁定
            bEnRtPIN: ""                //Router's PIN功能是否开启
        },
        bWifiBtnRecEnable: ""           //WiFi硬件开关关闭所有vaps时，记录的vaps的开启状态

    };

    this.MBSSID_MAIN_2_1_0 =
    {
        id: MBSSID_MAIN_DATA_ID,        //无线VAP设置，如主网络、访客网络
        layers: [2, 1, 0],              //layer描述
        uUnit: "",                      //该无线接口的在驱动中的接口号
                                        //取值范围:
                                        //UNIT_MAIN                               主接口
                                        //UNIT_GUESTNETWORK                       客户网络接口
                                        //UNIT_APC                                APC接口
                                        //UNIT_MAX                                边界检测
        cSsidPrefix: "",                //默认SSID的前缀，IPTV为iTV，访客网络为Guest
        uRadiusIp: "",                  //Radius服务器IP地址
        uRadiusGKUpdateIntvl: "",       //Radius组密钥更新周期，最小值30。为0表示不更新
        uPskGKUpdateIntvl: "",          //Psk组密钥更新周期，最小值30。为0表示不更新
        privacyRcd:                     //无线VAP设置，如主网络、访客网络
        [{                              //长度为4
            uKeyLength: "",             //WEP加密使用的密钥位数，5为64位，13为128位，16为152位
            cKeyVal: ""                 //WEP密钥值,最大需要存储32个hex
        }],
        uRadiusPort: "",                //Radius服务器端口号，默认1812
                                        //取值范围:
                                        //WLAN_RADIUS_PORT_DEFAULT                默认端口
        uKeyType: "",                   //WEP密钥的格式
                                        //取值范围:
                                        //WLAN_WEP_HEX                            HEX
                                        //WLAN_WEP_ASCII                          ASCII
        uDefaultKey: "",                //默认WEP密钥的索引。默认为1
        bEnable: "",                    //是否开启此网络，默认开启
        bBcastSsid: "",                 //是否开启SSID广播功能，默认开启
        cSsid: "",                      //网络的SSID
        bSecurityEnable: "",            //无线是否加密，默认不加密
        uAuthType: "",                  //WLAN加密与认证协议，例如WPA(2)-PSK,WPA(2),WEP等
                                        //取值范围:
                                        //WLAN_PRIVACY_MODE_MIN                   边界检测
                                        //WLAN_PRIVACY_MODE_WEP                   WEP
                                        //WLAN_PRIVACY_MODE_WPA_WPA2              WPA
                                        //WLAN_PRIVACY_MODE_PSK_PSK2              PSK认证，属于WPA的一种，另外一种是RADIUS
                                        //WLAN_PRIVACY_MODE_MAX                   边界检测
        uWEPSecOpt: "",                 //WEP认证类型，目前支持开放系统和共享密钥
                                        //取值范围:
                                        //WLAN_SECURITY_OPTION_WEP_MIN            按需拨号
                                        //WLAN_SECURITY_OPTION_WEP_OPEN           OPEN方式认证
                                        //WLAN_SECURITY_OPTION_WEP_SHARE          SHARE方式认证
                                        //WLAN_SECURITY_OPTION_WEP_AUTO           AUTO方式认证
                                        //WLAN_SECURITY_OPTION_WEP_MAX            边界检测
        uRadiusSecOpt: "",              //Radius认证类型，目前支持WPA，WPA2，自动
                                        //取值范围:
                                        //WLAN_SECURITY_OPTION_MIN                按需拨号
                                        //WLAN_SECURITY_OPTION_WPA                OPEN方式认证
                                        //WLAN_SECURITY_OPTION_WPA2               SHARE方式认证
                                        //WLAN_SECURITY_OPTION_AUTO               AUTO方式认证
                                        //WLAN_SECURITY_OPTION_MAX                边界检测
        uPSKSecOpt: "",                 //PSK认证类型，默认为8，自动
        uRadiusEncryptType: "",         //Radius加密类型，1为自动，2为TKIP，3为AES
        uPSKEncryptType: "",            //PSK加密类型，范围1-3，默认为3，AES加密
                                        //取值范围:
                                        //WLAN_ENCRYPT_TYPE_MIN                   边界检测
                                        //WLAN_ENCRYPT_TYPE_AUTO                  自动选择
                                        //WLAN_ENCRYPT_TYPE_TKIP                  TKIP加密
                                        //WLAN_ENCRYPT_TYPE_AES                   AES加密
                                        //WLAN_ENCRYPT_TYPE_MAX                   边界检测
        cRadiusSecret: "",              //Radius密码，也即Authenticator与Radius Server之间的密码
        cPskSecret: "",                 //PSK密码短语
        bSecCheck: "",                  //无线安全强度指示，TRUE表示弱，FALSE表示强
        wps:                            //无线VAP设置，如主网络、访客网络
        {                               
            bEnabled: "",               //wps功能是否开启
            cUsrPIN: "",                //当前使用的PIN码
            bConfigured: "",            //WPS是否被配置过
            bIsLocked: "",              //WPS是否被锁定
            bEnRtPIN: ""                //Router's PIN功能是否开启
        },
        bWifiBtnRecEnable: ""           //WiFi硬件开关关闭所有vaps时，记录的vaps的开启状态

    };

    this.MBSSID_MAIN_2_2_0 =
    {
        id: MBSSID_MAIN_DATA_ID,        //无线VAP设置，如主网络、访客网络
        layers: [2, 2, 0],              //layer描述
        uUnit: "",                      //该无线接口的在驱动中的接口号
                                        //取值范围:
                                        //UNIT_MAIN                               主接口
                                        //UNIT_GUESTNETWORK                       客户网络接口
                                        //UNIT_APC                                APC接口
                                        //UNIT_MAX                                边界检测
        cSsidPrefix: "",                //默认SSID的前缀，IPTV为iTV，访客网络为Guest
        uRadiusIp: "",                  //Radius服务器IP地址
        uRadiusGKUpdateIntvl: "",       //Radius组密钥更新周期，最小值30。为0表示不更新
        uPskGKUpdateIntvl: "",          //Psk组密钥更新周期，最小值30。为0表示不更新
        privacyRcd:                     //无线VAP设置，如主网络、访客网络
        [{                              //长度为4
            uKeyLength: "",             //WEP加密使用的密钥位数，5为64位，13为128位，16为152位
            cKeyVal: ""                 //WEP密钥值,最大需要存储32个hex
        }],
        uRadiusPort: "",                //Radius服务器端口号，默认1812
                                        //取值范围:
                                        //WLAN_RADIUS_PORT_DEFAULT                默认端口
        uKeyType: "",                   //WEP密钥的格式
                                        //取值范围:
                                        //WLAN_WEP_HEX                            HEX
                                        //WLAN_WEP_ASCII                          ASCII
        uDefaultKey: "",                //默认WEP密钥的索引。默认为1
        bEnable: "",                    //是否开启此网络，默认开启
        bBcastSsid: "",                 //是否开启SSID广播功能，默认开启
        cSsid: "",                      //网络的SSID
        bSecurityEnable: "",            //无线是否加密，默认不加密
        uAuthType: "",                  //WLAN加密与认证协议，例如WPA(2)-PSK,WPA(2),WEP等
                                        //取值范围:
                                        //WLAN_PRIVACY_MODE_MIN                   边界检测
                                        //WLAN_PRIVACY_MODE_WEP                   WEP
                                        //WLAN_PRIVACY_MODE_WPA_WPA2              WPA
                                        //WLAN_PRIVACY_MODE_PSK_PSK2              PSK认证，属于WPA的一种，另外一种是RADIUS
                                        //WLAN_PRIVACY_MODE_MAX                   边界检测
        uWEPSecOpt: "",                 //WEP认证类型，目前支持开放系统和共享密钥
                                        //取值范围:
                                        //WLAN_SECURITY_OPTION_WEP_MIN            按需拨号
                                        //WLAN_SECURITY_OPTION_WEP_OPEN           OPEN方式认证
                                        //WLAN_SECURITY_OPTION_WEP_SHARE          SHARE方式认证
                                        //WLAN_SECURITY_OPTION_WEP_AUTO           AUTO方式认证
                                        //WLAN_SECURITY_OPTION_WEP_MAX            边界检测
        uRadiusSecOpt: "",              //Radius认证类型，目前支持WPA，WPA2，自动
                                        //取值范围:
                                        //WLAN_SECURITY_OPTION_MIN                按需拨号
                                        //WLAN_SECURITY_OPTION_WPA                OPEN方式认证
                                        //WLAN_SECURITY_OPTION_WPA2               SHARE方式认证
                                        //WLAN_SECURITY_OPTION_AUTO               AUTO方式认证
                                        //WLAN_SECURITY_OPTION_MAX                边界检测
        uPSKSecOpt: "",                 //PSK认证类型，默认为8，自动
        uRadiusEncryptType: "",         //Radius加密类型，1为自动，2为TKIP，3为AES
        uPSKEncryptType: "",            //PSK加密类型，范围1-3，默认为3，AES加密
                                        //取值范围:
                                        //WLAN_ENCRYPT_TYPE_MIN                   边界检测
                                        //WLAN_ENCRYPT_TYPE_AUTO                  自动选择
                                        //WLAN_ENCRYPT_TYPE_TKIP                  TKIP加密
                                        //WLAN_ENCRYPT_TYPE_AES                   AES加密
                                        //WLAN_ENCRYPT_TYPE_MAX                   边界检测
        cRadiusSecret: "",              //Radius密码，也即Authenticator与Radius Server之间的密码
        cPskSecret: "",                 //PSK密码短语
        bSecCheck: "",                  //无线安全强度指示，TRUE表示弱，FALSE表示强
        wps:                            //无线VAP设置，如主网络、访客网络
        {                               
            bEnabled: "",               //wps功能是否开启
            cUsrPIN: "",                //当前使用的PIN码
            bConfigured: "",            //WPS是否被配置过
            bIsLocked: "",              //WPS是否被锁定
            bEnRtPIN: ""                //Router's PIN功能是否开启
        },
        bWifiBtnRecEnable: ""           //WiFi硬件开关关闭所有vaps时，记录的vaps的开启状态

    };

    this.WLAN_AP_LIST_1_0_0 =
    {
        id: WLAN_AP_LIST_DATA_ID,       //扫描得到的AP列表
        layers: [1, 0, 0],              //layer描述
        apEntry:                        //扫描得到的AP列表
        [{                              //长度为64
            cBssid: "",                 //扫描到的AP的BSSID
            cSsid: "",                  //扫描到的AP的SSID
            uRssi: "",                  //扫描到的AP的RSSI
            uChannel: "",               //扫描到的AP的工作信道
            uAuthMode: "",              //扫描到的AP的认证模式
            uBgnMode: "",               //扫描到的AP的采用的无线模式
            uChanWidth: ""              //扫描到的AP的支持的频段带宽
        }],
        uApCnt: "",                     //总共扫描到的AP数目
        reserved: ""                    //仅做对齐

    };

    this.IPTV_1_0_0 =
    {
        id: IPTV_DATA_ID,               //IPTV配置
        layers: [1, 0, 0],              //layer描述
        uMode: "",                      //IPTV工作模式，取值为Disabled、Bridge和802.1Q VLAN
                                        //取值范围:
                                        //IPTV_MODE_DISABLED                      禁用IPTV
                                        //IPTV_MODE_BRIDGE                        桥接模式
                                        //IPTV_MODE_8021Q                         802.1Q VLAN模式
                                        //IPTV_MODE_RU                            俄罗斯地区模式
                                        //IPTV_MODE_SG_SINGTEL                    新加坡电信模式
                                        //IPTV_MODE_MY_UNIFI                      马来西亚UNIFI模式
                                        //IPTV_MODE_MY_MAXIS1                     马来西亚MAXIS模式1
                                        //IPTV_MODE_MY_MAXIS2                     马来西亚MAXIS模式2
                                        //IPTV_MODE_VN_VIETTEL                    越南VIERREL模式
                                        //IPTV_MODE_PT_MEO                        葡萄牙MEO模式
                                        //IPTV_MODE_PT_VODAFONE                   葡萄牙沃达丰模式
                                        //IPTV_MODE_AU_NBN                        澳大利亚NBN模式
                                        //IPTV_MODE_NZ_UFB                        新西兰UFB模式
                                        //IPTV_MODE_CUSTOM                        手动设置
                                        //IPTV_MODE_MY_CELCOM                     马来西亚CELCOM模式
                                        //IPTV_MODE_TH_AIS                        泰国AIS模式
                                        //IPTV_MODE_DE_DT_DEFAULT                 德国电信默认模式
                                        //IPTV_MODE_DE_DT_VLAN8                   德国电信IPTV选择VLAN8模式
                                        //IPTV_MODE_US_CENTURYLINK                美国CenturyLink模式
                                        //IPTV_MODE_END                           边界检测
        uBridgePorts: "",               //Bridge模式的成员接口，bit 0~3分别对应LAN 1~4，1为包含，0为不包含
        uService:                       //IPTV配置
        [{                              //长度为4
            uVid: "",                   //VLAN ID
            uVlanPriority: "",          //VLAN Priority
            uMemberPorts: "",           //成员接口,bit 0~3分别对应LAN 1~4，1为包含，0为不包含
            bTagEnable: "",             //是否支持WAN口TAG
            uServiceType: ""            //类型，取值为Internet、IPTV、VOIP和Multicast Tag，类型设置为整型，以使地址按4倍数偏移
                                        //取值范围:
                                        //IPTV_SERVICE_INTERNET                   internet服务
                                        //IPTV_SERVICE_IPTV                       iptv服务
                                        //IPTV_SERVICE_VOIP                       voip服务
                                        //IPTV_SERVICE_MULTICAST                  multicast服务
                                        //IPTV_SERVICE_BRIDGE                     bridge服务
        }]

    };

    this.PPTP_1_0_0 =
    {
        id: PPTP_DATA_ID,               //PPTP拨号配置
        layers: [1, 0, 0],              //layer描述
        userName: "",                   //pptp用户名
        passwd: "",                     //pptp密码
        domainIp: "",                   //pptp服务器域名或者ip
        bDhcp: "",                      //是否采用dhcp方式获取ip地址
        ip: "",                         //静态IP
        mask: "",                       //静态IP掩码
        gateway: "",                    //静态IP网关
        dns: [],                        //静态IP的DNS
        mtu: "",                        //mtu值
        linkType: "",                   //连接方式（自动 手动 按需）
                                        //取值范围:
                                        //PPTP_DEMAND                             按需拨号
                                        //PPTP_AUTO                               自动拨号
                                        //PPTP_TIMEING                            定时连接
                                        //PPTP_MANUAL                             手动拨号
                                        //PPTP_LINK_TYPE_MAX                      边界检测
        maxIdleTime: ""                 //自动断线等待时间（分钟）

    };

    this.L2TP_1_0_0 =
    {
        id: L2TP_DATA_ID,               //L2TP拨号配置
        layers: [1, 0, 0],              //layer描述
        userName: "",                   //l2tp用户名
        passwd: "",                     //l2tp密码
        domainIp: "",                   //l2tp服务器域名或者ip
        bDhcp: "",                      //是否采用dhcp方式获取ip地址
        ip: "",                         //静态IP
        mask: "",                       //静态IP掩码
        gateway: "",                    //静态IP网关
        dns: [],                        //静态IP的DNS
        mtu: "",                        //mtu值
        linkType: "",                   //连接方式（自动 手动 按需）
                                        //取值范围:
                                        //L2TP_DEMAND                             按需拨号
                                        //L2TP_AUTO                               自动拨号
                                        //L2TP_TIMING                             定时连接
                                        //L2TP_MANUAL                             手动拨号
                                        //L2TP_LINK_TYPE_NUM                      边界检测
        maxIdleTime: ""                 //自动断线等待时间（分钟）

    };

    this.DDNS_1_0_0 =
    {
        id: DDNS_DATA_ID,               //
        layers: [1, 0, 0],              //layer描述
        mode: "",                       //当前模式，-1为Disable，0为NO-IP，1为DYNDNS，2为TP-LINK DDNS 。下面的serviceList[0]记录NO-IP的配置，service[1]记录DYNDNS的配置，暂未使用
        serviceList:                    //
        [{                              //长度为2
            enable: "",                 //是否开启
            username: "",               //用户名
            password: "",               //密码
            domainName: "",             //域名
            ip: "",                     //与domainName绑定的IP地址
            status: "",                 //最近一次update后的状态
                                        //取值范围:
                                        //DDNS_STATE_NOT_LAUNCH                   尚未加载
                                        //DDNS_STATE_START                        开始
                                        //DDNS_STATE_SEND_DNS_QUERY               发送DNS查询
                                        //DDNS_STATE_READ_DNS_RESPONSE            读取DNS回包
                                        //DDNS_STATE_TCP_CONNECTION               TCP连接
                                        //DDNS_STATE_SEND_HTTP_REQUEST            发送http查询
                                        //DDNS_STATE_READ_HTTP_REPLY              读取http返回值
                                        //DDNS_STATE_SUCCESS_GOOD                 成功
                                        //DDNS_STATE_SUCCESS_NOCHG                成功
                                        //DDNS_STATE_FAIL_NOHOST                  无该host
                                        //DDNS_STATE_FAIL_BADAUTH                 错误认证
                                        //DDNS_STATE_FAIL_BADAGENT                错误代理
                                        //DDNS_STATE_FAIL_NOT_DONATOR             ？？？
                                        //DDNS_STATE_FAIL_ABUSE                   失败
                                        //DDNS_STATE_FAIL_911                     911失败
                                        //DDNS_STATE_FAIL_NOTFQDN                 ？？？
                                        //DDNS_STATE_FAIL_NUMHOST                 ？？？
                                        //DDNS_STATE_FAIL_DNSERR                  DNS查询失败
                                        //DDNS_STATE_FAIL_CONNECT_ERROR           连接失败
                                        //DDNS_STATE_FAIL_UNKNOWN                 未知失败
            wanIpBind: ""               //domainName是否与wanIp绑定，绑定时检测注册的域名返回结果为wanIp，不会是外层ip
        }]

    };

    this.DDNS_STATUS_1_0_0 =
    {
        id: DDNS_STATUS_DATA_ID,        //
        layers: [1, 0, 0],              //layer描述
        status: []                      //DDNS状态, status[0]为NO-IP的状态，status[1]为DynDNS的状态

    };

    this.IPV6_MODE_1_0_0 =
    {
        id: IPV6_MODE_DATA_ID,          //
        layers: [1, 0, 0],              //layer描述
        mode: ""                        //IPv6模式，0为Disable，1为Router，2为Passthrough。
                                        //取值范围:
                                        //IPV6_MODE_DISABLE                       关闭IPv6
                                        //IPV6_MODE_ROUTER                        路由模式
                                        //IPV6_MODE_PASSTHROUGH                   桥接模式

    };

    this.IPV6_WAN_INTERFACE_1_0_0 =
    {
        id: IPV6_WAN_INTERFACE_DATA_ID, //
        layers: [1, 0, 0],              //layer描述
        interfaceType: "",              //IPv6的接口类型，PPPoE接口、以太网口、Tunnel等
        ipGetMethod: ""                 //WAN口IPv6地址获取方式，支持Auto、SLAAC、DHCP和静态

    };

    this.IPV6_WAN_ADDR_1_0_0 =
    {
        id: IPV6_WAN_ADDR_DATA_ID,      //
        layers: [1, 0, 0],              //layer描述
        wanIp: "",                      //WAN口的IPv6全局单播地址
        wanPrefixLen: "",               //WAN口的IPv6全局单播地址前缀长度
        gateway: ""                     //WAN口的IPv6网关

    };

    this.IPV6_WAN_DNS_1_0_0 =
    {
        id: IPV6_WAN_DNS_DATA_ID,       //
        layers: [1, 0, 0],              //layer描述
        dnsGetMethod: "",               //IPv6 DNS地址获取方式
        dns: []                         //IPv6 DNS服务器地址

    };

    this.IPV6_PPPOE_1_0_0 =
    {
        id: IPV6_PPPOE_DATA_ID,         //
        layers: [1, 0, 0],              //layer描述
        shareSession: "",               //是否与IPv4的PPPoE共用Session
        username: "",                   //用户名
        password: ""                    //密码

    };

    this.IPV6_WAN_STATUS_1_0_0 =
    {
        id: IPV6_WAN_STATUS_DATA_ID,    //
        layers: [1, 0, 0],              //layer描述
        status: "",                     //WAN口IPv6状态
        errorCode: "",                  //WAN口IPv6拔号的错误码
        interfaceType: "",              //当前IPv6的WAN口接口类型，用于缓存旧的接口类型，避免WAN_INTERFACE被修改后找不到旧接口
        ipGetMethod: "",                //当前IPv6的WAN口地址获取方式，用于缓存旧接口的地址获取方式，避免WAN_ADDR被修改后找不到旧的地址获取方式
        raReceived: "",                 //是否已经收到过RA
        getIpWithDhcp: "",              //是否通过DHCP获取IPv6地址
        getDnsWithDhcp: "",             //是否通过DHCP获取DNS地址
        globalIp: "",                   //WAN口的IPv6全局单播地址
        prefixAddr: "",                 //WAN口的IPv6前缀
        prefixLen: "",                  //WAN口的IPv6前缀长度
        gateway: "",                    //WAN口默认IPv6网关的本地链路地址
        dns: [],                        //WAN口IPv6 DNS服务器地址
        linkLocalIp: ""                 //WAN口的IPv6本地链路地址

    };

    this.IPV6_PREFIX_DELEGATION_1_0_0 =
    {
        id: IPV6_PREFIX_DELEGATION_DATA_ID,//
        layers: [1, 0, 0],              //layer描述
        enable: ""                      //是否开启Prefix Delegation

    };

    this.IPV6_LAN_PREFIX_1_0_0 =
    {
        id: IPV6_LAN_PREFIX_DATA_ID,    //
        layers: [1, 0, 0],              //layer描述
        prefixAddr: "",                 //LAN侧前缀
        prefixLen: ""                   //LAN侧前缀长度

    };

    this.IPV6_LAN_STATUS_1_0_0 =
    {
        id: IPV6_LAN_STATUS_DATA_ID,    //
        layers: [1, 0, 0],              //layer描述
        linkLocalIp: "",                //LAN口的本地链路地址
        prefixAddr: "",                 //LAN侧前缀
        prefixLen: ""                   //LAN侧前缀长度

    };

    this.MANUFACTURE_MODE_1_0_0 =
    {
        id: MANUFACTURE_MODE_DATA_ID,   //
        layers: [1, 0, 0],              //layer描述
        mode: ""                        //生产模式，每位都为一个生产组件的开关，目前只使用了bit 0，用于tmp server，后续可以添加按钮检查、产测等标记位

    };

    this.LANGUAGE_1_0_0 =
    {
        id: LANGUAGE_DATA_ID,           //
        layers: [1, 0, 0],              //layer描述
        currentLanguage: "",            //当前设置语言
        languageList: "",               //支持语言
        setByUser: ""                   //用户是否设置过语言

    };

    this.REBOOT_SCHE_1_0_0 =
    {
        id: REBOOT_SCHE_DATA_ID,        //定时重启模块配置
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //功能开关
        hour: "",                       //设置生效小时
        minute: "",                     //设置生效分钟
        repeat: "",                     //重复模式：每天：0，每周：1，每月：2
                                        //取值范围:
                                        //REBOOT_SCHE_EVERYDAY                    每天生效
                                        //REBOOT_SCHE_EVERYWEEK                   每周
                                        //REBOOT_SCHE_EVERYMONTH                  每月
        date: ""                        //周（1-7）月（1-28）重复时，指定哪天

    };

    this.LED_SCHE_1_0_0 =
    {
        id: LED_SCHE_DATA_ID,           //LED定时配置
        layers: [1, 0, 0],              //layer描述
        night_enable: "",               //夜间模式功能开关
        start_hour: "",                 //设置关闭LED的小时
        start_minute: "",               //设置关闭LED的分钟
        end_hour: "",                   //设置开启LED的小时
        end_minute: ""                  //设置开启LED的分钟

    };

    this.WLAN_SCHEDULE_1_0_0 =
    {
        id: WLAN_SCHEDULE_DATA_ID,      //host wireless schedule
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //是否启用wireless schedule
        schedule:                       //host wireless schedule
        [{                              //长度为16
            start: "",                  //开始时间（整点时刻）
            end: "",                    //结束时间（整点时刻）
            day: ""                     //时刻表条目生效是星期几（按位记录）
        }]

    };

    this.SMART_CONNECT_1_0_0 =
    {
        id: SMART_CONNECT_DATA_ID,      //无线双频合一功能，配置默认来源于2.4G，操作的配置由2.4G存储
        layers: [1, 0, 0],              //layer描述
        enable: ""                      //是否开启双频合一

    };

    this.PARENT_CTL_V2_1_0_0 =
    {
        id: PARENT_CTL_V2_DATA_ID,      //家长控制模块，用于SPF页面，水星页面不用
        layers: [1, 0, 0],              //layer描述
        ruleList:                       //家长控制模块，用于SPF页面，水星页面不用
        [{                              //长度为4
            rName: "",                  //规则条目的名称
            ruleId: "",                 //规则条目的Id
            block: "",                  //
            enableWorkdayTimeLimit: "", //
            enableWeekendTimeLimit: "", //
            enableWorkdayBedTime: "",   //
            enableWeekendBedTime: "",   //
            workdayDailyTime: "",       //
            weekendDailyTime: "",       //
            workdayBedTimeBegin: "",    //
            workdayBedTimeEnd: "",      //
            weekendBedTimeBegin: "",    //
            weekendBedTimeEnd: "",      //
            website: ""                 //
        }],
        clientList:                     //家长控制模块，用于SPF页面，水星页面不用
        [{                              //长度为32
            cName: "",                  //
            reserved_cName: "",         //补齐clientname
            cOwnerId: "",               //
            cMac: "",                   //
            cType: ""                   //
        }]

    };

    this.QOS_1_0_0 =
    {
        id: QOS_DATA_ID,                //QOS模块，用于SPF页面
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //开启QOS
        upBand: "",                     //上传总带宽(比特)
        downBand: ""                    //下载总带宽(比特)

    };

    this.HW_NAT_1_0_0 =
    {
        id: HW_NAT_DATA_ID,             //硬件NAT开关
        layers: [1, 0, 0],              //layer描述
        enable: ""                      //是否启用硬件加速

    };

    this.ACCESS_CONTROL_SWITCH_1_0_0 =
    {
        id: ACCESS_CONTROL_SWITCH_DATA_ID,//spfUI Access Control switch data model
        layers: [1, 0, 0],              //layer描述
        ctrlEnable: "",                 //enable/disable Access Control, disable by default
        isWhiteList: ""                 //TRUE is white list, FALSE is black list

    };

    this.PORT_TRIGGER_1_0_0 =
    {
        id: PORT_TRIGGER_DATA_ID,       //port trigger数据节点
        layers: [1, 0, 0],              //layer描述
        triggerEnable: "",              //是否启用port trigger功能
        list:                           //port trigger数据节点
        [{                              //长度为16
            serviceName: "",            //条目名
            reserved: "",               //reserved
            triggerPort: "",            //触发端口
            protocol: "",               //触发协议，只支持TCP和UDP。1为TCP，2为UDP，0为ALL
            externalPro: "",            //open port触发协议
            openPort: "",               //开放端口范围
            enable: "",                 //当前trigger条目是否生效
            hasBeenAdd: ""              //是否已添加对应NAT BIND条目
        }]

    };

    this.ETHERNET_INFO_1_0_0 =
    {
        id: ETHERNET_INFO_DATA_ID,      //每个物理接口的状态信息
        layers: [1, 0, 0],              //layer描述
        list:                           //每个物理接口的状态信息
        [{                              //长度为5
            alive: "",                  //物理连接或者未连接
            nameId: "",                 //物理接口的上层抽象使用时的名称编号
                                        //取值范围:
                                        //PHY_INDEX_LAN1                          LAN1口
                                        //PHY_INDEX_LAN2                          LAN2口
                                        //PHY_INDEX_LAN3                          LAN3口
                                        //PHY_INDEX_LAN4                          LAN4口
                                        //PHY_INDEX_WAN                           WAN口
                                        //PHY_INDEX_CPU                           CPU口
            mode: ""                    //物理接口工作模式（数量和单双工）
                                        //取值范围:
                                        //LINK_MODE_AUTO                          自动协商
                                        //LINK_MODE_10MF                          10M全双工
                                        //LINK_MODE_10MH                          10M半双工
                                        //LINK_MODE_100MF                         100M全双工
                                        //LINK_MODE_100MH                         100M半双工
                                        //LINK_MODE_1000MF                        1000M全双工
                                        //LINK_MODE_1000MH                        1000M半双工
                                        //LINK_MODE_END                           结束值，仅做边界检测
        }]

    };

    this.PING_RESPONSE_1_0_0 =
    {
        id: PING_RESPONSE_DATA_ID,      //response ping from LAN/WAN
        layers: [1, 0, 0],              //layer描述
        lanDisable: "",                 //disable ping from LAN
        wanDisable: ""                  //disable ping from WAN

    };

    this.SPI_FIREWALL_1_0_0 =
    {
        id: SPI_FIREWALL_DATA_ID,       //spi firewall开关，默认开启
        layers: [1, 0, 0],              //layer描述
        spiEnable: ""                   //enable spi firewall

    };

    this.LED_CTR_1_0_0 =
    {
        id: LED_CTR_DATA_ID,            //LED控制
        layers: [1, 0, 0],              //layer描述
        enable: ""                      //LED灯状态开关

    };

    this.CLOUD_BASIC_1_0_0 =
    {
        id: CLOUD_BASIC_DATA_ID,        //云基础结构
        layers: [1, 0, 0],              //layer描述
        alias: "",                      //device alias
        legality: "",                   //0 represents legality, 1 represents illegality
        illegalType: "",                //if value of Legality is not zero, this param represents type of illegality.
        tcspStatus: ""                  //status of current firmware version, value can be: TCSP_STATUS_NORMAL = 1,TCSP_STATUS_LOW_VER_NO_UPGRADE = 2,TCSP_STATUS_LOW_VER_CAN_UPGRADE = 3

    };

    this.CLOUD_FW_UPGRADE_1_0_0 =
    {
        id: CLOUD_FW_UPGRADE_DATA_ID,   //云升级结构
        layers: [1, 0, 0],              //layer描述
        type: "",                       //云固件等级；level of released firmware:1 - low level; 2 -middle level;3 high level
        version: "",                    //latest firmware version
        releaseDate: "",                //
        releaseLog: "",                 //log of released firmware
        url: "",                        //download url
        start: "",                      //0 represents that online-upgrade is not started or has ended; 1 represents that online-upgrade is running
        status: "",                     //status of online-upgrade
        progress: "",                   //progress of downloaded firmware
        title: "",                      //title of released firmware
        latestFlag: ""                  //the firmware is latest or not

    };

    this.CLOUD_OWNER_1_0_0 =
    {
        id: CLOUD_OWNER_DATA_ID,        //云账户-OWNER
        layers: [1, 0, 0],              //layer描述
        email: "",                      //
        passwd: "",                     //
        needUnbind: ""                  //The flag to unbind the dut from the owner user, only be set 1 when unbind failed before factory restore.

    };

    this.CLOUD_CURRENT_USER_CFG_1_0_0 =
    {
        id: CLOUD_CURRENT_USER_CFG_DATA_ID,//云账户-CurrUser
        layers: [1, 0, 0],              //layer描述
        nickname: "",                   //
        role: "",                       //The role of the current user: 0 -- owner; 1 -- user; -1 -- not sure, default
        token: "",                      //Used for webpage to get webs from cloud server
        eWebURL: "",                    //Used for webpage to get webs from specified URL
        status: "",                     //The error code from cloud client when act some operation related to cloud account.Set to default 0, when we conduct an action
        isBinded: "",                   //The status of binding:0 -- device has not been bound to a cloud user; 1 -- device has been bound to a cloud user;
        logInCloud: "",                 //The flag indicates if current cloud account has logged on cloud server. TRUE -logged; FALSE - not.
        needReconn: ""                  //The flag indicates if logon triggers reconnection to cloud server when device is offline.

    };

    this.CLOUD_DDNS_1_0_0 =
    {
        id: CLOUD_DDNS_DATA_ID,         //TP-LINK DDNS
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //
        boundDomain: "",                //Domain name bound to current device
        tmpDomainName: "",              //The parameter of the add delete or unbind action, for delete action, more than one domain names can be put here with ; as seperator and end charactor.
        status: "",                     //The action status of the ddns related action,set it to defaut 0 when we start a certain action
        list:                           //TP-LINK DDNS
        [{                              //长度为16
            domainName: "",             //
            regDate: "",                //register date string in the format 2016-03-24
            isBind: ""                  //
        }]

    };

    this.CLOUD_CURRENT_USER_1_0_0 =
    {
        id: CLOUD_CURRENT_USER_DATA_ID, //用来保存当前用户名，密码
        layers: [1, 0, 0],              //layer描述
        curUserName: "",                //The user name of the login user, if this is a cloud account, username should be an email.
        curUserPasswd: ""               //The password of the login user, should be encrypted in DM.

    };

    this.CLOUD_SVR_CONFIG_1_0_0 =
    {
        id: CLOUD_SVR_CONFIG_DATA_ID,   //保存cloud_brd的配置
        layers: [1, 0, 0],              //layer描述
        cloudSefDomain: "",             //SEF 服务器的域名
        cloudSefPort: "",               //SEF 服务器的端口号
        cloudSvrDefaultPort: "",        //服务器的默认端口号
        cloudDefaultSvrDomain: "",      //默认服务器的域名
        cloudDefaultSvrPort: ""         //默认服务器的端口号

    };

    this.ACCESS_CONTROL_WHITE_LIST_1_0_0 =
    {
        id: ACCESS_CONTROL_WHITE_LIST_DATA_ID,//spfUI access control white list data model
        layers: [1, 0, 0],              //layer描述
        whiteList:                      //spfUI access control white list data model
        [{                              //长度为16
            devName: "",                //device name
            reserved: "",               //reserved
            mac: "",                    //device mac address
            devType: ""                 //device type
        }]

    };

    this.ACCESS_CONTROL_BlACK_LIST_1_0_0 =
    {
        id: ACCESS_CONTROL_BlACK_LIST_DATA_ID,//spfUI access control black list data model
        layers: [1, 0, 0],              //layer描述
        blackList:                      //spfUI access control black list data model
        [{                              //长度为16
            devName: "",                //device name
            reserved: "",               //reserved
            mac: "",                    //device mac address
            devType: ""                 //device type
        }]

    };

    this.COMMONERR_1_0_0 =
    {
        id: COMMONERR_DATA_ID,          //设备端错误码
        layers: [1, 0, 0],              //layer描述
        error: ""                       //错误码的枚举值
                                        //取值范围:
                                        //ENONE                                   没有错误 
                                        //ENOMEMORY                               内存不足 
                                        //EINVARG                                 参数错误 
                                        //EINVFMT                                 格式错误 
                                        //EINVEVT                                 不支持的事件 
                                        //EINVCODE                                 
                                        //EFORBID                                 禁止的操作。 
                                        //EUNAUTH                                 认证失败。 
                                        //EOVERFLOW                                
                                        //EINVINSTRUCT                            不支持的指令 
                                        //EMD5                                    MD5校验失败 
                                        //EDESENCODE                              DES加密失败 
                                        //EDESDECODE                              DES解密失败 
                                        //ECHIPID                                 不支持的芯片类型； 
                                        //EFLASHID                                不支持的FLASH类型； 
                                        //EPRODID                                 不支持的产品型号； 
                                        //ELANGID                                 不支持的语言； 
                                        //ESUBVER                                 不支持子版本号； 
                                        //EOEMID                                  不支持的OEM类型； 
                                        //ECOUNTRYID                              不支持的国家； 
                                        //ECODE                                   不支持的操作类型； 
                                        //EWANTYPE                                不支持的WAN口接入类型； 
                                        //ETOOLONG                                数据过长。 
                                        //ESYSTEM                                 系统错误。 
                                        //ENOECHO                                 超时无响应。 
                                        //ENODEVICE                               找不到设备。 
                                        //EINVIP                                  IP地址不正确。 
                                        //EINVMASK                                掩码不正确。 
                                        //EINVGTW                                 网关不正确。 
                                        //EINVIPMASKPAIR                          IP和掩码不匹配。 
                                        //EGTWUNREACH                             网关不可达。 
                                        //EINVMTU                                 MTU错误 
                                        //EINVMACFMT                              MAC地址格式不正确。 
                                        //EENTRYEXIST                             条目已存在。 
                                        //EENTRYNOTEXIST                          条目不存在。 
                                        //EENTRYCONFLIC                           条目冲突。 
                                        //ETABLEFULL                              表满。 
                                        //ETABLEEMPTY                             表空 
                                        //EINVPORT                                超出端口范围
                                        //EPORTRESERVED                           端口冲突
                                        //EINVPTC                                 不支持的协议类型。 
                                        //ECOMFLICTNET                            网段冲突
                                        //EINVNET                                 非法的网段 
                                        //EINVTYPE                                非法的类型。 
                                        //EINVMODE                                非法的模式。 
                                        //EINVTIME                                
                                        //EINVFDNSVR                              非法的首选DNS 
                                        //EINVSDNSVR                              非法的备选DNS 
                                        //EINVDATA                                数据合法性验证失败 
                                        //EINVLEASETIME                           非法的地址租期。 
                                        //EINVADDRPOOL                            非法的地址池。 
                                        //EINVDATE                                非法的日期 
                                        //EINVTIMEZONE                            非法的时区 
                                        //ENOLINK                                 WAN口未链接 
                                        //ESYSBUSY                                系统繁忙。 
                                        //EINVNUM                                 
                                        //EINVSIZE                                
                                        //EINVTIMEOUT                             
                                        //EINVMETRIC                              
                                        //EINVINTERVAL                            时间间隔输入错误 
                                        //EINVBOOL                                布尔类型的取值只能是0或者1 
                                        //EINVSSIDLEN                             无线SSID长度不合法 
                                        //EINVSECAUTH                             无线安全设置的认证类型错误 
                                        //EINVWEPAUTH                             WEP认证类型错误 
                                        //EINVRADIUSAUTH                          RADIUS认证类型错误 
                                        //EINVPSKAUTH                             PSK认证类型错误 
                                        //EINVCIPHER                              加密算法错误 
                                        //EINVRADIUSLEN                           radius密钥短语长度错误 
                                        //EINVPSKLEN                              psk密钥短语错误 
                                        //EINVGKUPINTVAL                          组密钥更新周期错误 
                                        //EINVWEPKEYTYPE                          WEP密钥类型错误 
                                        //EINVWEPKEYIDX                           默认WEP密钥索引错误, 80 
                                        //EINVWEPKEYLEN                           WEP密钥长度错误 
                                        //EINVACLDESCLEN                          MAC地址过滤条目描述信息长度错误 
                                        //EINVWPSPINLEN                           WPS PIN码长度错误 
                                        //EINVAPMODE                              无线设备工作模式错误 
                                        //EINVWLSMODE                             无线速率模式(bgn)错误 
                                        //EINVREGIONIDX                           无线国家码错误 
                                        //EINVCHANWIDTH                           频段带宽错误 
                                        //EINVRTSTHRSHLD                          无线RTS阈值错误 
                                        //EINVFRAGTHRSHLD                         无线分片阈值错误 
                                        //EINVBCNINTVL                            无线beacon间隔错误, 90 
                                        //EINVTXPWR                               无线Tx功率错误 
                                        //EINVDTIMINTVL                           无线DTIM周期错误 
                                        //EINVWDSAUTH                             无线WDS认证类型错误 
                                        //EINVA34DETECT                           3/4地址格式配置错误 
                                        //EINVWLANPWD                             无线密钥包含非法字符 
                                        //EINVHOSTNAMELEN                         非法的主机名长度 
                                        //EINVGETIMEOUT                           非法的访客网络超时时间 
                                        //EINVGETIMEMODE                          非法的访客网络定时模式 
                                        //EINVMACGROUP                            MAC地址为组播地址 
                                        //ENAMEBLANK                              用户名输入为空 
                                        //EPWDBLANK                               密码输入为空 
                                        //EINVMACZERO                             MAC地址为全0 
                                        //EINVMACBROAD                            广播MAC地址 
                                        //EHOSTNAMEEMP                            受控主机名为空 
                                        //EOBJNAMEEMP                             访问目标名为空 
                                        //EPLANNAMEEMP                            日程计划名为空 
                                        //EOBJDOMAINALLEMP                        访问目标域名全为空 
                                        //EREFERED                                条目被关联了 
                                        //EDELPARTIAL                             只删除了部分条目 
                                        //EDELNOTHING                             一个条目都没有删除 
                                        //ERSACHECK                               RSA校验错误 
                                        //EINVLGPWDLEN                            登录密码长度不合法 
                                        //EINLGVALCHAR                            登录密码含有非法字符 
                                        //EINLGVALOLDSAME                         新登录密码和旧登录密码一样 
                                        //EINVNETID                               网络号全0或者1 
                                        //EINVHOSTID                              超出范围 
                                        //EOUTOFRANGE                             RSA校验错误 
                                        //EINDOMAIN                               非法的域名 
                                        //ELACKCFGINFO                            缺少必要的配置信息 
                                        //EINVKEY                                 旧的登录密码错误
                                        //EINVRMTPORT                             远程管理端口超出范围
                                        //EILLEGALPORT                            端口值非法 
                                        //EINVNAMELEN                             用户名长度超出范围 
                                        //EINVPWDLEN                              密码长度超出范围 
                                        //EINVNAME                                用户名非法 
                                        //ENOTLANSUBNET                           不是LAN网段IP 
                                        //EHOSTALLEMPTY                           受控主机IP全为空 
                                        //EOBJALLEMPTY                            访问目标IP和端口全为空 
                                        //EINVGROUPIP                             组播的IP地址 
                                        //EINVLOOPIP                              回环的IP地址 
                                        //EINVIPFMT                               IP地址格式错误 
                                        //ENOTLANWANNET                           网段不是LAN或WAN 
                                        //ELANSUBNET                              LAN网段IP 
                                        //EINVPWD                                 密码非法 
                                        //EIPRESERVED                             IP地址被占用 
                                        //EINVPORTFMT                             端口格式错误 
                                        //EADDRPOOLNOTLANSUBNET                   地址池不在LAN网段 
                                        //ERULECONFLICT                           受控规则冲突 
                                        //EINVTIMETYPE                            非法的时间设置方式 
                                        //EINDATE                                 非法日期 
                                        //EIPMACCONFLIC                           添加的条目与IP&MAC绑定冲突 
                                        //EDHCPRESERVECONFLIC                     添加的条目与DHCP RESERVE冲突 
                                        //EIPDNSCONFLICT                          lan ip与wan dns server冲突 

    };

    this.WDS_STATUS_1_0_0 =
    {
        id: WDS_STATUS_DATA_ID,         //wds连接状态
        layers: [1, 0, 0],              //layer描述
        status: ""                      //wds连接状态枚举
                                        //取值范围:
                                        //STA_STATE_DOWN                          未连接状态 
                                        //STA_STATE_IDLE                          这个状态好像没有用到20190904 
                                        //STA_STATE_SCAN                          扫描状态 
                                        //STA_STATE_AUTH                          认证连接中 
                                        //STA_STATE_ASSOC                         关联中 
                                        //STA_STATE_RUN                           连接完成，aplic接口正在运行 

    };

    this.WEB_COMMAND_1_0_0 =
    {
        id: WEB_COMMAND_DATA_ID,        //web及时命令，我们notify中响应
        layers: [1, 0, 0],              //layer描述
        QsReboot: ""                    //qs使用, 默认为0，被写为1则重启

    };

    this.YANG_DEX_DNS_1_0_0 =
    {
        id: YANG_DEX_DNS_DATA_ID,        
        layers: [1, 0, 0],
        state: "",
        type: "",     
        list:
        [{  
            mac: "",
            mode: "",
            name: ""
        }]                 
    };
    
    this.CWMP_CONFIG_1_0_0 =
    {
        id: CWMP_CONFIG_DATA_ID,        //cwmp的基础配置，web和acs都可以读写
        layers: [1, 0, 0],              //layer描述
        enable: "",                     //cwmp功能的开关
        acsURL: "",                     //访问acs时使用的url
        acsUsername: "",                //访问acs时使用的账号
        acsPassword: "",                //访问acs时使用的密码
        periodicInformEnable: "",       //周期性inform上报开关
        periodicInformInterval: "",     //周期性inform上报间隔，单位s
        periodicInformTime: "",         //周期性inform上报时间点，单位s
        parameterKey: "",               //parameterKey
        interfaceType: "",              //cwmp本地http服务器监听的设备
                                        //取值范围:
                                        //CWMP_BIND_IFACE_WAN                     本地http服务器绑定wan口IP
                                        //CWMP_BIND_IFACE_LAN                     本地http服务器绑定lan侧网关IP
                                        //CWMP_BIND_IFACE_END                     最大限制
        localPort: "",                  //acs访问本地cwmp server时的tcp端口,主机字节序
        resevedForAlign: "",            //内存对齐
        localPath: "",                  //acs访问本地cwmp server时使用的url中path
        localUsername: "",              //acs访问本地cwmp server时使用的账号
        localPassword: "",              //acs访问本地cwmp server时使用的密码
        localAuthType: "",              //cwmp本地http服务器的认证方式
                                        //取值范围:
                                        //CWMP_LOCAL_NO_AUTH                      无认证
                                        //CWMP_LOCAL_BASIC_AUTH                   basic认证
                                        //CWMP_LOCAL_DIGEST_AUTH                  digest认证
        X_TP_Flag: "",                  //X_TP_Flag
        eventCode: "",                  //EventCode
        rbCommandKey: "",               //reboot CommandKey
        reseved1: "",                   //对齐
        siCommandKey: "",               //schedule inform CommandKey
        reseved2: "",                   //对齐
        dlCommandKey: "",               //download CommandKey
        reseved3: "",                   //对齐
        dlStartTime: "",                //dlStartTime
        dlCompleteTime: "",             //dlCompleteTime
        dlFaultCode: "",                //dlFaultCode
        dataModelSpec: "",              //用户指定的数据模型规范，如TR098,TR181
                                        //取值范围:
                                        //CWMP_DATA_MODEL_START                   起始边界检查
                                        //CWMP_DATA_MODEL_TR098                   TR098数据模型:TR-069 InternetGatewayDevice:1.x Root Object definition
                                        //CWMP_DATA_MODEL_TR181                   TR181数据模型:TR-069 Device:2.x Root Object definition
                                        //CWMP_DATA_MODEL_END                     结束边界检查
        dataModelList:                  //cwmp的基础配置，web和acs都可以读写
        [{                              //长度为2
            sepcName: "",               //数据模型规范名称
            isSupport: ""               //是否支持该规范
        }],
        dm:                             //cwmp的基础配置，web和acs都可以读写
        {                               
            ProvisioningCode: ""        //XXX.DeviceInfo.ProvisioningCode-服务供应商信息
        }

    };

    this.MODE_COMMON_1_0_0 =
    {
        id: MODE_COMMON_DATA_ID,        //各个模式之间一些公共的数据，不写入flash，不属于用户配置
        layers: [1, 0, 0],              //layer描述
        lanIp: "",                      //AP和RE模式下lan口的默认IP地址，水星默认为192.168.1.254,tp系列默认为192.168.0.254
        routerLanIp: "",                //router模式下lan口的默认IP地址，水星默认为192.168.1.1,tp系列默认为192.168.0.1
        lanMask: ""                     //出厂的LAN口掩码，默认为255.255.255.0

    };

    this.WEB_SWITCH_1_0_0 =
    {
        id: WEB_SWITCH_DATA_ID,         //用来控制web页面上部分开关的显示，后续有关web页面上开关显示的数据都可以放在这
        layers: [1, 0, 0],              //layer描述
        mumimoSupported2g: "",          //2.4G频段下支持MU-MIMO功能
        mumimoSupported5g: "",          //5G频段下支持MU-MIMO功能
        lanOrderMode: "",               //表示lan口顺序，供IPTV页面显示LAN口图片用
                                        //取值范围:
                                        //LAN_DEFAULT_TYPE                        默认值，兼容不需要图片指示的机型
                                        //LAN_2_DIRECT_LEFT                       有两个lan口，顺序为LAN2-LAN1-WAN
                                        //LAN_2_DIRECT_RIGHT                      有两个lan口，顺序为WAN-LAN1-LAN2
                                        //LAN_3_DIRECT_RIGHT                      有三个lan口，顺序为WAN-LAN1-LAN2-LAN3
                                        //LAN_3_REVERSE_RIGHT                     有三个lan口，顺序为WAN-LAN3-LAN2-LAN1
        ru_Preinstall_ISP: "",          //俄罗斯quick setup阶段预置ISP列表功能
        yandexDNS: "",                  //俄罗斯定制yandex dns功能
        smartDMZ: "",                    //韩国定制smart DMZ功能
        WDS: "",
		igmpSnoop: "",
		igmpProxy: "",
        multiCountryCodeSwitch: "",     //多国家码功能页面开关
        timeFormatType: "",             //时间显示的格式类型
                                        //取值范围:
                                        //YEAR_FIRST_TYPE                         默认值，以YY/MM/DD来显示时间
                                        //DAY_FIRST_TYPE                          以DD/MM/YY来显示时间
        wifiSuppRate2g: "",             //2.4G支持的无线模式列表，以逗号分隔，取值参见uBgnMode，如果为空则使用页面列表11n 11gn 11bgn；需保证当前uBgnMode默认值在此列表中
        wifiSuppRate5g: "",              //5G支持的无线模式列表，以逗号分隔，取值参见uBgnMode，如果为空则使用页面列表11an 11nac 11anac；需保证当前uBgnMode默认值在此列表中
	    mutiLanguageEnable: "",           //
	    rebootTime: "",
        cwmpSupport: "",
        NDProxy: ""
    };
    
    this.ISPPRESET_1_0_0 =
    {
        id: ISPPRESET_DATA_ID,          //保存ISP配置
        layers: [1, 0, 0],              //layer描述
        authKey: "",                    //UI登录密码通配字符串
        reserved: "",                   //只为对齐
        option66Disable: ""             //禁用DUT 处理option66选项的标志

    };

    this.ISP_RUNTIMEDATA_1_0_0 =
    {
        id: ISP_RUNTIMEDATA_DATA_ID,    //保存ISP运行时数据
        layers: [1, 0, 0],              //layer描述
        bIspReset: "",                  //是否重置ISP配置的标志
        wUrlTimes: "",                  //记录下发重置的http url请求总共多少次
        curTicks: ""                    //记录CPU当前时间ticks/60 秒

    };
    this.MULTI_COUNTRY_CODE_1_0_0 =
    {
        id: MULTI_COUNTRY_CODE_DATA_ID, //多国家码功能结构
        layers: [1, 0, 0],              //layer描述
        countryToDomainList:            //多国家码功能结构
        [{                              //长度为32
            countryName: "",            //国家名称
            domainRegion: "",           //国家名称对应的domainRegion,(取值于id=32节点的uRegionIndex属性值)
            channelList2G: "",          //当前国家2.4G下channelList列表，以逗号分开
            channelList5G: ""           //当前国家5G下channelList列表，以逗号分开
        }]
    };
    
    this.IGMP_SNOOPING_1_0_0 =
    {
        id: IGMP_SNOOPING_DATA_ID,      //
        layers: [1, 0, 0],              //layer描述
        enable: "",                      //开启/关闭Snooping功能
	    IgmpProxyEnable: ""             //开启/关闭IGMP_PROXY功能
    };
}

