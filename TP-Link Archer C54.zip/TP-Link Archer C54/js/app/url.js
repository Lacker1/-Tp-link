(function($){
	$.su = $.su || {};

	$.su.url = function(url){
		var noSession = (arguments[1] === false || arguments[2] === false);
		function UrlObj() {}
		UrlObj.prototype.toString =  function(){
				var tag = "";
				var pos = url.indexOf("?");
				
				var reg = new RegExp($.su.url.sessionKey + '=.*(&)?'); 
				if (!$.su.url.session || $.su.url.session.length == 0 || url.match(reg) || noSession)
				{
					//如果session不存在，或者url中已含有sessionkey，则不作任何处理
					return url;
				}

				//否则，给url添加sessionkey。因为url.toString可能会被多次调用，session会更新,不修改原始的url
				var urlNew = '';
				if (pos >= 0)
				{
					if (url.substring(url.length - 1) != "&")
					{
						tag = "&";
					}

					urlNew = url + (tag + $.su.url.sessionKey + "=" + $.su.encodePara($.su.url.session));
				}
				else
				{
					urlNew = url + ("?" + $.su.url.sessionKey + "=" + $.su.encodePara($.su.url.session));
				}

				return urlNew;
			};
		return new UrlObj();
	};

	$.su.ozkerurl = function(url){
		var url = $.su.url.ozkersubs + $.su.url.stok + url;
		return url;
	};

	$.su.url.session= "";
	$.su.url.sessionKey = "id";

})(jQuery);
