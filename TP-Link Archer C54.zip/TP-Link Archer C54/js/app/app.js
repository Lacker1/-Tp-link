(function ($) {
	$.su.App = (function () {

		//tmp code
		var models;
		var hashMap;
		var modules;
		var classesPath;
		$.ajax("./config/models.json?t=ebd0dc2b", {
			async: false,
			method: "GET",
			dataType: "json",
			success: function (data) {
				models = $.extend({}, data);
			}
		});
		$.ajax("./config/modules.json?t=ebd0dc2b", {
			async: false,
			method: "GET",
			dataType: "json",
			success: function (data) {
				modules = data;
			}
		});
		$.ajax($.su.settings.Loader.classesPath, {
			async: false,
			method: "GET",
			dataType: "json",
			success: function (data) {
				classesPath = data;
			}
		});
		$.ajax("./config/src.js?t=ebd0dc2b", {
			async: false,
			method: "GET",
			dataType: "script"
		});
		$.su.settings.navigatorUrl = [];
		$.su.settings.navigatorUrl[SYSTEM_MODE_ROUTER] = "./config/navigator.json?t=ebd0dc2b";
		$.su.settings.navigatorUrl[SYSTEM_MODE_AP] = "./config/navigator.ap.json?t=ebd0dc2b";
		$.su.settings.navigatorUrl[SYSTEM_MODE_RE] = "./config/navigator.re.json?t=ebd0dc2b";
		$.su.settings.navigatorUrl[SYSTEM_MODE_WISP] = "./config/navigator.wisp.json?t=ebd0dc2b";
		var App = function (options) {
			var that = this;

			this.override();

			$.su.Application.call(this);

			this.loader = $.su.loader = new $.su.Loader();
			this.loader.setPath(classesPath);
			this.classManager = $.su.ClassManager.getInstance();
			this.classManager.setLoader(this.loader);

			// $.su.AjaxProxy.setup(proxySettings);

			new $.su.Services.Ajax({
				ajax: {
					contentType: "text/plain;charset=UTF-8",
					type: "POST"
				},
				failHandler: function (failCallback) {
					return function (result, data, errorCode, status, xhr) {
						// var msg = $.su.SMB_CHAR.ERRCODE[errorCode];
						// that.moduleManager.get('index').showError(msg);
						!!failCallback && failCallback(result, data, errorCode, status, xhr);
					};
				},
				errorHandler: function (errorCallback) {
					return function (status, xhr) {
						// var msg = $.su[$.app.language.settings.char].ALERT.FAIL_GET_DATA;
						// that.moduleManager.get('index').showError(msg);
						!!errorCallback && errorCallback(status, xhr);
					};
				}
			});
			new $.su.Services.Vtype();
			new $.su.Services.Polling();
			new $.su.Services.ModuleManager();
			this.device = new $.su.Services.Device({
				service: {
					ajax: that.serviceManager.get('ajax'),
					loading: that.serviceManager.get('loading')
				}
			});
			new $.su.Services.Time({
				service: {
					ajax: that.serviceManager.get('ajax')
				}
			});
			new $.su.Services.Timer();
			this.moduleLoader = new $.su.Services.ModuleLoader();


			// this.customWidget();
			$.su.ModuleRouter = new $.su.Services.ModuleRouter({
				hashMap: []
			});
			this.language = new $.su.Services.LanguageService();

			this.router = $.su.router = new $.su.Router();
			this.router.setModelsPath(models);
			this.router.set(modules);

		};

		$.su.inherit($.su.Application, App);

		App.prototype.init = function () {
			var dtd = $.Deferred();
			var me = this;
			var promiseArr = [];

			var mobileFilePromise = $.Deferred();
			promiseArr.push(mobileFilePromise);
			if ($.su.isMobile()) {
				// load widget.mobile.js
				$.su.loader.loadFile('./js/su/widget/widget.mobile.js', function () {
					mobileFilePromise.resolve();
				});
			} else {
				mobileFilePromise.resolve();
			}

			// var loaderPathFetchPromise = $.Deferred();
			// promiseArr.push(loaderPathFetchPromise);
			// var path = $.su.settings.Loader.classesPath;
			// this.loader.loadFile(path, function(data){
			// 	debugger
			// 	me.loader.setPath(data);
			// 	loaderPathFetchPromise.resolve();
			// });

			$.when.apply(this, promiseArr).done(function () {
				dtd.resolve();
			});

			return dtd.promise();
		};

		App.prototype.customWidget = function () {
			// 覆盖默认控件方法
			var overRide = {
				errortip: {
					animate: function (tips) {
						var _this = this.dom();
						var wrap = _this.find("div.widget-error-tips-wrap");
						var content = _this.find("div.error-tips-content");
						var loaderContainer = _this.closest('.html-loader-container');
						var msgContainer = _this.closest('.msg-content-wrap');
						var container = loaderContainer.length > 0 ? loaderContainer : (msgContainer.length > 0 ? msgContainer : $('#index-view-container'));
						var containerOffset = container.offset();
						var containerWidth = container.width();

						if ($.type(tips) === "string") {
							content.text(tips);
						}

						_this.addClass('show').show();

						// 计算位置
						var offset = wrap.offset();
						var width = wrap.width();

						if (offset.left - containerOffset.left + width > containerWidth) {
							wrap.css({
								"right": 0
							});
						}
					}
				}

			};

			for (var widget in overRide) {
				if (overRide.hasOwnProperty(widget)) {
					for (var method in overRide[widget]) {
						if (overRide[widget].hasOwnProperty(method)) {
							if ($.fn[widget]) {
								$.fn[widget][method] = overRide[widget][method];
							}
						}
					}
				}
			}
		};

		App.prototype.override = function () {
			/*兼容IE8 数组array的indexOf方法*/
			if (!Array.prototype.indexOf) {
				Array.prototype.indexOf = function (elt /*, from*/) {
					var len = this.length >>> 0;
					var from = Number(arguments[1]) || 0;
					from = (from < 0) ? Math.ceil(from) : Math.floor(from);
					if (from < 0)
						from += len;
					for (; from < len; from++) {
						if (from in this &&
							this[from] === elt)
							return from;
					}
					return -1;
				};
			}

			// $.su.Model.prototype.beforeLoad = function(option){
			// 	var me = this;
			// 	option = option || {};
			// 	// !!this.read && this.read(option);
			// 	if (!(option && option.ajax && option.ajax.type)){
			// 		option = option || {};
			// 		option.data = $.extend({}, {operation: "read"}, option.data);
			// 		option.ajax = option.ajax || {};
			// 		option.ajax.type = 'POST';
			// 		option.ajax.contentType = 'application/x-www-form-urlencoded';
			// 		!!option.url && (option.ajax.url = option.url);
			// 	}
			// 	option.params = option.params || {};
			// 	var failFn = option.fail;
			// 	option.fail = function(keyData, rawData, errorCode){
			// 		!!failFn && failFn(keyData, rawData, errorCode);
			// 		if(errorCode){
			// 			me.trigger("ev_model_load_error", errorCode);
			// 		}
			// 	};
			// 	var errorFn = option.error;
			// 	option.error = function(status, xhr){
			// 		!!errorFn && errorFn(status, xhr);
			// 		me.trigger("ev_model_ajax_error", [status, xhr]);
			// 	};
			// 	return option;
			// };

			// $.su.Model.prototype.beforeSubmit = function(data, option){
			// 	var model = this;
			//
			// 	return {
			// 		ajax: {
			// 			url: option.url || undefined,
			// 			contentType: "application/x-www-form-urlencoded"
			// 		},
			// 		data: $.extend({}, model.modelSerialize(data), {operation: "write"}, option.data),
			// 		params: option.params || {},
			// 		success: function(keyData, rawData){
			// 			if(keyData.model && rawData.data){
			// 				model.loadData(keyData.model, true);
			// 				model.record();
			// 			}
			// 			!!option.success && option.success(keyData.model, rawData);
			// 			model.fireEvent('ev_model_submit');
			// 		},
			// 		fail: function(keyData, rawData, errorCode){
			// 			if(keyData.model && rawData.data){
			// 				model.loadData(keyData.model, true);
			// 				model.record();
			// 			}
			// 			if(errorCode){
			// 				model.trigger("ev_model_submit_error", errorCode);
			// 			}
			//
			// 			!!option.fail && option.fail(rawData, errorCode);
			// 		},
			// 		error: function(status, xhr){
			// 			!!option.error && option.error(status, xhr);
			// 			model.trigger("ev_model_ajax_error", [status, xhr]);
			// 		}
			// 	};
			// };

			// $.su.Store.prototype.beforeInsert = function(storeData, items, option){
			// 	option = option || {};
			// 	var me = this;
			// 	var sendData = {};
			//
			// 	//single operation
			// 	var singleItemDealed = false;
			// 	for(var key in items){
			// 		if(items.hasOwnProperty(key)){
			// 			//key may be int type, 'key' property name is not reliable.
			// 			if(!singleItemDealed){
			// 				sendData.key = "add";
			// 				sendData["new"] = JSON.stringify(items[key].model);
			// 				sendData.old = "add";
			// 				sendData.index = 0;
			// 				singleItemDealed = true;
			// 			}else{
			// 				return
			// 			}
			// 		}
			// 	}
			//
			// 	return {
			// 		ajax: $.extend({}, {
			// 			url: option.url || undefined,
			// 			type: "POST",
			// 			contentType: 'application/x-www-form-urlencoded',
			// 			traditional: true
			// 		}, option.ajax),
			// 		data: $.extend({}, sendData, {operation: "insert"}, option.data),
			// 		success: function(result){
			// 			// me.loadData(result.model, true);
			// 			!!option.success && option.success(result);
			// 			me.fireEvent('ev_store_operation');
			// 			me.load();
			// 		},
			// 		fail: function(keyData, rawData, errorCode){
			// 			me.loadData(me.snapshot);
			// 			!!option.fail && option.fail(rawData, errorCode);
			// 			if(errorCode){
			// 				me.trigger("ev_store_sync_error", errorCode);
			// 			}
			// 		},
			// 		error: function(status, xhr){
			// 			me.loadData(me.snapshot);
			// 			!!option.error && option.error(status, xhr);
			// 			me.trigger("ev_store_ajax_error", [status, xhr]);
			// 		}
			// 	};
			// };

			// $.su.Store.prototype.beforeLoad = function(option){
			// 	var me = this;
			// 	if (!(option && option.ajax && option.ajax.type)){
			// 		option = option || {};
			// 		option.ajax = option.ajax || {};
			// 		option.ajax.type = 'POST';
			// 		option.ajax.contentType = 'application/x-www-form-urlencoded';
			// 	}
			// 	option.data = $.extend({}, {operation: "load"}, option.data);
			// 	var failFn = option.fail;
			// 	option.fail = function(keyData, rawData, errorCode){
			// 		!!failFn && failFn(keyData, rawData, errorCode);
			// 		if(errorCode){
			// 			me.trigger("ev_store_sync_error", errorCode);
			// 		}
			// 	};
			// 	var errorFn = option.error;
			// 	option.error = function(status, xhr){
			// 		!!errorFn && errorFn(status, xhr);
			// 		me.trigger("ev_store_ajax_error", [status, xhr]);
			// 	};
			// 	return option;
			// };
			//
			// $.su.Store.prototype.beforeUpdate = function(storeData, items, option){
			// 	option = option || {};
			// 	var me = this;
			// 	var sendData = {};
			// 	var keyProperty = this.keyProperty;
			//
			// 	//single operation
			// 	var singleItemDealed = false;
			// 	for(var key in items){
			// 		if(items.hasOwnProperty(key)){
			// 			//key may be int type, 'key' property name is not reliable.
			// 			if(!singleItemDealed){
			// 				sendData.key = items[key].oldModel[keyProperty];
			// 				sendData["new"] = JSON.stringify(items[key].model);
			// 				sendData.old = JSON.stringify(items[key].oldModel);
			// 				singleItemDealed = true;
			// 			}else{
			// 				return
			// 			}
			// 		}
			// 	}
			//
			// 	return {
			// 		ajax: $.extend({}, {
			// 			url: option.url || undefined,
			// 			type: "POST",
			// 			contentType: 'application/x-www-form-urlencoded',
			// 			traditional: true
			// 		}, option.ajax),
			// 		data: $.extend({}, sendData, {operation: "update"}, option.data),
			// 		success: function(result){
			// 			// me.loadData(result.model, true);
			// 			!!option.success && option.success(result);
			// 			me.fireEvent('ev_store_operation');
			// 			me.load();
			// 		},
			// 		fail: function(keyData, rawData, errorCode){
			// 			me.loadData(me.snapshot);
			// 			!!option.fail && option.fail(rawData, errorCode);
			// 			if(errorCode){
			// 				me.trigger("ev_store_sync_error", errorCode);
			// 			}
			// 		},
			// 		error: function(status, xhr){
			// 			me.loadData(me.snapshot);
			// 			!!option.error && option.error(status, xhr);
			// 			me.trigger("ev_store_ajax_error", [status, xhr]);
			// 		}
			// 	};
			// };

			// $.su.Store.prototype.getIndexsInSnapshot = function(keyArray){	//根据keyArray返回index的array
			// 	var data = this.snapshot;
			// 	var keyProperty = this.keyProperty;
			//
			// 	if(keyArray.length === 0){
			// 		return undefined;
			// 	}
			//
			// 	var indexArray = [];
			// 	for(var jndex = 0, jlen = keyArray.length; jndex < jlen; jndex++){
			// 		for(var index = 0, len = data.length; index < len; index++){
			// 			var key = keyArray[jndex];
			// 			if(data[index][keyProperty] == key.toString()){
			// 				indexArray.push(index);
			// 				break;
			// 			}
			// 		}
			// 	}
			// 	return indexArray;
			// };

			// $.su.Store.prototype.beforeRemove = function(storeData, items, option){
			// 	var keyProperty = this.keyProperty;
			// 	option = option || {};
			// 	var me = this;
			// 	var sendData = {
			// 		"key": [],
			// 		"index": []
			// 	};
			//
			// 	for(var key in items){
			// 		if(items.hasOwnProperty(key)){
			// 			//key may be int type, 'key' property name is not reliable.
			// 			sendData.key.push(items[key].oldModel[keyProperty]);
			// 		}
			// 	}
			// 	sendData.index = this.getIndexsInSnapshot(sendData.key);
			//
			// 	return {
			// 		ajax: $.extend({}, {
			// 			url: option.url || undefined,
			// 			type: "POST",
			// 			contentType: 'application/x-www-form-urlencoded',
			// 			traditional: true
			// 		}, option.ajax),
			// 		data: $.extend({}, sendData, {operation: "remove"}, option.data),
			// 		success: function(result, data){
			// 			// me.loadData(result.model, true);
			// 			!!option.success && option.success(result);
			// 			me.fireEvent('ev_store_operation');
			// 			me.load();
			// 		},
			// 		fail: function(keyData, rawData, errorCode){
			// 			me.loadData(me.snapshot);
			// 			!!option.fail && option.fail(rawData, errorCode);
			// 			if(errorCode){
			// 				me.trigger("ev_store_sync_error", errorCode);
			// 			}
			// 		},
			// 		error: function(status, xhr){
			// 			me.loadData(me.snapshot);
			// 			!!option.error && option.error(status, xhr);
			// 			me.trigger("ev_store_ajax_error", [status, xhr]);
			// 		}
			// 	};
			// };
			$.su.Error.handle = function (err) {
				this.errorTolerance = this.errorTolerance || {};
				
				if (err.tolerance && typeof err.tolerance == 'number') {
					var me = this;
					var cleanupTime = err.cleanupTime || 10 * 1000;
					//获取累计次数
					this.errorTolerance[err.type] = this.errorTolerance[err.type] || 0;
					
					//设置定时器清零次数
					clearTimeout(this.errorTolerance[err.type+'timer']);
					this.errorTolerance[err.type+'timer'] = setTimeout(function() {
						me.errorTolerance[err.type] = 0;
					}, cleanupTime);
					
					if (++this.errorTolerance[err.type] > err.tolerance) {
						//次数清零，处理错误
						clearTimeout(this.errorTolerance[err.type+'timer']);
						this.errorTolerance[err.type] = 0;
					} else {
						console.warn(err);
						return true;
					}
				}
				switch (err.type) {
					case "module_not_found":
					case "module_not_defined":
						if (console && console.log) {
							console.log("navigator error", err.module);
						}
						return true;
					case "model_ajax_error":
					case "store_ajax_error":
					case "ajax_error":
						err.errorCode = "ajax_error";
						return;
					default:
						var code = err.errorCode;
						var data = err.data;
						var showStr = $.appUtils.errorToText(code, data);

						
						if ($.su.moduleManager.query("main")) {
							var mainModule = $.su.moduleManager.query("main");
							if (showStr == "ev_logout") {
								mainModule.logout && mainModule.logout();
							} else {
								mainModule.showError && mainModule.showError(showStr);
							}
							
						}
						return true;
				}


			};

			$.su.Model.combineSubmit = function (models) {
				if (!$.isArray(models)) {
					models = [models];
				}
				var dfd = $.Deferred();
				var getKey = function (block) {
					var blockId = block.id;
					var layers = (block.layers || [1, 0, 0]).join(",");
					return blockId + "|" + layers;
				};
				var combineData = {};
				// var combineData = [];
				var proxy = null;
				$.each(models, function (i, model) {
					if (!(model instanceof $.su.Model) && !(model instanceof $.su.ModelBind)) {
						return;
					}
					var data = model.modelSerialize(model.getData('submit'));
					if ($.isArray(data)) {
						$.each(data, function (i, block) {
							block = model.getProxy().addDataId(block);
							combineData[getKey(block)] = block;
						});
						return;
					}
					// single blocks
					proxy = model.getProxy();
					var blocks = proxy.blocks;
					blocks = ($.isArray(blocks) ? blocks[0] : blocks).toString().split("|");
					data.id = blocks[0];
					data.layers = blocks[1] && blocks[1].split(",");
					data = proxy.addDataId(data);
					combineData[getKey(data)] = data;
				});

				var toSend = [];
				$.each(combineData, function (key, data) {
					toSend.push(data);
				});
				if (proxy !== null) {
					proxy.write({
						data: toSend,
						success: dfd.resolve,
						fail: dfd.reject,
						error: dfd.reject
					});
				} else {
					dfd.resolve();
				}
				return dfd.promise();
			};
		};

		App.prototype.reset = function () {
		};

		App.prototype.reload = function () {
		};

		App.prototype.getInfo = function () {
		};

		return App;
	})();

	$.appUtils = $.su.App.utils = {
		/***容量单位数值转换***/
		numToCapacity: function (value, dig) {
			var result = value,
				dig = dig || 3;
			if (value >= 1000 * 1000 * 1000 * 1000 * 1000) {
				result = (result / (1000 * 1000 * 1000 * 1000 * 1000)).toFixed(dig) + $.su.CHAR.UNIT.PB;
			}
			else if (value >= 1000 * 1000 * 1000 * 1000) {
				result = (result / (1000 * 1000 * 1000 * 1000)).toFixed(dig) + $.su.CHAR.UNIT.TB;
			}
			else if (value >= 1000 * 1000 * 1000) {
				result = (result / (1000 * 1000 * 1000)).toFixed(dig) + $.su.CHAR.UNIT.GB;
			}
			else if (value >= 1000 * 1000) {
				result = (result / (1000 * 1000)).toFixed(dig) + $.su.CHAR.UNIT.MB;
			}
			else if (value >= 1000) {
				result = (result / (1000)).toFixed(dig) + $.su.CHAR.UNIT.KB;
			}
			return result;
		},
		capacityToNum: function (str) {
			var str = str.replace("&nbsp;", "").replace(" ", "");
			var PB = $.su.CHAR.UNIT.PB;
			var TB = $.su.CHAR.UNIT.TB;
			var GB = $.su.CHAR.UNIT.GB;
			var MB = $.su.CHAR.UNIT.MB;
			var KB = $.su.CHAR.UNIT.KB;
			var B = $.su.CHAR.UNIT.B;
			if (str.indexOf(PB) > -1) {
				return str.split(PB)[0] * 1000 * 1000 * 1000 * 1000;
			}
			if (str.indexOf(TB) > -1) {
				return str.split(TB)[0] * 1000 * 1000 * 1000 * 1000;
			}
			if (str.indexOf(GB) > -1) {
				return str.split(GB)[0] * 1000 * 1000 * 1000;
			}
			if (str.indexOf(MB) > -1) {
				return str.split(MB)[0] * 1000 * 1000;
			}
			if (str.indexOf(KB) > -1) {
				return str.split(KB)[0] * 1000;
			}
			if (str.indexOf(B) > -1) {
				return str.split(KB)[0];
			}
		},
		ipToInt: function (str_ip) {
			if (!str_ip) {
				return;
			}
			var patternIp = /^\s*[0-9]{1,3}\.{1}[0-9]{1,3}\.{1}[0-9]{1,3}\.{1}[0-9]{1,3}\s*$/;
			var ip_array = str_ip.split(".");
			if (ip_array.length != 4) {
				return -1;
			}
			if (!patternIp.test(str_ip)) {
				return -1;
			}
			return (Number(ip_array[0]) * (1 << 24) + (Number(ip_array[1]) << 16 | Number(ip_array[2]) << 8 | Number(ip_array[3])));
		},
		isSameNet: function (ip1, ip2, mask) {
			if (ip1 == "") {
				return false;
			};

			var ipToInt = $.appUtils.ipToInt;
			var intIp1 = ipToInt(ip1);
			var intIp2 = ipToInt(ip2);
			var intMask = ipToInt(mask);

			if (intMask == 0) {
				return false;
			}

			if ((intIp1 & intMask) != (intIp2 & intMask)) {
				return false;
			}
			return true;
		},
		getLimitIp: function (lanIP, lanMask, type) {
			var ipArr = lanIP.split(".");
			var maskArr = lanMask.split(".");
			var ipLen = ipArr.length;
			var maskLen = maskArr.length;
			var returnArr = [];
			for (var i = 0; i < ipLen; ++i) {
				if (type == 'min') {
					returnArr.push(ipArr[i] & maskArr[i]);
				}
				else {
					var value = parseInt(maskArr[i]);
					if (value < 128) {
						returnArr.push(ipArr[i] | (((~value - 128) << 24 >> 24) + 128));
					}
					else {
						returnArr.push(ipArr[i] | (~value << 24 >> 24));
					}
				}
			}
			return returnArr.join(".");
		},
		intToArray: function (num, length) {
			num = parseInt(num);
			var result = [];
			while (num > 0) {
				result.push(num % 2);
				num = parseInt(num / 2);
			}
			if (result.length < length) {
				var len = result.length;
				for (var i = 0; i < (length - len); i++) {
					result.push(0);
				}
			}
			return result;
		},
		arrayToInt: function (array) {
			var result = 0;
			var base = 1;
			while (array.length > 0) {
				result += (array.shift() || 0) * base;
				base = base * 2;
			}
			return result;
		},
		objectToArray: function (obj) {
			var array = [];
			for (var i in obj) {
				array[i] = obj[i];
			}
			return array;
		},
		resetPortsValue: function (origin, target) {
			var val1 = $.appUtils.portSplit(origin).split(",");
			var val2 = $.appUtils.portSplit(target).split(",");
			/*-------------------------------*/

			for (var i = 0; i < val1.length; i++) {
				var index = val2.indexOf(val1[i]);
				if (index >= 0) {
					val2.splice(index, 1);
				}
			}
			return $.appUtils.portCombine(val2.join(","));
		},
		keyHandler: function (key) {
			return (key).toString().replace(/[\/\.\:\s\(\)]/g, '_');
		},
		doLayout: function () {
			var h1 = $('#scroll-layer').height() - $('.bot').height();
			$("#main-con").css({
				minHeight: h1
			});
		},
		errorToText: function (code, data) {
			var errStr = $.su.CHAR.errStr;
			var showStr;
			var main = $.su.moduleManager.query("main");
			if (main) {
				//处理特殊页面的特殊错误码
				var currentPage = $.su.ModuleRouter.getCurrentPage();
				switch (currentPage) {
					//特殊模块
					case "IPMACBinding":
						switch (code) {
							case EENTRYCONFLIC:
								showStr = $.su.CHAR.IP_MAC_BINDING.CONFLICT_WITH_RESERVATION;
								break;
						}
						break;
					case "dhcpServerAdv":
						switch (code) {
							case EENTRYCONFLIC:
								showStr = $.su.CHAR.IP_MAC_BINDING.CONFLICT_WITH_IP_MAC;
								break;
						}
						break;
					case "portForwarding":
						switch (code) {
							case EPORTRESERVED:
								showStr = $.su.CHAR.PORT_FORWARDING.CONFLICT_WITH_EXISTING_PORT;
								showStr = showStr.replace("%num%", $.trim(data));
								break;
						}
						break;
					case "portTriggering":
						switch (code) {
							case EPORTRESERVED:
								showStr = $.su.CHAR.PORT_TRIGGERING.CONFLICT_WITH_EXISTING_PORT;
								showStr = showStr.replace("%num%", $.trim(data));
								break;
						}
						break;
					case "administration":
						switch (code) {
							case EPORTRESERVED:
								showStr = $.su.CHAR.errStr.remotePortConflict;
								break;
						}
						break;
				}
			}

			if (!showStr) {
				switch (code) {
					case EFORBID:
						showStr = errStr.prohibit;
						break;
					case EINVARG:
						showStr = errStr.acIncompleteArg;
						break;
					case EOVERFLOW:
						showStr = errStr.invPortErr;
						break;
					case EINVINSTRUCT:
						showStr = errStr.instructErr;
						break;
					case ESYSTEM:
						showStr = errStr.systemErr;
						break;
					case EINVIP:
						showStr = errStr.ipAddrErr;
						break;
					case EINVMASK:
						showStr = errStr.maskErr;
						break;
					case EINVGTW:
						showStr = errStr.gatewayErr;
						break;
					case EINVIPMASKPAIR:
						showStr = errStr.ipAddrMaskNotMatch;
						break;
					case EGTWUNREACH:
						showStr = errStr.gatewayUnreachErr;
						break;
					case EINVMTU:
						showStr = errStr.pppoeMtuErr;
						break;
					case EINVMACFMT:
						showStr = errStr.macFmtErr;
						break;
					case EENTRYEXIST:
						showStr = errStr.entryExistErr;
						break;
					case EENTRYNOTEXIST:
						showStr = errStr.entryNoExistErr;
						break;
					case EENTRYCONFLIC:
						showStr = errStr.entryConflicErr;
						break;
					case ETABLEFULL:
						showStr = errStr.tableFullErr;
						break;
					case ETABLEEMPTY:
						showStr = errStr.tableEmptyErr;
						break;
					case EINVPORT:
						showStr = errStr.localPortErr;
						break;
					case EPORTRESERVED:
						showStr = errStr.portConflicErr;
						break;
					case EINVPTC:
						showStr = errStr.invProtoErr;
						break;
					case ECOMFLICTNET:
						showStr = errStr.ipAddrLanWanConflict;
						break;
					case EINVNET:
						showStr = errStr.ipAddrNetErr;
						break;
					case EINVTIME:
						showStr = errStr.pppoeOffTimeErr;
						break;
					case EINVFDNSVR:
						showStr = errStr.primDnsErr;
						break;
					case EINVSDNSVR:
						showStr = errStr.seDnsErr;
						break;
					case EINVLEASETIME:
						showStr = errStr.dhcpsLeaseErr;
						break;
					case EINVADDRPOOL:
						showStr = errStr.dhcpsAddrPoolErr;
						break;
					case ENOLINK:
						showStr = errStr.wanLinkDown;
						break;
					case EINVSSIDLEN:
						showStr = errStr.wlanSsidLenErr;
						break;
					case EINVPSKAUTH:
						showStr = errStr.wlanSecNotSupport;
						break;
					case EINVRADIUSLEN: /* Radius Password */
						showStr = errStr.wlanPwdLenValid;
						break;
					case EINVPSKLEN:
						showStr = errStr.wlanPwdLenValid;
						break;
					case EINVWEPKEYLEN: /* wep password */
						showStr = errStr.wlanWepPwdLenValid;
						break;
					case EINVWLANPWD:
						showStr = errStr.wlanPwdInvalid;
						break;
					case EINVGETIMEOUT:
						showStr = errStr.guestNetSpeedInvalid;  //TODO:该文案与后台错误码不对应
						break;
					case EINVGETIMEMODE:
						showStr = errStr.guestNetTimeoutInvalid;//TODO:该文案与后台错误码不对应
						break;
					case EINVMACGROUP:
						showStr = errStr.macGroupErr;
						break;
					case EPWDBLANK:
						showStr = errStr.wlanPwdNull;
						break;
					case EINVMACZERO:
						showStr = errStr.macZeroErr;
						break;
					case EINVMACBROAD:
						showStr = errStr.macBroadErr;
						break;
					case EHOSTNAMEEMP:
						showStr = errStr.hostNameEmpty;
						break;
					case EOBJNAMEEMP:
						showStr = errStr.objNameEmpty;
						break;
					case EPLANNAMEEMP:
						showStr = errStr.planNameEmpty;
						break;
					case EOBJDOMAINALLEMP:
						showStr = errStr.objDomainAllEmpErr;
						break;
					case EREFERED:
						showStr = errStr.acRefered;
						break;
					case EINVLGPWDLEN:
						showStr = errStr.lgPwdLenInvalid;
						break;
					case EINLGVALCHAR:
						showStr = errStr.pwdCharValid;
						break;
					case EINLGVALOLDSAME:
						showStr = errStr.pswNewOldSameErr;
						break;
					case EINVNETID:
						showStr = errStr.ipAddrNetIdErr;
						break;
					case EINVHOSTID:
						showStr = errStr.ipAddrHostIdErr;
						break;
					case EOUTOFRANGE:
						showStr = errStr.dhcpcHostNameErr;
						break;
					case EINDOMAIN:
						showStr = errStr.domainErr;
						break;
					case EINVKEY:
						showStr = errStr.pwdOldPwdErr;
						break;
					case EINVRMTPORT:
						showStr = errStr.remotePortErr;
						break;
					case EILLEGALPORT:
						showStr = errStr.portIllegalErr;
						break;

					case ENOTLANSUBNET:
						showStr = errStr.ipNotLanSubnet;
						break;
					case EHOSTALLEMPTY:
						showStr = errStr.acHostAllEmpty;
						break;
					case EOBJALLEMPTY:
						showStr = errStr.acObjAllEmpty;
						break;
					case EINVGROUPIP:
						errNote = errStr.ipAddrGroupErr;
						break;
					case EINVLOOPIP:
						showStr = errStr.ipAddrLoopErr;
						break;
					case EINVIPFMT:
						showStr = errStr.ipAddrFmtErr;
						break;
					case ENOTLANWANNET:
						showStr = errStr.ipAddrNotLanWanNetErr;
						break;
					case ELANSUBNET:
						showStr = errStr.ipLanSubnet;
						break;
					case EIPRESERVED:
						showStr = errStr.ipAddrReservedErr;
						break;
					case EINVPORTFMT:
						showStr = errStr.portIllegalFmtErr;
						break;
					case EADDRPOOLNOTLANSUBNET:
						showStr = errStr.dhcpsAddrPoolNetErr;
						break;
					case ERULECONFLICT:
						showStr = errStr.acruleConflict;
						break;
					// case EINVRMTPORTFMT:
					// 	showStr = errStr.remotePortNotNum;
					// 	break;
					// case EINVMACNULL:
					// 	showStr = errStr.macNullErr;
					// 	break;
					case EIPMACCONFLIC:
						showStr = $.su.CHAR.NETWORK_DHCP.CONFLICT_WITH_IP_MAC;
						break;
					case EDHCPRESERVECONFLIC:
						showStr = $.su.CHAR.IP_MAC_BINDING.CONFLICT_WITH_RESERVATION;
						break;
					case EIPDNSCONFLICT:
						showStr = errStr.ipAddrLanDnsConflictShortNote;
						break;
					case EINVTIMETYPE:
						showStr = EINVTIMETYPE; //TODO no error text
						break;
					case EINDATE:
						showStr = EINDATE;//TODO no error text
						break;

					

					case "ajax_error":
						showStr = $.su.CHAR.errStr.noRespond;
						break;
					case EUNAUTH:
						showStr = "ev_logout";
						break;
					default:
						showStr = errStr.unknown + code;
						break;
				}
			}

			return showStr;
		},
		isSameMac: function (mac1, mac2) {
			return typeof mac1 === "string" && typeof mac2 === "string" && $.trim(mac1.toLowerCase()) === $.trim(mac2.toLowerCase());
		},
		
		signalLevel: function (rssi) {
            // rssi 转换为信号强度，这是一个阶梯公式，采用的折半比较，以便减少比较次数
            if (rssi >= 20) {
            if (rssi >= 30) {
            if (rssi >= 50) {
                return 5; // rssi∈[50, 100)
            } else {
                return 4; // rssi∈[30, 50)
            }
            } else {
                return 3; // rssi∈[20, 30)
            }
            } else {
                if (rssi >= 10) {
                    return 2; // rssi∈[10, 20)
                } else {
                    return 1; // rssi∈[0, 10)
                }
            }
        }
	};

})(jQuery);
