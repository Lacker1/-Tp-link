/**
 * Created by admin on 2018/6/19.
 */
var SYN = 0;
var ASYN = 1;
var TDDP_INSTRUCT = 0;
var TDDP_WRITE = 1;		/* 更新数据，对应于以前的SET命令； */
var TDDP_READ = 2;		/* 读取数据，对应于以前的GET命令； */
var TDDP_UPLOAD = 3;	/* 更新软件，由于在TDDPV3中，命令放到了数据中，因此"特殊子命令"字段可以去掉； */
var TDDP_DOWNLOAD = 4;	/* 备份软件配置。TDDPV2及其以前的意义将被覆盖。 */
var TDDP_RESET =5;		/* 恢复初始设置； */
var TDDP_REBOOT = 6;	/* 重启设备； */
var TDDP_AUTH = 7;		/* 认证 */
var TDDP_GETPEERMAC = 8;	/* 获取主机信息 */
var TDDP_CONFIG = 9;	/* 载入用户配置数据 */
var TDDP_CHGPWD = 10;	/* 修改密码 */
var TDDP_LOGOUT = 11;	/* 登出 */
var TDDP_WRITEOEM = 12;	/**/
var TDDP_CHGMODE = 13;	/* 变更模式 */
var HTTP_OP_CLOUD_RESET = 14;	/* restore */
var HTTP_OP_CLOUD_LOGIN = 15;	/* 云登录 */
var HTTP_OP_GDPRCFG = 16;	/* gdpr */
var CLOUD_TMP = 17; /* 云登录获取 tmp key */
var CLOUD_AUTH = 18; /* 获取 token */
var HTTP_OP_AUTHKEY = 19; /* 传入RSA加密后的信息 */

var LINK_DOWN = 0;
var LINK_UP = 1;
var LINKING_UP = 2;
var LINKING_DOWN = 3;
var IPV6_INTERFACE_LINKING_UP = 4;
var IPV6_INTERFACE_LINK_UP = 5;
var IPV6_INTERFACE_LINKING_DOWN = 6;
var IPV6_INTERFACE_LINK_DOWN = 7;
var IPV6_ADDRESS_LINKING_UP = 8;
var IPV6_ADDRESS_LINK_UP = 9;
var IPV6_ADDRESS_LINKING_DOWN = 10;
var IPV6_ADDRESS_LINK_DOWN = 11;

var IPV6_MODE_DISABLE = 0;
var IPV6_MODE_ROUTER = 1;
var IPV6_MODE_PASSTHROUGH = 2;

var IPV6_WAN_TYPE_ETHERNET = 0;
var IPV6_WAN_TYPE_PPPOE = 1;
var IPV6_WAN_TYPE_TUNNEL6TO4 = 2;

var IPV6_ADDR_TYPE_AUTO = 0;
var IPV6_ADDR_TYPE_SLAAC = 1;
var IPV6_ADDR_TYPE_DHCP = 2;
var IPV6_ADDR_TYPE_STATIC = 3;
var IPV6_ADDR_TYPE_TUNNEL = 4;

var IPV6_DNS_TYPE_AUTO = 0;
var IPV6_DNS_TYPE_SLAAC = 1;
var IPV6_DNS_TYPE_DHCP = 2;
var IPV6_DNS_TYPE_STATIC = 3;

var LEVEL_ALL = 0;

var DDNS_TYPE_PH = 0;

var DDNS_LINK_STATUS_DISCONNECTED = 0;
var DDNS_LINK_STATUS_CONNECTING = 1;
var DDNS_LINK_STATUS_CONNECTED = 2;
var DDNS_LINK_STATUS_AUTHFAIL = 3;
var DDNS_LINK_STATUS_DOMAINERROR = 4;
var DDNS_LINK_STATUS_GETTING_IP = 5;
var DDNS_LINK_STATUS_REGISTERRING = 6;
var DDNS_LINK_STATUS_DISCONNECTED_SUB_STATE = 7;
var DDNS_LINK_STATUS_NOLAUNCHING = 8;
var DDNS_LINK_STATUS_FAILED = 9;


var DDNS_SERVICE_TYPE_STA = 0;
var DDNS_SERVICE_TYPE_PRO = 1;
var DDNS_SERVICE_TYPE_NONE = 2;


var WDS_LINK_DISCONNECTED = 0;
var WDS_LINK_INIT = 1;
var WDS_LINK_SCAN = 2;
var WDS_LINK_AUTH = 3;
var WDS_LINK_ASSOC = 4;
var WDS_LINK_CONNECTED = 5;
var WDS_LINK_CONNECTING = 6;

var HTTP_CLIENT_FULL = 0;
var HTTP_CLIENT_LOCK = 1;
var HTTP_CLIENT_TIMEOUT = 2;
var HTTP_CLIENT_PSWERR = 3;
var HTTP_CLIENT_NORMAL = 4;
var HTTP_CLIENT_INVALID = 5;
var HTTP_CLIENT_PSWIlegal = 6;

var USER_GROUP_ADMIN = 0;
var USER_GROUP_REMOTE = 1;
(function () {
	$.su.define("MERProxy", {
		extend: "AjaxProxy",
		statics: {
			dataBlock: new DataBlock(),  //后台的数据模板
			/**
			 * 返回模板对象的拷贝
			 * @param identify 对象id
			 * @param copy 是否返回拷贝
			 * @returns {void|*|Object}
			 */
			findBlock: function(identify, layers)
			{
				var dataBlock;
				var blocks = $.su.ClassManager.getInstance().get("MERProxy").dataBlock;
				var findFirst = typeof layers == "undefined" || layers.join(',') == "0,0,0";
				identify = parseInt(identify);
				for (var property in blocks)
				{
					/* 找到了数据块。 */
					if (typeof blocks[property] == "object" &&
						blocks[property].id == identify &&
						(findFirst || blocks[property].layers === undefined || blocks[property].layers.join(',') == layers.join(',')))
					{
						dataBlock = blocks[property];
						break;
					}
				}
				return dataBlock;
			},
			/* 根据ID找到其所有实例数据块。--对外导出 */
			findBlockAll: function(identify)
			{
				var res = [];

				identify = parseInt(identify);
				var blocks = $.su.ClassManager.getInstance().get("MERProxy").dataBlock;
				for (var property in blocks)
				{
					/* 找到了数据块。 */
					if (typeof blocks[property] == "object" &&
						blocks[property].id == identify)
					{
						res.push(blocks[property]);
					}
				}

				return res;
			},
			/* 根据父layers找到其下该ID的所有实例数据块。--对外导出 */
			findBlockList: function(identify, pLayers)
			{
				var res = [];
				var blocks = $.su.ClassManager.getInstance().get("MERProxy").dataBlock;
				var isPrefix = function(listA, listB)
				{
					var prefix = [];
					for (var i in listA)
					{
						if (listA[i] != 0)
						{
							prefix.push(listA[i]);
						}
						else
						{
							break;
						}
					}
					return listB.join(',').startsWith(prefix.join(','));
				};

				identify = parseInt(identify);

				for (var property in blocks)
				{
					/* 找到了数据块。 */
					if (typeof blocks[property] == "object" &&
						blocks[property].id == identify &&
						isPrefix(pLayers, blocks[property].layers))
					{
						res.push(blocks[property]);
					}
				}

				return res;
			},
			/**
			 * 检查某datablock下的name字段是否为数组，有两种情况，datablock.name是数组，或data.xx是数组，name是xx下的对象的属性
			 * @param dataBlock
			 * @param name
			 * @returns {boolean}
			 */
			elmInArray: function(dataBlock, name)
			{
				var dataBlockZ;

				for (var property in dataBlock)
				{
					if (dataBlock[property] instanceof Array)
					{
						dataBlockZ = dataBlock[property][0];

						if (typeof dataBlockZ == "undefined" || typeof dataBlockZ != "object")
						{
							if (property == name)
							{
								return true;
							}

							continue;
						}

						if (dataBlockZ.hasOwnProperty(name))
						{
							return true;
						}
					}
				}

				return false;
			},
			/**
			 * 给对象的字段设值
			 * @param dataBlock
			 * @param name
			 * @param value
			 * @param index
			 */
			setElmValue: function(dataBlock, name, value, index)
			{
				var dataBlockZ, para;

				/* 对解析出的value进行unicode解码 */
				value = decodeURI(value);

				for (var property in dataBlock)
				{
					para = dataBlock[property];

					if (typeof para != "object" || para === null)
					{
						if (property == name)
						{
							dataBlock[property] = value;
							return;
						}

						continue;
					}

					/* 如果是对象但是不是数组 */
					if (Object.prototype.toString.call(para) != '[object Array]')
					{
						if (para.hasOwnProperty(name))
						{
							para[name] = value;
							return;
						}

						continue;
					}

					dataBlockZ = para[0];

					/* 给数组赋值的方法待定。下面的有问题。 */
					if (typeof dataBlockZ == "undefined" || typeof dataBlockZ != "object")
					{
						if (property == name)
						{
							if (null == index)
							{
								return;
							}

							para[parseInt(index)] = value;
							return;
						}

						continue;
					}

					/* 对象数组 */
					if (dataBlockZ.hasOwnProperty(name))
					{
						if (null == index)
						{
							return;
						}

						if (typeof para[parseInt(index)] != "object")
						{
							para[parseInt(index)] = {};
						}

						para[parseInt(index)][name] = value;
						return;
					}
				}
			},
			/**
			 * 解析TDDP文本，并将值赋给对应的成员属性
			 * @param text
			 * @returns {*}
			 */
			parser: function (text) {
				var PARSE_INIT = 0;		/* 初始态 */
				var PARSE_NOTE = 1;		/* 以#开头的为注释。注意:只有在初始态遇到了#才认为会是注释，否则会被当作内容。 */
				var PARSE_CMD = 2;		/* 解析命令。 */
				var PARSE_ID = 3;		/* 解析数据块ID。 */
				var PARSE_INDEX = 4;	/* 解析索引。 */
				var PARSE_VALUE = 5;	/* 解析值。 */
				var PARSE_ERR = 6;		/* 解析遇到错误。 */

				var machine = PARSE_INIT;     //解析步骤
				var element = {name: "", value: "", index: ""};    //保存一行数据的临时对象
				var dataBlock;                //数据模板
				var identify = "";            //对象id
				var parts= [];
				var layers = [];
				var ch = '';                  //当前字符
				var record = 0;               //当前词块的长度
				var result;              //返回结果

				if (text == "" || text == null || text == undefined ) {
					return null;
				}
				for (var index = 0; index < text.length; index++) {
					ch = text.charAt(index);
					switch (machine) {
						case PARSE_INIT:
							element = {name: "", value: "", index: ""};
							record = 0;

							if ('#' == ch)    /* 从#一直到行尾，均视为注释。 */
							{
								machine = PARSE_NOTE;
								continue;
							}

							/* 遇到可见字符，则视为遇到了一条tddp命令。 */
							if ((' ' < ch) && ('~' >= ch)) {
								machine = PARSE_CMD;
								element.name += ch;
								record++;
							}

							break;

						case PARSE_NOTE:
						case PARSE_ERR:
							if (('\r' == ch) || ('\n' == ch))    /* 遇到命令结束字符，恢复到初始状态。 */
							{
								machine = PARSE_INIT;
							}

							break;

						case PARSE_CMD:                            /* 空格/回车之前的部分算作命令。 */
							if ((' ' == ch) || ('\t' == ch))    /* 命令名解析完毕。 */
							{
								if (element.name == "id") {
									machine = PARSE_ID;
									record = 0;
									continue;
								}

								/* 根据名字找到对象中的元素 */
								if (undefined == dataBlock) {
									machine = PARSE_ERR;
									continue;
								}

								record = 0;
								machine = PARSE_VALUE;

								/* 如果是元素是数组，后续开始解析index. */
								if ($.su.ClassManager.getInstance().get("MERProxy").elmInArray(dataBlock, element.name)) {
									machine = PARSE_INDEX;
								}

								continue;
							}

							/* 在此阶段遇到了命令结束符，表明命令不完整，转到错误处理。 */
							if (('\r' == ch) || ('\n' == ch)) {
								machine = PARSE_ERR;
								continue;
							}

							element.name += ch;
							record++;

							break;

						case PARSE_ID:
							if ((' ' == ch) || ('\t' == ch)) {
								if (0 != record) {
									machine = PARSE_INIT;
									if (identify.indexOf('|') != -1){
										parts = identify.split('|');
										identify = parts[0];
										layers = parts[1].split(',');
										dataBlock = $.su.ClassManager.getInstance().get("MERProxy").findBlock(identify, layers);
										result = result || {};
										result[identify] = result[identify] || {};
										result[identify][parts[1]] = dataBlock;
									}else{
										dataBlock = $.su.ClassManager.getInstance().get("MERProxy").findBlock(identify);
										result = result || {};
										result[identify] = dataBlock
									}
									identify = "";
								}

								continue;

							}

							/* 命令提前结束。 */
							if (('\r' == ch) || ('\n' == ch)) {
								if (0 == record) {
									machine = PARSE_ERR;
									continue;
								}

								machine = PARSE_INIT;
								if (identify.indexOf('|') != -1){
									parts = identify.split('|');
									identify = parts[0];
									layers = parts[1].split(',');
									dataBlock = $.su.ClassManager.getInstance().get("MERProxy").findBlock(identify, layers);
									result = result || {};
									result[identify] = result[identify] || {};
									result[identify][parts[1]] = dataBlock;
								}else{
									dataBlock = $.su.ClassManager.getInstance().get("MERProxy").findBlock(identify);
									result = result || {};
									result[identify] = dataBlock;
								}
								identify = "";

								continue;
							}

							/* index必须是十进制的数字。 */
							if (ch != '|' && ch != ',' && ('0' > ch || ch > '9')) {
								machine = PARSE_ERR;
								continue;
							}

							identify += ch;
							record++;
							break;

						case PARSE_INDEX:
							if ((' ' == ch) || ('\t' == ch)) {
								if (0 != record) {
									//alert("index=" + element.index);
									machine = PARSE_VALUE;
									record = 0;
								}

								continue;
							}

							/* 命令提前结束。 */
							if (('\r' == ch) || ('\n' == ch)) {
								machine = PARSE_ERR;
								continue;
							}

							/* index必须是十进制的数字。 */
							if (('0' > ch) || (ch > '9')) {
								machine = PARSE_ERR;
								continue;
							}

							element.index += ch;
							record++;

							break;

						case PARSE_VALUE:
							if (((' ' == ch) || ('\t' == ch)) && (0 == record))    /* 忽略左边的空格。 */
							{
								continue;
							}

							if (('\r' == ch) || ('\n' == ch)) {
								/*alert(element.name + "=" + element.value + ", index=" + element.index);*/

								/* 如果没有value，那么直接使用默认的“” */
								$.su.ClassManager.getInstance().get("MERProxy").setElmValue(dataBlock, element.name, element.value, element.index);
								machine = PARSE_INIT;

								continue;
							}

							element.value += ch;
							record++;

							break;
					}

				}


				/* 有可能最后一条命令不带\r\n等结束符，此时需要进行检测。 */
				if ((PARSE_VALUE == machine) && (record > 0)) {
					/*alert(element.name + "=" + element.value + ", index=" + element.index);*/
					$.su.ClassManager.getInstance().get("MERProxy").setElmValue(dataBlock, element.name, element.value, element.index);
				}
				return result;
			},
			/* 把某个数据块转换成TDDP文本。对外 */
			toText: function(dataBlock)
			{
				var text = "";
				var index = 0;
				var element;
				var value = "";

				if (dataBlock['layers'] == undefined)
				{
					dataBlock['layers'] = [1, 0, 0];
				}

				for (var property in dataBlock)
				{
					if (property == 'layers')
					{
						continue;
					}
					/* 单个元素。 */
					if (typeof dataBlock[property] != "object")
					{
						if (property == "id")
						{
							value = dataBlock[property] + '|' + dataBlock["layers"].join(',');
						}
						else
						{
							/* 对value值进行unicode编码 */
							value = encodeURIComponent(dataBlock[property]);
						}
						text += property + " " + value + "\r\n";
						continue;
					}

					/* 是对象，但不是数组 */
					element = dataBlock[property];
					if (typeof element == "object" &&
						Object.prototype.toString.call(element) != '[object Array]')
					{
						for (var elm in element)
						{
							/* 对value值进行unicode编码 */
							value = encodeURIComponent(element[elm]);
							text += elm + " " + value + "\r\n";
						}

						continue;
					}

					/* 只是纯数组 */
					element = dataBlock[property][0];
					if (typeof element == "undefined" || typeof element != "object")
					{
						element = dataBlock[property];

						for (index = 0; index < element.length; index++)
						{
							/* 对value值进行unicode编码 */
							value = encodeURIComponent(element[index] || "");
							text += property + " " + index + " " + value + "\r\n";
						}

						continue;
					}

					element = dataBlock[property];

					/* 对象数组。 */
					for (index = 0; index < element.length; index++)
					{
						var dataEntry = element[index];
						for (var elm in dataEntry)
						{
							/* 对value值进行unicode编码 */
							value = encodeURIComponent(dataEntry[elm]);
							text += elm + " " + index + " " + value + "\r\n";
						}
					}
				}

				return text;
			}

		},
		constructor: (function(){
			var MERProxy = function (options) {
				MERProxy.$parent.call(this, options);
				//for the compatibility of old codes
				//以下属性会扩展到this和defaultOption上
				var merDefaultOption = {
					url: undefined,                   //
					blocks: undefined,               //节点
					instrs: undefined,               //标准指令对象
					reAuth: undefined,               //认证失败时是否重登录
					preventSuccessEvent: false,    //是否阻止成功时的默认事件（弹出toast）
					preventFailEvent: false,        //是否阻止失败时的默认事件（raise一个事件）
					preventErrorEvent: false,      //是否阻止错误时的默认事件（raise一个事件）
					urlAsyn: undefined,             //url中asyn参数，只在read中用到
					gdpr: undefined,                  //默认需要加密，设为false时不加密
					resetGdprNextRequest: undefined  //下一个请求时先重置加密器
				};
				for (var i in merDefaultOption) {
					if (merDefaultOption.hasOwnProperty(i)) {
						if (options && options.hasOwnProperty(i)) {
							this[i] = options[i];
						}
						this.defaultOption[i] = this[i];
					}
				}
			};
			return MERProxy;
		})(),
		urlAsyn: 1,
		blocks: undefined,
		ajax: {
			contentType: "text/plain;charset=UTF-8",
			dataType: "text",
			timeout: 15*1000
		},


		/**
		 * 后台的block及instr命令返回的报文，第一行都是错误码。该函数用于解释处错误码，并把后面的数据返回
		 * @param text 原始报文
		 * @returns {{errorCode: (string|*), data: *}} errorCode：错误码。 data：未解释的数据。
		 */
		errorAndDataSplit: function(text) {
			var pos, handleCode, n = 0, data, len;
			try {
				pos = text.search(/\r|\n/);
				handleCode = text.substring(0, pos);

				if (/\D/.test(handleCode) == true || handleCode.length == 0)
				{
					handleCode = undefined;
					data = text;
				}
				else
				{
					len = handleCode.length - 1;
					while((handleCode.charAt(n) == "0")&&(n < len))
					{
						n++;
					}

					handleCode = parseInt(handleCode.substring(n), 10);
					data = text.search(/\r\n/) === -1 ? text.substring(pos + 1) : text.substring(pos + 2);
				}

				return {
					errorCode: handleCode,
					data: data
				}
			} catch(e) {
				return {
					errorCode: undefined,
					data: text
				}
			}

		},
		failFilter: function(data){
			// var result = $.extend({}, data);
			// result.errorCode = data.errorCode || data.error || data.error_code || data.errorcode;
			return data;
		},

		/**
		 *  命令的分流入口。如果外部需要自定义proxy的处理逻辑，请重写此方法。
		 *  当operation=read且有blocks，调用this.read（读取节点）,如果没有blocks则调用this.instrsExe做更细的instr命令分流。
		 *  当operation=write且有blocks。调用this.write(写入节点)，如果没有blocks则调用this.instrsExe
		 * @param option 包含 url，
		 *                  method ajax的method，
		 *                  blocks数组或字符串，包含一个或多个节点id，
		 *                  instrs对象 其中又包括add、get、del、edit等对象，每个对象下又包括instr（命令前缀），fields（命令组装需要使用的字段），writeFilter， edit对象包含keyField字段
		 *                  ajax对象，
		 *                  success 成功回调，
		 *                  fail 失败回调，
		 *                  error 错误回调，
		 *                  operation Model或Store传下的操作识别，
		 *                  dataObj（Model或Sotre实例），
		 *                  difference model及sotre在执行他们本身的sync时传下的数据
		 *                  readFilter，
		 *                  writeFilter，
		 *                  failFilter，
		 *                  data 发送的数据，一般是空的，由各方法生成，
		 *                  api对象 可对本proxy中的read，write，instr三个基础方法的method、等多个参数再一次定制
		 * 多个地方可以传入option，相同配置项的优先级关系是：直接写在proxy.js上配置 < models中,创建proxy的配置 < models中,创建proxy配置中的api下同名方法的配置 < proxy调用时传入的配置
		 * @param other
		 */
		sync: function (option, other) {
			var operation = option.operation;
			// var difference = option.difference;
			var dataObj = option.dataObj;
			var modelType;
			if(dataObj instanceof $.su.Model){
				modelType = "Model";
			}else if(dataObj instanceof $.su.Store){
				modelType = "Store";
			}

			if (operation === "read") {
				if (this.instrs && this.instrs.get) {
					this.instrsExe.apply(this, arguments);
				} else if (this.blocks !== undefined) {
					this.read.apply(this, arguments);
				} else if (this.url) {
					this.urlRequest(option);
				} else {
					$.su.debug.error('no instrs or blcoks or url in operation read');
				}

			} else if (operation === "write") {
				if (this.instrs && (this.instrs.add || this.instrs.edit || this.instrs.del || this.instrs.clear)) {
					this.instrsExe.apply(this, arguments);
				} else if (this.blocks) {
					this.write.apply(this, arguments);
				} else {
					$.su.debug.error('no instrs or blcoks in operation write ');
				}
			} else {
				if (!this[operation]) {
					$.su.debug.error('no such operation: ', operation);
				} else {
					this[operation].apply(this, arguments);
				}
			}
		},
		/**
		 * 配合model或store使用，success加入了ev_load事件触发
		 * @param options
		 * @param other
		 * @param triggerEvent
		 * @returns {*}
		 */
		urlRequest: function(options, other, triggerEvent) {
			var me = this;

			options.readFilter = options.readFilter || function(data) {
					return data;
				};
			if (triggerEvent !== false) {
				var successCallback = options.success;
				options.success = function (filteredData, data, status, xhr) {
					me.trigger("ev_load", [filteredData]);
					!!successCallback && successCallback(filteredData, data, status, xhr);
				};
			}
			return this.op("urlRequest", options);
		},
		/**
		 * 读取后台的节点。组装url，使用blocks组装data。使用默认的readFilter解释数据。
		 * @param options
		 * @param other
		 * @param triggerEvent 默认触发ev_load事件。
		 * @returns {*} 返回$.Deferred
		 */
		read: function (options, other, triggerEvent) {
			var me = this;
			blocks = options.blocks || this.blocks;
			var blocks = $.isArray(blocks) ? blocks : [blocks];
			var data = [];
			var blocksWithLayer;  //原始id上可能没有layers，在添加layers后block的数量可能会变多，将其存起来，在readFilter上使用
			for (var i = 0; i < blocks.length; i++) {
				if(blocks[i].toString().indexOf("|")>-1){
					data.push(blocks[i]);
				}else{
					var tmpBlock = $.su.ClassManager.getInstance().get("MERProxy").findBlockAll(blocks[i]);
					for(var j=0; j< tmpBlock.length; j++){
						if(tmpBlock[j].layers){
							data.push(blocks[i] + "|" + tmpBlock[j].layers.join(","));
						}else{
							data.push(blocks[i].toString());
						}
					}
				}
				//data += blocks[i] + '#';
			}
			blocksWithLayer = data.slice();
			//data = data.substring(0, data.length - 1);
			data = data.join("#");
			options.data = data || options.data;
			options.url = $.su.url("?code=" + TDDP_READ + "&asyn=" + this.urlAsyn, data);
			/**
			 * 将文本解释成数据对象，如果blocks中只有一个id，返回单个对象，否则返回更高一层的对象.
			 * 有两层readFilter，第一层是调用旧水星代码解析原始数据，第二层是用options或api传入的readFilter再进行过滤。
			 * @param data 文本的形式
			 * @returns {*}
			 */
			var readFilterLevel2 = options.readFilter || (this.api["read"] && this.api["read"].readFilter) || this.readFilter || function(data) { return data };
			options.readFilter = options.readFilter || function(data) {
					data = $.extend(true,{}, $.su.ClassManager.getInstance().get("MERProxy").parser(data));
					var blockID;
					var tempData = {};
					var blocksWithLayerObj = {};
					var tmpId;
					var tmpLayer;
					if (blocksWithLayer.length == 1) {
						//如果请求的数据只有一个，直接返回单个对象
						tmpId = blocksWithLayer[0].split("|")[0];
						tmpLayer = blocksWithLayer[0].split("|")[1];
						tempData = data[tmpId] && (data[tmpId][tmpLayer] || data[tmpId]);  //可能原始data中没有layer
					} else {
						//如果请求的数据不止一个，根据blocksWithLayer筛选后再返回

						//将blocksWithLayer处理成这样的格式：
						//{1:["1,0,0", "1,2，0"]}
						for (var i = 0; i < blocksWithLayer.length; i++) {
							tmpId = blocksWithLayer[i].split("|")[0];
							tmpLayer = blocksWithLayer[i].split("|")[1];
							blocksWithLayerObj[tmpId] = blocksWithLayerObj[tmpId] || [];
							blocksWithLayerObj[tmpId].push(tmpLayer);
						}
						for (tmpId in blocksWithLayerObj) {
							if (blocksWithLayerObj.hasOwnProperty(tmpId)) {
								var tmpLayerArr = blocksWithLayerObj[tmpId];
								if (tmpLayerArr.length == 1) {
									//只有一个layer，不管layer是什么，返回数据的key名省掉layer后缀，
									tmpLayer = tmpLayerArr[0];
									tempData[tmpId] = data[tmpId] && (data[tmpId][tmpLayer] || data[tmpId]);  //可能原始data中没有layer
								} else {
									//如果有多个layer，则key名是 1|1,0,0的形式，用layer做后缀
									for (var j = 0 ; j < tmpLayerArr.length; j++) {
										tmpLayer = tmpLayerArr[j];
										tempData[tmpId + "|" + tmpLayer] = data[tmpId] && (data[tmpId][tmpLayer] || data[tmpId]);  //可能原始data中没有layer
									}
								}
							}
						}
					}

					return readFilterLevel2(tempData);
				};
			if (triggerEvent !== false) {
				var successCallback = options.success;
				options.success = function (filteredData, data, status, xhr) {
					me.trigger("ev_load", [filteredData]);
					!!successCallback && successCallback(filteredData, data, status, xhr);
				};
			}
			return this.op("read", options);
		},

		/**
		 * proxy中最底层的接口，调用connection发送数据，返回_decorateOption创建的promise
		 * @param option
		 * @returns {*} 返回_decorateOption创建的promise
		 */
		request: function (option) {
			var me = this;
			var dtd = $.Deferred();

			var requestDfd = $.Deferred().resolve();

			if ($.su.serviceManager.get("device").getConfig().gdpr && !$.su.development) {
				//如果此请求需要gdpr，且resetGdprNextRequest被设为true，则需要新完成同步密钥
				if (option.gdpr !== false && $.su.resetGdprNextRequest) {
					//如果同步密钥的任务已被创建，则不创建新的，等同步完后再发此次的请求
					if ($.su.resetGdprDtd) {
						requestDfd = $.su.resetGdprDtd;
					} else {
						//创建一个同步密钥的任务，任务执行完后才把相关标志置空。在执行完前，所有请求都会被阻塞
						var mainModule = $.su.moduleManager.query("main");
						$.su.resetGdprDtd = mainModule.resetAndSyncEncryptor && mainModule.resetAndSyncEncryptor();
						$.su.resetGdprDtd.then(function() {
							$.su.resetGdprNextRequest = false;
							$.su.resetGdprDtd = null;
						});
						requestDfd = $.su.resetGdprDtd
					}

				}

				//resetGdprNextRequest为真，下一个请求重设gdpr秘钥
				if (option.resetGdprNextRequest) {
					$.su.resetGdprNextRequest = true;
				}
			}


			requestDfd.then(function() {
				me._decorateOption(option).then(function(data) {
					dtd.resolve(data);
				}, function(data) {
					dtd.reject(data);
				});
				
				me.connection.request(option);
			});

			return dtd.promise();
		},

		// @param {string} operation: api name to call
		// @param {object} options: for the compatibility of old codes,
		op: function (operation, options) {
			// this.connection.request(options);
			var optionTar = $.extend(true, {}, this.defaultOption, this.api[operation], options);
			optionTar.opMethod = operation || "default";
			return this.request(optionTar);
		},

		/**
		 * 调用writerFilter对data进行过滤。对原始报文提取错误码，调用readFilter解释数据，根据错误码相应调用success或fail。
		 * @param option
		 * @returns {*}
		 * @private
		 */
		_decorateOption: function (option) {
			var me = this;
			var dtd = $.Deferred();
			var gdprFlag = $.su.serviceManager.get("device").getConfig().gdpr
				&& $.su.encryptor
				&& option.gdpr !== false
				&& !$.su.development;
			if (option.writeFilter) {
				option.data = option.writeFilter.call(this, option.data);
			}

			if (gdprFlag) {
				var tempData = $.su.encryptor.dataEncrypt(option.data);
				option.data = "sign=" + tempData.sign + "\r\n" + "data=" + tempData.data;
			}
			var successCallback = !!option && option.success;
			var failCallback = !!option && option.fail;
			var errorCallback = !!option && option.error;
			option.success = function (data, status, xhr) {
				try {
					if (gdprFlag) {
						data = $.su.encryptor.dataDecrypt(data);
					}
					data = me.errorAndDataSplit ? me.errorAndDataSplit(data, status, xhr) : {};
				} catch(e) {
					$.su.debug.log("parse error in proxy's success");
					var mainModule = $.su.moduleManager.query("main");
					mainModule.logout && mainModule.logout();
					return;
				}

				if (data.errorCode === 0) {
					var filteredData = (option.readFilter) ? option.readFilter.call(me, data.data) : data.data;
					!!successCallback && successCallback(filteredData, data, status, xhr);
					dtd.resolve([filteredData, data, status, xhr]);
					var exeFlag = false;

					if (!option.preventSuccessEvent) {
						if (option.operation) {
							if (option.operation != 'read') {
								exeFlag = true
							}
						} else if (option.opMethod != "default" && option.opMethod != "read" && option.opMethod != "urlRequest"){
							exeFlag = true
						}
					}
					if (exeFlag && $.su.moduleManager.query("main")) {
						$.su.moduleManager.query("main").showNotice($.su.CHAR.COMMON.SAVED);
					}

				} else {
					var failData = (option.failFilter) ? option.failFilter.call(me, data.data): data.data;
					!!failCallback && failCallback(failData, data.errorCode, status, xhr);
					dtd.reject([failData, data.errorCode, status, xhr]);
					if (!option.preventFailEvent) {
						$.su.raise({
							msg: "ev_proxy_fail",
							type: "proxy_fail",
							errorCode: data.errorCode,
							proxy: me
						});
					}
				}
			};
			option.error = function(xhr, textStatus, errorThrown){
				var mainModule = $.su.moduleManager.query("main");
				if(xhr.status == 401){
					//获取返回的数据，如果是加密过的，先进行解密。将data变成{errorCode: 123, data:xxx}的格式
					var data = xhr.responseText;
					try {
						if (gdprFlag) {
							data = $.su.encryptor.dataDecrypt(data);
						}
						data = me.errorAndDataSplit ? me.errorAndDataSplit(data) : {};
					} catch (e) {
						data = {};
					}

					//判断当前是否云登录，获取重认证用的pwd
					var isCloudLogin = false;
					var pwd;
					if (mainModule) {
						isCloudLogin = mainModule.isCloudLogin();
						if (isCloudLogin) {
							pwd = mainModule.getCloudAuth()
						} else {
							pwd = mainModule.getPwd();
						}
					}
					option.authCount = option.authCount || 0;
					var errorHandle = function() {
						var failData = (option.failFilter) ? option.failFilter.call(me, data.data): data.data;
						!!failCallback && failCallback(failData,  data.errorCode);
						dtd.reject([failData, data.errorCode]);
					};
					//如果已经登录，且错误码是超时，需要重新登录再发送请求
					if (data.errorCode === EUNAUTH && pwd && mainModule instanceof $.su.Module && option.authCount == 0 && option.reAuth !== false) {
						option.authCount++;
						if (isCloudLogin) {
							//如果是云登录，需要再发请求获取tmpKey，之后重新登录，再重发请求
							mainModule.getCloudTmpKey().then(function () {
								return mainModule.cloudAuthWithId(pwd)
							}).then(function () {
								me.connection.request(option);
							}, function () {
								dtd.reject([textStatus, xhr]);
								mainModule.logout && mainModule.logout();
							});
						} else {
							//如果是普通登录，从返回的数据里解析出tmpKey
							var results;
							var relCnt = data.data;

							if (relCnt.lastIndexOf("\r\n") == relCnt.length - 2)
							{
								relCnt = relCnt.substring(0, relCnt.length - 2);
							}

							results = relCnt.split("\r\n");
							
							mainModule.updateAuthInfo(results);
							mainModule.login(pwd, function () {
								me.connection.request(option);
							}, function () {
								dtd.reject([textStatus, xhr]);
								mainModule.logout && mainModule.logout();
							});
						}
					} else if (data.errorCode === undefined) {
						$.su.debug.log("parse error in proxy's error");
						mainModule.logout && mainModule.logout();
					}else {
						errorHandle();
					}
				} else if(xhr.status == 408 || xhr.status == 403){
					//老化超时或解密出错
					dtd.reject([textStatus, xhr]);
					mainModule.logout && mainModule.logout();
				}else {
					dtd.reject([textStatus, xhr]);
					errorCallback(textStatus, xhr);
					var raiseMsg = function() {
						$.su.raise({
							msg: "ev_ajax_error",
							type: "ajax_error",
							errorCode: xhr.status,
							proxy: me
						});
					};
					if (!option.preventErrorEvent) {
						raiseMsg();
					}
				}
			};
			return dtd;
		},

		/**
		 * 判断obj是否为block的一个子集，即obj有的属性block都有
		 * @param obj 数据对象
		 * @param block 模板对象
		 * @returns {boolean} 为子集返回true
		 */
		_objSubBlock: function(obj, block) {
			for (var i in obj) {
				if (obj.hasOwnProperty(i)) {
					if (!block.hasOwnProperty(i)) {
						return false;
					}
				}
			}
			return true;
		},
		/**
		 * 给数据加上id,因为字段有特定的顺序，所以把数据覆盖到模板上，再返回模板
		 * @param {Array/Object} data model层返回的数据
		 * @returns {Array/Object} 添加id后的数据
		 */
		addDataId: function(data) {
			if (!$.isArray(data)) {
				data = [data];
			}
			var blocks = this.blocks;
			if (!$.isArray(blocks)) {
				blocks = [blocks];
			}
			var tempBlock;
			for (var i = 0; i< data.length; i++) {
				if (data[i].id) {
					//一旦显示指定id，layers如果不指定则使用默认值，不再从blocks中查找
					tempBlock = $.extend(true, {}, $.su.ClassManager.getInstance().get("MERProxy").findBlock(data[i].id, data[i].layers));
					data[i] = $.extend(true, tempBlock, data[i]);
					continue;
				}

				//如果没有id，遍历blocks，找到匹配的block，并添加id
				for (var j = 0; j < blocks.length; j++) {
					var tmpId = blocks[j];
					var tmpLayer;
					if (blocks[j].toString().indexOf('|') != -1) {
						tmpId = blocks[j].split('|')[0];
						tmpLayer = blocks[j].split('|')[1].split(','); //[1,0,0]形式
					}
					tempBlock = $.extend(true, {}, $.su.ClassManager.getInstance().get("MERProxy").findBlock(tmpId, tmpLayer));
					if (this._objSubBlock(data[i], tempBlock)) {
						data[i] = $.extend(true, tempBlock, data[i]);
						break;
					}
				}
				if (!data[i].id) {
					$.su.debug.error('blockId notFound: ', data[i]);
				}
			}
			if (data.length > 1) {
				return data;
			} else {
				return data[0];
			}
		},
		/**
		 * 将数据同步（覆盖）到数据备份上
		 * @param data 数据必须包含id和layers
		 * @private
		 */
		_updateBackupData: function(data) {
			if (!$.isArray(data)) {
				var data = [data];
			}

			for (var i = 0; i < data.length; i++) {
				var tempData = data[i];
				var blockData = $.su.ClassManager.getInstance().get("MERProxy").findBlock(tempData.id, tempData.layers);
				if (blockData) {
					$.extend(true, blockData, tempData);
				} else {
					$.su.debug.error('updateBackupData error');
				}

			}
		},
		/**
		 * 组装url及data，对后台节点进行写入操作。默认触发ev_sync_success。
		 * @param options
		 * @param other
		 * @param triggerEvent
		 * @returns {*}
		 */
		write: function (options, other, triggerEvent) {
			var me = this;
			var updateBackup = options.updateBackup;
			options.difference = $.extend({update:{}}, options.difference);
			options.data = options.data || this.addDataId(options.difference.update.model);
			options.addId && (options.data = this.addDataId(options.data));
			options.url = $.su.url("?code=" + TDDP_WRITE + "&asyn=" + (options.asyn || 0));
			options.writeFilter = function(data) {
				if (!$.isArray(data)) {
					var data = [data];
				}
				var contentText = "";
				for (var i = 0; i< data.length; i++) {
					contentText += $.su.ClassManager.getInstance().get("MERProxy").toText(data[i]);
				}
				return contentText;
			};
			if (triggerEvent !== false) {
				var successCallback = options.success;
				options.success = function (filteredData, data, status, xhr) {
					if (updateBackup !== false) {
						me._updateBackupData(options.data);
					}
					me.trigger("ev_sync_success", [filteredData]);
					!!successCallback && successCallback(filteredData, data, status, xhr);
				};
			}
			return this.op("write", options);
		},

		/**
		 * instr命令分流。根据options.difference中的数据创建增删改任务。
		 * @param options
		 * @param other
		 */
		instrsExe: function(options, other) {
			var me = this;
			if (options.operation == "read") {
				this.instrGet(options, other)
			} else if (options.operation == "write") {
				//这一层根据difference，创建一个或多个增删改的任务，待任务都执行完毕后再执行回调和事件触发
				//所以这一层在调用instrSync创建任务时，triggerEvent=false，各call=bull
				var store = options.dataObj;       //没使用
				var promiseArray = [];              //存储多任务的promise的数组
				var optionsCopy = $.extend({}, options, true);   //options的拷贝，去掉callback，保留其它配置项，ajax、filter等
				var successCallback = optionsCopy.success;
				var failCallback = optionsCopy.fail;
				var errorCallback = optionsCopy.error;
				optionsCopy.success = null;
				optionsCopy.fail = null;
				optionsCopy.error = null;

				//清空条目
				if(optionsCopy.deleteAll) {
					return this.instrClear(options, other);
				}
				//删除条目。多个条目时需要串行执行
				if (!$.su.isEmptyObject(options.difference.remove)) {
					var removeItems = options.difference.remove;
					var removeItemArray = [];

					//删除时要根据index从大到小地删除，所以先把条目存储到数组中
					for (var key in removeItems) {
						if (removeItems.hasOwnProperty(key)) {
							removeItemArray[removeItems[key].index] = removeItems[key];
						}
					}
					//
					// removeItemArray[0] = removeItemArray[1];
					var promise = $.Deferred().resolve();
					//创建串行多任务的promise。按从大到小的顺序删除，其中一个出错，则停止删除，直接到fail回调
					//promise的特性：使用promise=$.Deferred().then(function{ return $.Deferred()}).then(...)的形式串行执行任务，
					// 最终创建的promise只有当所有then中return的promise都resolve它才resolve，只要有一个reject，它就reject并停止执行后续的then
					for (var i = removeItemArray.length - 1; i >= 0; i--) {
						if (removeItemArray[i]) {
							var tempItem = removeItemArray[i];
							var removeItem = function(tempItem) {
								return promise.then(function() {
									return me.instrSync({
										instrObj: me.instrs.del,
										model: tempItem.oldModel,
										index: tempItem.index,
										triggerEvent: false
									}, optionsCopy, other)
								});
							};
							promise = removeItem(tempItem);
						}
					}
					promiseArray.push(promise);  //只需要把最终的promise存起来，中间的不必存
				}
				//新增条目。正常情况下，一次只会有一条条目。
				if(!$.su.isEmptyObject(options.difference.insert)){
					if (options.dataObj instanceof $.su.Model) {
						// 将model的数据结构处理为与store一致
						// model中需要自带index字段
						var tmpInsert = options.difference.insert;
						tmpInsert.index = tmpInsert.model.index || 0;
						options.difference.insert = {
							insert: tmpInsert
						};
					}
					var insertItems = options.difference.insert;
					//并行多任务
					for (var key in insertItems) {
						if (insertItems.hasOwnProperty(key)) {
							promiseArray.push(this.instrSync({
								instrObj: me.instrs.add,
								model: insertItems[key].model,
								index: insertItems[key].index,
								triggerEvent: false
							}, optionsCopy, other));
						}
					}
				}
				//修改条目。正常情况下只会有一条条目
				if(!$.su.isEmptyObject(options.difference.update)){
					if (options.dataObj instanceof $.su.Model) {
						// 将model的数据结构处理为与store一致
						// model中需要自带index字段
						var tmpUpdate = options.difference.update;
						tmpUpdate.index = tmpUpdate.model.index || 0;
						options.difference.update = {
							update: tmpUpdate
						};
					}
					var updateItems = options.difference.update;
					var instrEditObj = (options.instrs && options.instrs.edit) || this.instrs.edit || {};
					var keyField = instrEditObj.keyField;
					var delAndAdd = instrEditObj.delAndAdd === undefined ? false : instrEditObj.delAndAdd;
					//并行多任务。虽然实际上一次不会出现多任务的情况
					for (var key in updateItems) {
						if (updateItems.hasOwnProperty(key)) {
							//后台使用条目的index或者某些字段作为key值。
							//keyField指定某字段为key字段。如果没有keyField，一般要在instrs.xxx.fields中加入”index“。
							//如果没有指定keyField或该字段没有修改,则根据instrs.edit的配置创建一条instr命令
							var delAndAddFlag = false;
							if (delAndAdd === true ||
								($.isFunction(delAndAdd) && delAndAdd())) {
								//如果delAndAdd为真，需要先删除后添加
								delAndAddFlag = true;
							} else if (keyField !== undefined &&
								updateItems[key].oldModel &&
								updateItems[key].model[keyField] != updateItems[key].oldModel[keyField]) {
								//后台使用条目的index或者某些字段作为key值。
								//keyField指定某字段为key字段。如果没有keyField，一般要在instrs.xxx.fields中加入”index“。
								//如果修改了keyField，需要先删除后创建
								delAndAddFlag = true;
							}

							if (!delAndAddFlag) {
								//根据instrs.edit修改旧条目
								promiseArray.push(this.instrSync({
									instrObj: me.instrs.edit,
									model: updateItems[key].model,
									index: updateItems[key].index,
									triggerEvent: false
								}, optionsCopy, other));
							} else {
								//需要删除旧条目（根据instrs.del的配置），再添加一条新条目（根据instrs.add的配置）
								promiseArray.push(this.instrSync({
									instrObj: me.instrs.del,
									model: updateItems[key].oldModel,
									index: updateItems[key].index,
									triggerEvent: false
								}, optionsCopy, other).then(function() {
									return me.instrSync({
										instrObj: me.instrs.add,
										model: updateItems[key].model,
										index: updateItems[key].index,
										triggerEvent: false
									}, optionsCopy, other);
								}));

							}
						}
					}
				}

				//多个任务执行完毕后。统一触发事件和调用相应回调
				$.when.apply(this, promiseArray).then(function (data) {
					//任务执行成功
					me.trigger("ev_sync_success", [data && data[0]]);
					!!successCallback && successCallback.apply(null, data);
				}, function(data) {
					if (data.length == 4) {
						//任务执行失败，errorcode>0
						me.trigger("ev_sync_success", [data[0]]);
						!!failCallback && failCallback.apply(null, data);
					} else {
						//任务执行出错，ajax出错
						!!errorCallback && errorCallback.apply(null, data);
					}
				});
			}
		},
		/**
		 * 根据instrs.get创建一个instr任务。默认触发ev_load事件，执行options中的回调。
		 * @param options 包含callback也可包含instrs.get
		 * @param other
		 * @returns {*} 返回$.Deferred对象
		 */
		instrGet: function(options, other) {
			var instrGetObj = (options.instrs && options.instrs.get) || this.instrs.get || {};
			options.data = instrGetObj.instr;
			return this.instr(options, other);
		},
		/**
		 * 根据dataObj生成一个instr任务。
		 * @param dataObj 包含多个属性。instrObj: 其中又包含instr（命令前缀）、fields（指定要组装的字段,可以是字符串直接指定字段名，也可以是对象里面包含name、mapping、filter等）、writeFilter（自定义组装格式,传入instrObj, model）等。
		 *                               model: 用于组装命令的数组，一般是sotre及model传下来的数据，options.difference.update[key].model。
		 *                               index: 条目在store中index，与model并列。
		 *                               triggerEvent：是否触发事件，默认否。
		 * @param options  包含callback，ajax配置，filter等
		 * @param other
		 * @returns {*} 返回$.Deferred对象
		 */
		instrSync: function(dataObj, options, other) {
			var instrObj = dataObj.instrObj || {};
			var model = dataObj.model || {};
			var writeFilter = dataObj.writeFilter || function(instrObj, model) {
					var fields = instrObj.fields;
					var instrText = instrObj.instr;

					if (fields && $.isArray(fields)) {
						for (var j = 0; j < fields.length; j++) {
							var tempName;
							var mappingName;
							var filter;
							if (typeof fields[j] == 'string') {
								tempName = fields[j];
								mappingName = fields[j];
							} else if (typeof fields[j] == 'object'){
								tempName = fields[j].name || "";
								mappingName = fields[j].mapping || fields[j].name;
								filter = fields[j].filter;
							}

							if (tempName == 'index' && !model[mappingName]) {
								var index = dataObj.index || "0";
								instrText += " " + tempName + ':' + (filter ? filter(index) : index);
							} else {
								if (tempName != "") {
									instrText += " " + tempName + ':' + (filter ? filter(model[mappingName]) : model[mappingName]);
								} else {
									instrText += " "  + (filter ? filter(model[mappingName]) : model[mappingName]);
								}

							}

						}
					}else {
						for (var keyName in model) {
							if (model.hasOwnProperty(keyName)) {
								instrText += " " + keyName + ":" + model[keyName];
							}
						}
					}

					return instrText;
				};

			options.data = writeFilter(instrObj, model);

			return this.instr(options, other, dataObj.triggerEvent);
		},
		/**
		 * 清除指令
		 * @param options
		 * @param other
		 * @returns {*}
		 */
		instrClear: function(options, other) {
			var instrObj = (options.instrs && options.instrs.clear) || this.instrs.clear || {};
			options.data = instrObj.instr || instrObj;

			return this.instr(options, other);
		},

		/**
		 * 最基础的instr命令接口，组装url，把已组装好的options.data发出去。
		 * @param options 包含callback，ajax配置，filter等
		 * @param other
		 * @param triggerEvent 是否触发事件。
		 * @returns {*}
		 */
		instr: function(options, other, triggerEvent) {
			var me = this;
			options.url = $.su.url("?code=" + TDDP_INSTRUCT + "&asyn=0", options.data);
			var successCallback = options.success;
			if (triggerEvent !== false) {
				//当operation=read时，触发ev_load
				if (options.operation == "read") {
					options.success = function (filteredData, data, status, xhr) {
						me.trigger("ev_load", [filteredData]);
						!!successCallback && successCallback(filteredData, data, status, xhr);
					};
				} else{
					//当operation=write时，触发ev_sync_success
					options.success = function (filteredData, data, status, xhr) {
						me.trigger("ev_sync_success", [filteredData]);
						!!successCallback && successCallback(filteredData, data, status, xhr);
					};
				}
			}

			return this.op("instr", options);
		},
		upload: function(options){
			//upload前需要保证当前不是session过期的状态，先做一次登录。成功做
			var me = this;
			this.op("default", {
				url: $.su.url("?code="+ TDDP_AUTH + "&asyn=1", "loginCheck"),
				preventFailEvent: true,
				gdpr: false,
				success: function() {
					var defaultOption = (me.api['upload'] ? me.api['upload'] : me.defaultOption);
					var optionTar = $.extend({}, defaultOption, options);
					// me._decorateOption(optionTar);
					me.connection.upload(optionTar);
				},
				fail: options.fail,
				error: options.error
			});

		}
	});

})(jQuery);
