(function() {
	$.su = $.su || {};
	$.su.Services = $.su.Services || {};
	$.su.Services.LanguageService = (function() {
		var Language = function() {
			this.init();
			this.name = 'language';
			$.su.Service.call(this);
		};
	
		$.su.inherit($.su.Service, Language);
	
		Language.prototype.init = function(){
			$.su.serviceManager.get("ajax").request({
				method: "read",
				proxy: "languageProxy"
			})
		};
	
		Language.prototype.getLocale = function(){
			return $.su.language.getLocale();
		};
	
		Language.prototype.switchTo = function(lanType, callback_success, callback_failed){
			$.su.serviceManager.get("ajax").request({
				method: "setLocale",
				proxy: "languageProxy",
				data: {
					locale: lanType
				},
				success: function(data) {
					location.reload();
					if (callback_success){
						callback_success.call();
					}
				},
				fail: callback_failed
			})
		};
	
		return Language;
	})();
})();