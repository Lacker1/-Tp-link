(function(){
	var extendSettings = {
		classManager: {
			loader: "Loader"
		},
		Proxy: {
			defaultRoot: "root"
		},
		Model: {
			defaultProxy: "MERProxy",
			depFields: ["proxy"]
		},
		Store: {
			defaultProxy: "MERProxy",
			depFields: ["proxy"]
		},
		AjaxService: {
			defaultProxy: "MERProxy"
		},
		AjaxProxy: {
			defaultConnection: "Connection"
		}
	};

	$.extend($.su.settings, extendSettings);
})(jQuery);
