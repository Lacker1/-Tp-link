/*
 * @description
 * @author XCH
 * @change
 *   2017/12/07: create file
 *
 * */
 (function($){
 	var weekdaySelect = $.su.Widget.register("weekdaySelect", {
 		settings: {},

 		listeners: [{
 			selector: ".icon",
 			event: "click",
 			callback: function(e, viewObj){
 				$(this).toggleClass("selected");
 				var val = viewObj.getValue();

 				viewObj.dom().triggerHandler("ev_view_change", [{
                    "type": "value",
                    "value": val
                }]);
 			}
 		}],

 		init: function(){},

 		render: function(){
			var _this = this.dom();
			var settings = this.settings;
			var labelField = settings.labelField === false ? 'label-empty' : '';

			_this.addClass(settings.cls + "wireless-schedule-repeat-container " + labelField);

			var innerHTML =	"";
			if (settings.labelField !== null) {
                innerHTML += '<div class="widget-fieldlabel-wrap' + settings.labelCls + (settings.labelField == '' ?  ' empty' : '') + '">';
				innerHTML += '<div class="widget-fieldlabel-inner">';
                innerHTML += '<label class="widget-fieldlabel text-fieldlabel">' + settings.labelField + '</label>';
                if (settings.labelField) {
                    innerHTML += '<span class="widget-separator">' + settings.separator + '</span>';
                }
                innerHTML += '</div>';
                innerHTML += '</div>';
            }
            	innerHTML += '<div class="widget-wrap-outer wireless-schedule-repeat-wrap-outer">';
            	innerHTML += '<ul>';
            	innerHTML +=	'<li ><span class="icon sun" data-type="sun"></span></li> ';
            	innerHTML +=	'<li ><span class="icon mon" data-type="mon"></span></li> ';
            	innerHTML +=	'<li ><span class="icon tue" data-type="tue"></span></li> ';
            	innerHTML +=	'<li ><span class="icon wed" data-type="wed"></span></li> ';
            	innerHTML +=	'<li ><span class="icon thu" data-type="thu"></span></li> ';
            	innerHTML +=	'<li ><span class="icon fri" data-type="fri"></span></li> ';
            	innerHTML +=	'<li ><span class="icon sat" data-type="sat"></span></li> ';
            	innerHTML += '</ul>';
            	innerHTML += '<div widget="errortip" error-cls="' + settings.errorTipsCls + '">';
            	innerHTML += '</div>';
            	innerHTML += '</div>';

			_this.empty().append(innerHTML);
 		},

 		setValue: function(value){
			var _this = this.dom();
			if(value){
				var day = value.split(",");
				_this.find(".icon").removeClass("selected");

				if(value == "eve"){
					_this.find(".icon").addClass("selected");
					return;
				}else if(value == "weekdays"){
					_this.find(".icon.mon").addClass("selected");
					_this.find(".icon.tue").addClass("selected");
					_this.find(".icon.wed").addClass("selected");
					_this.find(".icon.thu").addClass("selected");
					_this.find(".icon.fri").addClass("selected");
					return;
				}else if(value == "weekends"){
					_this.find(".icon.sat").addClass("selected");
					_this.find(".icon.sun").addClass("selected");
					return;
				}
				for(var i = 0; i < day.length; i++){
					_this.find(".icon."+day[i]).addClass("selected");
				}
			}else{
				_this.find(".icon").removeClass("selected");
			}
 		},

		getValue: function(){
			var _this = this.dom();
			var value = "";
			var days = _this.find(".icon");
			for(var i = 0; i < days.length; i++){
			    if($(days[i]).hasClass("selected")){
			        value += $(days[i]).attr("data-type") + ",";
			    }
			}
			value = value.substr(0, value.length-1);
			
			return value;
		},
		 
		disable: function () {
		 var _this = this.dom();
		 var container = this.getContainer();
		
		 container.addClass("disabled");
		 _this.triggerHandler('ev_view_disable');
		},
		enable: function () {
			var _this = this.dom();
			var container = this.getContainer();
			
			container.removeClass("disabled");
			_this.triggerHandler('ev_view_enable');
		}

 	});
 })(jQuery);
