(function () {
	var Steps = $.su.Widget.register('steps', {
		settings: {
 			fields: {
 				attribute: "fields",
 				defaultValue: null
 			}
 		},

		render: function(){
			var _this = this.dom();
			var settings = this.settings;
			var fields = settings.fields;

			_this.addClass("steps-container");

			var innerHTML = '<ul class="steps-ul">';
			if(fields){
				for(var i = 0; i < fields.length; i++){
					var text = (typeof fields[i].text === "string") ? fields[i].text : "";
					innerHTML += '<li class="step-li step-point-wrapper step-item' + fields[i].name + '">';
					innerHTML +=    '<div class="step-item-text hidden">' + text + '</div>';
					innerHTML +=    '<div class="step-item-point"></div>';
					innerHTML += '</li>';
					if(i != fields.length - 1){
						innerHTML += '<li class="step-li step-line-wrapper' + fields[i].name + '">';
						innerHTML +=    '<div class="step-item-line"></div>';
						innerHTML += '</li>';
					}
				}
			}
			innerHTML += '</ul>';
			_this.append(innerHTML);
		},

		loadItems: function(items){
			var fields = this.settings.fields = items;
			var innerHTML = "";
			for(var i = 0; i < fields.length; i++){
				var text = (typeof fields[i].text === "string") ? fields[i].text : "";
				innerHTML += '<li class="step-li step-point-wrapper step-item' + fields[i].name + '">';
				innerHTML +=    '<div class="step-item-text hidden">' + text + '</div>';
				innerHTML +=    '<div class="step-item-point"></div>';
				innerHTML += '</li>';
				if(i != fields.length - 1){
					innerHTML += '<li class="step-li step-line-wrapper' + fields[i].name + '">';
					innerHTML +=    '<div class="step-item-line"></div>';
					innerHTML += '</li>';
				}
			}
			this.dom().find(".steps-ul").empty().append(innerHTML);
		},

		setValue: function(value){
			var _this = this.dom();
			var settings = this.settings;
			var fields = settings.fields;
			if(!fields){
				return;
			}
			this.value = value;

			this.dom().find(".step-point-wrapper").removeClass("current done undone");
			this.dom().find(".step-item-text").addClass("hidden");

			var liDom = this.dom().find(".step-item" + value);
			var liTextDom = this.dom().find(".step-item" + value + " .step-item-text");
			if(liDom.length>0){
				liDom.prevAll().removeClass("current");
				liDom.prevAll().removeClass("undone");
				liDom.prevAll().addClass("done");
				liDom.nextAll().removeClass("current");
				liDom.nextAll().removeClass("done");
				liDom.nextAll().addClass("undone");
				liDom.removeClass("done");
				liDom.removeClass("undone");
				liDom.addClass("current");
				liTextDom.removeClass("hidden");
			}

			for(var i = 0;  i < fields.length; i++){
				$("div.fieldset-container."+fields[i].container).hide();
			}

			$("div.fieldset-container."+value).show();
		},

		getValue: function(){
			return this.value;
		},

		next: function(){
			var _this = this.dom();
			var settings = this.settings;
			var fields = settings.fields;
			var step = this.getValue();

			for(var i = 0; i < fields.length; i++){
				if(step == fields[i].name){
					break;
				}
			}

			if(i < fields.length - 1){
				this.setValue(fields[i+1].name);
				this.dom().triggerHandler("ev_view_change", [{
                    "type": "value",
                    "value": fields[i+1].name
                }]);
			}
		},

		back: function(){
			var _this = this.dom();
			var settings = this.settings;
			var fields = settings.fields;
			var step = this.getValue();

			for(var i = 0; i < fields.length; i++){
				if(step == fields[i].name){
					break;
				}
			}

			if(i > 0){
				this.setValue(fields[i-1].name);
				this.dom().triggerHandler("ev_view_change", [{
                    "type": "value",
                    "value": fields[i-1].name
                }]);
			}
		}
	});
})();