(function($) {
	var InterfaceList = $.su.Widget.register('interfaceList', {
		settings: {},
		listeners: [],
		init: function(options) {},
		render: function() {
			var viewObj = this;
			var dom = this.dom();
			var settings = this.settings;

			dom.addClass("widget-container interface-list-container");

			var inHTML = '';
			inHTML += '<ul class="interface-list-wrap">';
			inHTML += '</ul>';

			dom.append(inHTML);
		},
		syncData: function (keys, callback) {
			this.dom().triggerHandler('ev_store_render_items', [keys]);
		},
		renderModels: function(key, models, callback) {
			var dom = "";
			for(var i = 0; i < models.length; i++) {
				var item = models[i].getData();
				dom += this.renderItem(item, i);
			}
			this.dom().find('.interface-list-wrap').html(dom);
		},
		renderItem: function(data, index) {
			// {
			//   type: lan/wan
			//   status: connected/disconnected
			//   speed
			//   duplex: FULL/HALF
			//   serial: 1, 2 ... 8, only for lan
			// }

			var dom = '<li class="interface-list-item '+ getCls(data.status) +'">';
			dom += '<div class="interface-item-wrap">';
			dom += '<span class="interface-icon"></span>';
			dom += '<span class="interface-name">' + getName(data.type, data.serial) + '</span>';
			if (data.status === "connected") {
				dom += '<span class="interface-speed-detail">';
				dom += '<span class="interface-speed">' + getSpeed(data.speed) + '</span>';
				dom += '<span class="interface-duplex">' + getDuplex(data.duplex) + '</span>';
				dom += '</span>';
			} else {
				dom += '<span class="interface-speed-detail">---</span>';
			}
			dom += "</div>"
			dom += "</li> "
			return dom;

			function getCls(status) {
				var statusCls = status === "connected" ? "connected" : "disconnected";
				return statusCls;
			}
			function getName(type, serial) {
				if (type.toLowerCase() === "wan") {
					return $.su.CHAR.NETWORK_MAP.INTERNET;
				}
				return $.su.CHAR.NETWORK_MAP.LAN + " " + serial;
			}
			function getSpeed(val) {
				val = parseInt(val, 10);
				if (val > 1000) {
					return val / 1000 + $.su.CHAR.NETWORK_MAP.GBPS_2;
				}
				return val + $.su.CHAR.NETWORK_MAP.MBPS_2;
			}
			function getDuplex(val) {
				if (val.toLowerCase() === "full") {
					return $.su.CHAR.NETWORK_MAP.FULL_DUPLEX;
				}
				return $.su.CHAR.NETWORK_MAP.HALF_DUPLEX;
			}
		}
	});
})(jQuery);
