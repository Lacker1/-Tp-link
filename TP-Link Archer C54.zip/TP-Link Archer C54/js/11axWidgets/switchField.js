/*
 * @description
 * @author XCH
 * @change
 *   2017/11/08: create file
 *
 * */
 (function($){
 	var QosBtn = $.su.Widget.register("switchField", {
 		settings: {
 			fields: {
 				attribute: "fields",
 				defaultValue: null
 			}
 		},

 		listeners: [{
 			selector: "div.fields-item-name",
 			event: "click",
 			callback: function(e, viewObj){
 				viewObj.dom().find("div.fields-item-name").removeClass("select");
 				$(this).addClass("select");

 				var fields = viewObj.settings.fields;
 				for(var i = 0;  i < fields.length; i++){
 					$("div.fieldset-container."+fields[i].container).hide();
 				}
	
				var item = $(this).attr("item");
 				$("div.fieldset-container."+item).show();
 				viewObj.dom().triggerHandler("ev_switch_click", [{
 					fields: viewObj.settings.fields
 				}]);
 			}
 		}],

 		init: function(){},

 		render: function(){
 			var me = this;
			var _this = this.dom();
			var settings = this.settings;
			var i = 0;

			_this.addClass("switch-field-container");

			var innerHTML =		'<div class="switch-field-name-wrapper">';
				innerHTML +=		'<div class="switch-field-name">'
			for(i=0; i<settings.fields.length; i++){
				innerHTML +=			'<div class="fields-item-name '+settings.fields[i].name+ (i == 0 ? ' first' : '') + (i == settings.fields.length - 1 ? ' lst' : '') + '" item="'+settings.fields[i].name+'"">';
				innerHTML +=				'<span>'+settings.fields[i].text+'</span>';
				innerHTML +=			'</div>';
			}
				innerHTML +=		'</div>';
				innerHTML +=	'</div>';
				innerHTML +=	'<div class="switch-field-content">';
				innerHTML +=	'</div>';

			_this.append(innerHTML);

			// if (_this.children('div[widget]').length > 0){
			// 	_this.children('div[widget]').appendTo(_this.find('div.switch-field-content'));
			// }
 		},

 		itemClick: function(item){
			var _this = this.dom();
			_this.find("div.fields-item-name."+item).trigger("click");
 		}
 	});
 })(jQuery);
